# -*- coding: utf-8 -*-
"""
Created on Mon Apr 24 15:47:19 2017

@author: tarachy
"""

# Load Libraries
import web
#import xml.etree.ElementTree as ET
import os
import pandas as pd
from nltk.corpus import stopwords
import re
import string
#from whoosh.analysis import StemmingAnalyzer
from whoosh.index import create_in
from whoosh.fields import Schema, ID, KEYWORD, TEXT
from whoosh.qparser import MultifieldParser, OrGroup, FuzzyTermPlugin, AndGroup
from whoosh.index import open_dir

from datetime import date, datetime
import numpy as np

#from math import isnan
import math
from math import sqrt

import shutil

# Define urls (to be used in web service)
urls = (
    '/batch', 'create_flat_files',
    '/trips/(.*)', 'search_trip',
    '/places/(.*)', 'search_place',
    '/share/(.*)', 'search_share',
    '/user/(.*)', 'search_user',
    '/all/(.*)', 'search_all'
)
  
app = web.application(urls, globals())

# Define classes

class create_flat_files(object):
    
    def GET(self):
        batch_proc()    


class search_trip(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        trip_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        trip_query = trip_query.split(' ')
        trip_query_1 = [i.encode('latin-1') for i in trip_query]
        trip_query = ' '.join(trip_query_1)
        
        self.trip_query = trip_query
        
        return search_query_trip(trip_query, user_id)[0]
    
    
class search_place(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        place_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        place_query = place_query.split(' ')
        place_query_1 = [i.encode('latin-1') for i in place_query]
        place_query = ' '.join(place_query_1)
        
        self.place_query = place_query
        
        return search_query_place(place_query, user_id)[0]
    
    
class search_share(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        share_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        share_query = share_query.split(' ')
        share_query_1 = [i.encode('latin-1') for i in share_query]
        share_query = ' '.join(share_query_1)
        
        self.share_query = share_query
        
        return search_query_share(share_query, user_id)[0]
    
class search_user(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        user_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        user_query = user_query.split(' ')
        user_query_1 = [i.encode('latin-1') for i in user_query]
        user_query = ' '.join(user_query_1)
        
        self.user_query = user_query
        
        return search_query_user_alone(user_query)
    
class search_all(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        self.query = query
        return search_query_all(query, user_id)

# Replacing all special characters with user defined
def replace_all(text):
    reps = {u'ö':'oe', u'ß':'ss', u'ß':'ss', u'ü':'ue', u'ä':'ae', u'Å':'ae', u'é':'e', u'Ä':'ae', u'Ö':'oe', u'Ü':'ue', u',':' ',  u'|':' ', u'-':' '}
    for i, j in reps.iteritems():
        #print('******** printing raw search text *************')
        #print(text)
        #print(type(text))
        #text = unicode(text, encoding="utf-8", errors="ignore")
        text = text.replace(i, j)
        #print('******** printing clean search text *************')
        #print(text)
        
    return text

def square_rooted(x): 
    return round(sqrt(sum([a*a for a in x])),3)
 
def cos_sim(x,y):
    numerator = sum(a*b for a,b in zip(x,y))
    denominator = square_rooted(x)*square_rooted(y)
    return round(numerator/float(denominator + 1e-11),4)

## Converting floating/nan User Ids to string
def float_to_string(x):
    cln_lst = []
    for i in x:
        if type(i) == float:
            if not math.isnan(i):
                val = str(int(float(i)))
                cln_lst.append(val)
        else:
            cln_lst.append(i)
    return cln_lst

# Define all functions

def batch_proc():
    user_weights = [5.0, 1.0, 1.0]
    
    trip_details, trip_profile, trip_details_old = read_files_trip()
    
    trip_profile = item_profile_trip(input_file = trip_details, output_file = trip_profile)
    
    print 'Processed Trip Profile. Saving file in path...'
    trip_profile.to_csv('trip_profile.csv', index = False, encoding = 'utf-8')
    trip_details, deleted_trips = remove_deleted_trips(trip_details)
    trip_details_flat = trip_details[['TripID', 'Description', 'Dest_Point', 'Sour_Point', 'Sugg_Places', 'Tags', 'Trip_Name', 'Owner', 'CommentList']]
    create_flat_trip_fn(trip_details_flat, deleted_trips)
    trip_details = trip_details[['TripID', 'Owner', 'Likes', 'Comments']]
    user_action_trip, trip_details = user_action_proc_trip(trip_details, trip_details_old, deleted_trips)
    
    print 'Processed trip details. Saving file in path...'
    trip_details.to_csv('trip_details.csv', index = False, encoding = 'utf-8')
    
    print 'Processed user actions for trip. Saving file in path...'
    user_action_trip.to_csv('user_action_trip.csv', index = False, encoding = 'utf-8')
    user_profile_trip = create_user_profile_trip(user_action_trip, trip_profile, user_weights)
    user_profile_trip.to_csv('user_profile_trip.csv', index = False, encoding = 'utf-8')
    trip_similarity = creat_trip_similarity(trip_profile, user_profile_trip)
    trip_similarity.to_csv('trip_similarity.csv', index = False)
    
    place_details, place_profile, place_details_old = read_files_place()
    
    place_profile = item_profile_place(input_file = place_details, output_file = place_profile)
    
    print 'Processed Place Profile. Saving file in path...'
    place_profile.to_csv('place_profile.csv', index = False, encoding = 'utf-8')
    place_details, deleted_places = remove_deleted_places(place_details)
    place_details_flat = place_details[['PlaceID', 'Place_Name', 'City', 'Country', 'District', 'Add1', 'State', 'Street', 'Detail_Desc', 'Info_Decor', 'Info_Limit', 'Info_Perm', 'Tags', 'CommentList', 'Owner']]
    create_flat_place_fn(place_details_flat, deleted_places)
    place_details = place_details[['PlaceID', 'Owner', 'Likes', 'Comments']]
    user_action_place, place_details = user_action_proc_place(place_details, place_details_old, deleted_places)
    
    print 'Processed place details. Saving file in path...'
    place_details.to_csv('place_details.csv', index = False, encoding = 'latin-1')
    
    print 'Processed user actions for place. Saving file in path...'
    user_action_place.to_csv('user_action_place.csv', index = False, encoding = 'utf-8')
    user_profile_place = create_user_profile_place(user_action_place, place_profile, user_weights)
    user_profile_place.to_csv('user_profile_place.csv', index = False, encoding = 'utf-8')
    place_similarity = creat_place_similarity(place_profile, user_profile_place)
    place_similarity.to_csv('place_similarity.csv', index = False)
    
    share_details, share_profile, share_details_old = read_files_share()
    
    share_profile = item_profile_share(input_file = share_details, output_file = share_profile)
    
    print 'Processed Share Profile. Saving file in path...'
    share_profile.to_csv('share_profile.csv', index = False, encoding = 'utf-8')
    share_details, deleted_shares = remove_deleted_shares(share_details)
    share_details_flat = share_details[['ShareID', 'Sharetext', 'CommentList', 'PlaceAddr', 'City', 'Owner']]
    create_flat_share_fn(share_details_flat, deleted_shares)
    share_details = share_details[['ShareID', 'Owner', 'Likes', 'Comments']]
    user_action_share, share_details = user_action_proc_share(share_details, share_details_old, deleted_shares)
    
    print 'Processed share details. Saving file in path...'
    share_details.to_csv('share_details.csv', index = False, encoding = 'utf-8')
    
    print 'Processed user actions for share. Saving file in path...'
    user_action_share.to_csv('user_action_share.csv', index = False, encoding = 'utf-8')
    
    user_profile_share = create_user_profile_share(user_action_share, share_profile, user_weights)
    user_profile_share.to_csv('user_profile_share.csv', index = False, encoding = 'utf-8')
    share_similarity = creat_share_similarity(share_profile, user_profile_share)
    share_similarity.to_csv('share_similarity.csv', index = False)
    
    create_flat_user_fn()


"""
TRIP FILES
"""
def remove_deleted_trips(trip_details):
    deleted_trips = []
    for i in xrange(trip_details.shape[0]):
        if pd.isnull(trip_details['Owner'][i]):
            j = trip_details['TripID'][i]
            trip_details = trip_details[trip_details.TripID != j]
            deleted_trips.append(j)
    trip_details = trip_details.reset_index(drop=True)
    if len(deleted_trips) == 0:
        deleted_trips = None
    return trip_details, deleted_trips


def read_files_trip():
    trip_details = pd.read_csv('trip_file.csv', encoding = 'latin-1')
    
    trip_details_old = None
    if os.path.exists('trip_details.csv'):
        trip_details_old = pd.read_csv('trip_details.csv', encoding = 'latin-1')
        #print 'Trip detail file exists. Reading file...'
    if os.path.exists('trip_profile.csv'):
        trip_profile = pd.read_csv('trip_profile.csv', encoding = 'utf-8')
        #print 'Trip Profile found. Updating file...'
    else:
        trip_profile = None
        #print 'Warning: Trip Profile not found in path. Creating new one...'
    return trip_details, trip_profile, trip_details_old

def item_profile_trip(input_file, output_file = None):
    input_file['Create_Date'] = pd.to_datetime(input_file['Create_Date'], format = '%Y-%m-%d')
    if output_file is None:
        output_file = create_item_profile_trip(input_file)
    else:
        output_file = update_item_profile_trip(input_file, output_file)
    return output_file

def update_item_profile_trip(input_file, output_file):
    
    print('Updating trip item profile...')
    time = datetime.now()
    
    profile_var = list(output_file.columns)
    tripid_list = list(output_file.TripID)
    for i in xrange(0, input_file.shape[0]):
        if input_file['TripID'][i] not in tripid_list and not pd.isnull(input_file['Create_Date'][i]):
            update_record = {}
            update_record['TripID'] = input_file['TripID'][i]
            Comment_Count = input_file['Comment_Count'][i]
            if Comment_Count == 0:
                update_record['comments_count_0'] = 1
            elif Comment_Count < 6:
                update_record['comments_count_5'] = 1
            elif Comment_Count < 21:
                update_record['comments_count_20'] = 1
            else:
                update_record['comments_count_more'] = 1
            Dist_Covered = input_file['Dist_Covered'][i]
            if Dist_Covered <= 50:
                update_record['Dist_Covered_50'] = 1
            elif Dist_Covered <= 200:
                update_record['Dist_Covered_200'] = 1
            elif Dist_Covered <=500:
                update_record['Dist_Covered_500'] = 1
            else:
                update_record['Dist_Covered_more'] = 1
            driving_exp = input_file['Driving_Exp'][i]
            if pd.notnull(driving_exp): 
                dri_exp_label = 'dri_exp_' + driving_exp
                if dri_exp_label not in profile_var:
                    profile_var.append(dri_exp_label)
                    output_file[dri_exp_label] = 0
            else:
                dri_exp_label = 'dri_exp_nan'
            update_record[dri_exp_label] = 1
            Like_Count = input_file['Like_Count'][i]
            if Like_Count == 0:
                update_record['likes_count_0'] = 1
            elif Like_Count < 11:
                update_record['likes_count_10'] = 1
            elif Like_Count < 51:
                update_record['likes_count_50'] = 1
            else:
                update_record['likes_count_more'] = 1
            my_car = input_file['My_Car'][i]
            if pd.notnull(my_car): 
                my_car_label = 'car_' + my_car
                if my_car_label not in profile_var:
                    profile_var.append(my_car_label)
                    output_file[my_car_label] = 0
            else:
                my_car_label = 'car_nan'
            update_record[my_car_label] = 1
            purp = input_file['Purpose'][i]
            if pd.notnull(purp): 
                purp_label = 'purp_' + purp
                if purp_label not in profile_var:
                    profile_var.append(purp_label)
                    output_file[purp_label] = 0
            else:
                purp_label = 'purp_nan'
                
            update_record[purp_label] = 1
            re_count = input_file['Reshare_Count'][i]
            datediff = (date.today() - input_file['Create_Date'][i].date()).days
            if datediff == 0:
                update_record['create_today'] = 1
            elif datediff < 8:
                update_record['create_1week'] = 1
            elif datediff < 31:
                update_record['create_1month'] = 1
            elif datediff < 91:
                update_record['create_3month'] = 1
            else:
                update_record['create_old'] = 1

            if re_count == 0:
                update_record['reshare_0'] = 1
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 0
            elif re_count <= 3:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 1
                update_record['reshare_m'] = 0
            else:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 1
            travellers = input_file['Travellers'][i]
            if travellers == 0:
                update_record['travellers_0'] = 1
                update_record['travellers_2'] = 0
                update_record['travellers_m'] = 0
            elif travellers == 1:
                update_record['travellers_0'] = 0
                update_record['travellers_2'] = 1
                update_record['travellers_m'] = 0
            else:
                update_record['travellers_0'] = 0
                update_record['travellers_2'] = 0
                update_record['travellers_m'] = 1
            update_record['tripimg_yes_no'] = input_file['TripImage'][i]
            stat = input_file['Trip_Status'][i]
            if pd.notnull(stat): 
                stat_label = 'stat_' + stat
                if stat_label not in profile_var:
                    profile_var.append(stat_label)
                    output_file[stat_label] = 0
            else:
                stat_label = 'stat_nan'
            update_record[stat_label] = 1
            update_list = []
            for m in profile_var:
                if m in update_record.keys():
                    update_list.append(update_record[m])
                else:
                    update_list.append(0)
            output_file.loc[len(output_file)] = update_list
        else:
            co_count = input_file['Comment_Count'][i]
            li_count = input_file['Like_Count'][i]
            re_count = input_file['Reshare_Count'][i]
            di_covered = input_file['Dist_Covered'][i]
            driving_exp = input_file['Driving_Exp'][i]
            travellers = input_file['Travellers'][i]
            stat = input_file['Trip_Status'][i]
            if pd.notnull(driving_exp):            
                dri_exp_label = 'dri_exp_' + driving_exp
                if dri_exp_label not in profile_var:
                    profile_var.append(dri_exp_label)
                    output_file[dri_exp_label] = 0
            else:
                dri_exp_label = 'dri_exp_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], dri_exp_label] = 1
            my_car = input_file['My_Car'][i]
            if pd.notnull(my_car): 
                my_car_label = 'car_' + my_car
                if my_car_label not in profile_var:
                    profile_var.append(my_car_label)
                    output_file[my_car_label] = 0
            else:
                my_car_label = 'car_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], my_car_label] = 1
            purp = input_file['Purpose'][i]
            if pd.notnull(purp): 
                purp_label = 'purp_' + purp
                if purp_label not in profile_var:
                    profile_var.append(purp_label)
                    output_file[purp_label] = 0
            else:
                purp_label = 'purp_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], purp_label] = 1
            output_file.ix[output_file.TripID == input_file.TripID[i], 'tripimg_yes_no'] = input_file['TripImage'][i]              
            if pd.notnull(stat): 
                stat_label = 'stat_' + stat
                if stat_label not in profile_var:
                    profile_var.append(stat_label)
                    output_file[stat_label] = 0
            else:
                stat_label = 'stat_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], stat_label] = 1              
            if travellers == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_2'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_m'] = 0
                
            elif travellers == 1:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_2'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_m'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_2'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_m'] = 1
            
            if co_count == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 0
            elif co_count < 6:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 0
            elif co_count < 21:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 1
            if li_count == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 0
            elif li_count < 11:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 0
            elif li_count < 51:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 1
            if re_count == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_3'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_m'] = 0
                
            elif re_count <= 3:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_3'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_m'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_3'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_m'] = 1
            if di_covered <= 50:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 0
            elif di_covered <= 200:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 0
            elif di_covered <= 500:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 1

    for i in xrange(input_file.shape[0]):
        if pd.isnull(input_file['Owner'][i]):
            j = input_file['TripID'][i]
            output_file = output_file[output_file.TripID != j]

    diff = datetime.now() - time
    print('Time taken to update trip item profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file
                                    
def create_item_profile_trip(input_file):
    
    print('Creating trip item profile...')
    time = datetime.now()
    
    profile_var = []
    profile_var.append('TripID')
    profile_var.append('tripimg_yes_no')
    dri_exp_list = list(input_file['Driving_Exp'].unique())
    dri_exp_list1 = []
    for dri_exp in dri_exp_list:
        try:
            dri_exp_list1.append('dri_exp_' + dri_exp)
        except:
            dri_exp_list1.append('dri_exp_' + str(dri_exp))
    dri_exp_list = dri_exp_list1[:]
    if 'dri_exp_nan' not in dri_exp_list:
        dri_exp_list.append('dri_exp_nan')
    my_car_list = list(input_file['My_Car'].unique())
    my_car_list1 = []
    for my_car in my_car_list:
        try:
            my_car_list1.append('car_' + my_car)
        except:
            my_car_list1.append('car_' + str(my_car))
    my_car_list = my_car_list1[:]
    if 'car_nan' not in my_car_list:
        my_car_list.append('car_nan')
    purp_list = list(input_file['Purpose'].unique())
    purp_list1 = []
    for purp in purp_list:
        try:
            purp_list1.append('purp_' + purp)
        except:
            purp_list1.append('purp_' + str(purp))
    purp_list = purp_list1[:]
    if 'purp_nan' not in purp_list:
        purp_list.append('purp_nan')
    trip_status_list = list(input_file['Trip_Status'].unique())
    trip_status_list1 = []
    for trip_stat in trip_status_list:
        try:
            trip_status_list1.append('stat_' + trip_stat)
        except:
            trip_status_list1.append('stat_' + str(trip_stat))
    trip_status_list = trip_status_list1[:]
    if 'stat_nan' not in trip_status_list:
        trip_status_list.append('stat_nan')
    create_list = ['create_today', 'create_1week', 'create_1month', 'create_3month', 'create_old']
    comment_list = ['comments_count_0', 'comments_count_5', 'comments_count_20', 'comments_count_more']
    like_list = ['likes_count_0', 'likes_count_10', 'likes_count_50', 'likes_count_more']
    reshare_list = ['reshare_0', 'reshare_3', 'reshare_m']
    dist_covered_list = ['Dist_Covered_50', 'Dist_Covered_200', 'Dist_Covered_500', 'Dist_Covered_more']
    travellers_list = ['travellers_0', 'travellers_2', 'travellers_m']
    
    profile_var = profile_var + dri_exp_list + my_car_list + purp_list + trip_status_list + create_list + comment_list + like_list + reshare_list + dist_covered_list + travellers_list
    output_file = pd.DataFrame(columns = profile_var)
    for i in xrange(0, input_file.shape[0]):
        update_record = {}
        update_record['TripID'] = input_file['TripID'][i]
        Comment_Count = input_file['Comment_Count'][i]
        if Comment_Count == 0:
            update_record['comments_count_0'] = 1
        elif Comment_Count < 6:
            update_record['comments_count_5'] = 1
        elif Comment_Count < 21:
            update_record['comments_count_20'] = 1
        else:
            update_record['comments_count_more'] = 1
        dist_covered = input_file['Dist_Covered'][i]
        if dist_covered <= 50:
            update_record['Dist_Covered_50'] = 1
        elif dist_covered <= 200:
            update_record['Dist_Covered_200'] = 1
        elif dist_covered <= 500:
            update_record['Dist_Covered_500'] = 1
        else:
            update_record['Dist_Covered_more'] = 1
        try:
            driving_exp_label = 'dri_exp_' + input_file['Driving_Exp'][i]
        except:
            driving_exp_label = 'dri_exp_' + str(input_file['Driving_Exp'][i])
        
        update_record[driving_exp_label] = 1
        Like_Count = input_file['Like_Count'][i]
        if Like_Count == 0:
            update_record['likes_count_0'] = 1
        elif Like_Count < 11:
            update_record['likes_count_10'] = 1
        elif Like_Count < 51:
            update_record['likes_count_50'] = 1
        else:
            update_record['likes_count_more'] = 1
        try:
            my_car_label = 'car_' + input_file['My_Car'][i]
        except:
            my_car_label = 'car_' + str(input_file['My_Car'][i])

        update_record[my_car_label] = 1
                     
        try:
            purp_label = 'purp_' + input_file['Purpose'][i]
        except:
            purp_label = 'purp_' + str(input_file['Purpose'][i])
     
        update_record[purp_label] = 1
        reshare_count = input_file['Reshare_Count'][i]
        if reshare_count == 0:
            update_record['reshare_0'] = 1
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 0
        elif reshare_count <= 3:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 1
            update_record['reshare_m'] = 0
        else:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 1
        datediff = (date.today() - input_file['Create_Date'][i].date()).days
        if datediff == 0:
            update_record['create_today'] = 1
        elif datediff < 8:
            update_record['create_1week'] = 1
        elif datediff < 31:
            update_record['create_1month'] = 1
        elif datediff < 91:
            update_record['create_3month'] = 1
        else:
            update_record['create_old'] = 1
        travellers = input_file['Travellers'][i]
        if travellers == 0:
            update_record['travellers_0'] = 1
        elif travellers == 1:
            update_record['travellers_2'] = 1
        else:
            update_record['travellers_m'] = 1
        update_record['tripimg_yes_no'] = input_file['TripImage'][i]
        
        try:
            stat_label = 'stat_' + input_file['Trip_Status'][i]
        except:
            stat_label = 'stat_' + str(input_file['Trip_Status'][i])

        update_record[stat_label] = 1
        update_list = []
        for m in profile_var:
            if m in update_record.keys():
                update_list.append(update_record[m])
            else:
                update_list.append(0)
        output_file.loc[len(output_file)] = update_list

    diff = datetime.now() - time
    print('Time taken to create trip item profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file


# apply(lambda text: replace_all(text))

def create_flat_trip_fn(trip_details_flat, deleted_trips = None):
    
    print('Creating trip flat file...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    
    trip_details_flat = trip_details_flat.fillna('i')
    
    trip_details_flat = trip_details_flat.astype('unicode')

    trip_details_flat['Description'] = trip_details_flat['Description'].apply(lambda x: replace_all(x))
    trip_details_flat['Description'] = trip_details_flat['Description'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['Dest_Point'] = trip_details_flat['Dest_Point'].apply(lambda x: replace_all(x))
    trip_details_flat['Dest_Point'] = trip_details_flat['Dest_Point'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['Sour_Point'] = trip_details_flat['Sour_Point'].apply(lambda x: replace_all(x))
    trip_details_flat['Sour_Point'] = trip_details_flat['Sour_Point'].apply(lambda x: str(x.encode('utf-8')))
    
    
    trip_details_flat['Sugg_Places'] = trip_details_flat['Sugg_Places'].apply(lambda x: replace_all(x))
    trip_details_flat['Sugg_Places'] = trip_details_flat['Sugg_Places'].apply(lambda x: str(x.encode('utf-8')))
        
    trip_details_flat['Tags'] = trip_details_flat['Tags'].apply(lambda x: replace_all(x))
    trip_details_flat['Tags'] = trip_details_flat['Tags'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['Trip_Name'] = trip_details_flat['Trip_Name'].apply(lambda x: replace_all(x))
    trip_details_flat['Trip_Name'] = trip_details_flat['Trip_Name'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['CommentList'] = trip_details_flat['CommentList'].apply(lambda x: replace_all(x))
    trip_details_flat['CommentList'] = trip_details_flat['CommentList'].apply(lambda x: str(x.encode('utf-8')))
    
    if os.path.exists('trip_details_flat.csv'):
        trip_details_flat_old = pd.read_csv('trip_details_flat.csv', encoding = 'latin-1')
        trip_details_flat_old = trip_details_flat_old.fillna('i')
        trip_details_flat_old['Owner'] = trip_details_flat_old['Owner'].apply(lambda x: str(int(x)))
        
        trip_details_flat_old['Description'] = trip_details_flat_old['Description'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Description'] = trip_details_flat_old['Description'].apply(lambda x: str(x.encode('utf-8')))
        
        trip_details_flat_old['Dest_Point'] = trip_details_flat_old['Dest_Point'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Dest_Point'] = trip_details_flat_old['Dest_Point'].apply(lambda x: str(x.encode('utf-8')))
        
        trip_details_flat_old['Sour_Point'] = trip_details_flat_old['Sour_Point'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Sour_Point'] = trip_details_flat_old['Sour_Point'].apply(lambda x: str(x.encode('utf-8')))
                
        trip_details_flat_old['Sugg_Places'] = trip_details_flat_old['Sugg_Places'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Sugg_Places'] = trip_details_flat_old['Sugg_Places'].apply(lambda x: str(x.encode('utf-8')))
        
        trip_details_flat_old['Tags'] = trip_details_flat_old['Tags'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Tags'] = trip_details_flat_old['Tags'].apply(lambda x: str(x.encode('utf-8')))
        
        
        trip_details_flat_old['Trip_Name'] = trip_details_flat_old['Trip_Name'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Trip_Name'] = trip_details_flat_old['Trip_Name'].apply(lambda x: str(x.encode('utf-8')))

        trip_details_flat_old['CommentList'] = trip_details_flat_old['CommentList'].apply(lambda x: replace_all(x))
        trip_details_flat_old['CommentList'] = trip_details_flat_old['CommentList'].apply(lambda x: str(x.encode('utf-8')))

        
        old_trip_ids = list(trip_details_flat_old['TripID'])
        
        for i in xrange(trip_details_flat.shape[0]):
            j = trip_details_flat['TripID'][i]
            
            if j in old_trip_ids:
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Description'] = trip_details_flat[trip_details_flat.TripID == j]['Description'].values[0]
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Dest_Point'] = trip_details_flat[trip_details_flat.TripID == j]['Dest_Point'].values[0]
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Sour_Point'] = trip_details_flat[trip_details_flat.TripID == j]['Sour_Point'].values[0]
                #sugg_temp = str(trip_details_flat[trip_details_flat.TripID == j]['Sugg_Places'].values[0])
                #sug_temp = sugg_temp.replace(',', ' ')
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Sugg_Places'] = str(trip_details_flat[trip_details_flat.TripID == j]['Sugg_Places'].values[0])
                #temp_tag = str(trip_details_flat[trip_details_flat.TripID == j]['Tags'].values[0])
                #temp_tag = temp_tag.replace(',', ' ')
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Tags'] = str(trip_details_flat[trip_details_flat.TripID == j]['Tags'].values[0])
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Trip_Name'] = trip_details_flat[trip_details_flat.TripID == j]['Trip_Name'].values[0]
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Owner'] = trip_details_flat[trip_details_flat.TripID == j]['Owner'].values[0]

                #comm_temp = trip_details_flat[trip_details_flat.TripID == j]['CommentList'].values[0]
                #comm_temp = comm_temp.replace('|', ' ')
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'CommentList'] = trip_details_flat[trip_details_flat.TripID == j]['CommentList'].values[0]
                
            else:
                trip_details_flat_old.loc[len(trip_details_flat_old)] = trip_details_flat[trip_details_flat.TripID == j].values[0]
                
        
        if deleted_trips is not None:
            for del_trip in deleted_trips:
                
                trip_details_flat_old = trip_details_flat_old[trip_details_flat_old.TripID != del_trip]

        trip_details_flat = trip_details_flat_old.reset_index(drop=True)
        
    if os.path.exists("tripindex"):
        shutil.rmtree("tripindex")

    data_list = trip_details_flat.values.tolist()
    collect_clean = []
    for items in data_list:
        
        bucket = []
        for text in items:
            
            if ' ' in text:
                clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
                
            else:
                
                clean_txt = ' '.join([word.lower() for word in text.split() if word not in stop_words])
            			
            bucket.append(clean_txt)
        collect_clean.append(bucket)
        
    column = trip_details_flat.columns    
    trip_details_flat = pd.DataFrame(collect_clean,columns = column)    
    trip_details_flat.to_csv('trip_details_flat.csv', index = False, encoding = 'latin-1')
    
    schema_trip = Schema(TripID = ID(stored=True),
                          Description = TEXT(field_boost=2.0, stored=True),
                          CommentList = TEXT(field_boost=1.0, stored=True),
                          Dest_Point = KEYWORD(field_boost=1.0, stored=True),
                          Sour_Point = KEYWORD(field_boost=1.0, stored=True),
                          Sugg_Places = KEYWORD(field_boost=1.0, stored=True),
                          Tags = TEXT(field_boost=2.0, stored=True),
                          Trip_Name = KEYWORD(field_boost=1.0, stored=True),
                          Owner = KEYWORD(stored=True))
    
    if not os.path.exists("tripindex"):
        os.mkdir("tripindex")
    trip_ix = create_in("tripindex", schema = schema_trip)
    trip_ix = open_dir("tripindex")
    trip_writer = trip_ix.writer()
    for val in collect_clean:
        #print unicode(val[2], encoding = "utf-8", errors = "ignore")
        trip_writer.add_document(TripID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                 Description = unicode((str(val[1]) if ' ' in val[1] else val[1]), encoding="utf-8", errors="ignore"),
                                 CommentList = unicode((str(val[8]) if ' ' in val[8] else val[8]), encoding="utf-8", errors="ignore"),
                                 Dest_Point = unicode((str(val[2]) if ' ' in val[2] else val[2]), encoding="utf-8", errors="ignore"),
                                 Sour_Point = unicode((str(val[3]) if ' ' in val[3] else val[3]), encoding="utf-8", errors="ignore"),
                                 Sugg_Places = unicode((str(val[4]) if ' ' in val[4] else val[4]), encoding="utf-8", errors="ignore"),
                                 Tags = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"),
                                 Trip_Name = unicode((str(val[6]) if ' ' in val[6] else val[6]), encoding="utf-8", errors="ignore"),
                                 Owner = unicode(str(val[7]), encoding="utf-8", errors="ignore"))
    trip_writer.commit()
    diff = datetime.now() - time
    print('Time taken to create trip flat file: ' + str(diff.seconds  ) + ' seconds')


def user_action_proc_trip(trip_details, trip_details_old, deleted_trips = None):
    if trip_details_old is not None:
        trip_details1 = trip_details_proc(trip_details, trip_details_old, deleted_trips)
        user_action_trip = create_user_action_trip(trip_details1)
        return user_action_trip, trip_details1
    else:
        user_action_trip = create_user_action_trip(trip_details)
        return user_action_trip, trip_details

def create_user_profile_trip(user_action_trip, trip_profile, user_weights):
    
    print('Creating users trip profile...')
    time = datetime.now()
    
    col_names = ['UserID'] + list(trip_profile.columns[1:])
    user_profile_trip = pd.DataFrame(columns = col_names)
    for i in xrange(user_action_trip.shape[0]):
        k = user_action_trip['UserID'][i]
        total_count = 0
        owns = str(user_action_trip['Owner'][i]).split('|')
        likes = str(user_action_trip['Likes'][i]).split('|')
        comments = str(user_action_trip['Comments'][i]).split('|')
        
        total_count = len(owns) * user_weights[0] + len(likes) * user_weights[1] + len(comments) * user_weights[2]
        update_record = []
        update_record.append(k)
        summation = np.zeros((1, trip_profile.shape[1]-1))[0]
        if owns is not None:
            for j in owns:
                if j not in ['None','nan']:
                    summation = summation + (trip_profile[trip_profile.TripID == j]).values[0][1:] * user_weights[0]
        if likes is not None:
            for j in likes:
                if j not in ['None','nan']:
                    summation = summation + (trip_profile[trip_profile.TripID == j]).values[0][1:] * user_weights[1]
        if comments is not None:
            for j in comments:
                if j not in ['None','nan']:
                    summation = summation + (trip_profile[trip_profile.TripID == j]).values[0][1:] * user_weights[2]
        summation /= total_count
        update_record = update_record + list(summation)
        user_profile_trip.loc[len(user_profile_trip)] = update_record
    diff = datetime.now() - time
    print('Time taken to users trip profile: ' + str(diff.seconds  ) + ' seconds')
    return user_profile_trip 

def creat_trip_similarity(trip_profile, user_profile_trip):
    print('Creating users trip similarity matrix...')
    time = datetime.now()
    col_names = ['TripID'] + list(user_profile_trip['UserID'])
    trip_similarity = pd.DataFrame(columns = col_names)
    trip_list = list(trip_profile['TripID'])
    for i in trip_list:
        update_record = [i]
        for k, j in enumerate(col_names):
            if k != 0:
                list1 = list(user_profile_trip[user_profile_trip.UserID == j].values[0][1:])
                list2 = list(trip_profile[trip_profile.TripID == i].values[0][1:])
                update_record.append(cos_sim(list1, list2))
        trip_similarity.loc[len(trip_similarity)] = update_record
    diff = datetime.now() - time
    print('Time taken to users trip similarity matrix: ' + str(diff.seconds  ) + ' seconds')
    return trip_similarity

def trip_details_proc(trip_details, trip_details_old, deleted_trips = None):
    print('Creating trip details file...')
    time = datetime.now()
    trip_list_old = list(trip_details_old['TripID'])
    trip_list_new = list(trip_details['TripID'])
    for i,j in enumerate(trip_list_new):
        if j in trip_list_old:
            if pd.isnull(trip_details['Owner'][i]):
                trip_details_old = trip_details_old[trip_details_old.TripID != j]
            elif str(trip_details['Owner'][i]).split('|') is None:
                trip_details_old = trip_details_old[trip_details_old.TripID != j]
            else:
                trip_details_old.loc[trip_details_old.TripID == j, 'Owner'] = trip_details[trip_details.TripID == j]['Owner'].values[0]
                trip_details_old.loc[trip_details_old.TripID == j, 'Likes'] = trip_details[trip_details.TripID == j]['Likes'].values[0]
                trip_details_old.loc[trip_details_old.TripID == j, 'Comments'] = trip_details[trip_details.TripID == j]['Comments'].values[0]
        else:
            trip_details_old.loc[len(trip_details_old)] = trip_details[trip_details.TripID == j].values[0]
    if deleted_trips is not None:
        for del_trip in deleted_trips:
            trip_details_old = trip_details_old[trip_details_old.TripID != del_trip]
    trip_details_old = trip_details_old.reset_index(drop=True)
    diff = datetime.now() - time
    print('Time taken to creat trip details file: ' + str(diff.seconds  ) + ' seconds')
    return trip_details_old 

def create_user_action_trip(trip_details):
    print('Creating users action trip...')
    time = datetime.now()
    
    ''' Converting a column to string if its data type is float/int type '''
    com_list = trip_details['Comments'].tolist()
    com_list = float_to_string(com_list)
    
    like_list = trip_details['Likes'].tolist()
    like_list = float_to_string(like_list)
    #trip_details.drop('Comments', axis=1, inplace=True)
        
    trip_details['Comments'] = pd.DataFrame(com_list, columns=['Comments'])
    trip_details['Likes'] = pd.DataFrame(like_list, columns=['Likes'])
    
    user_action_trip = pd.DataFrame(columns = ['UserID', 'Owner', 'Likes', 'Comments'])
    user_list = []
    
    for i in xrange(trip_details.shape[0]):
        u_list = []
        if pd.notnull(trip_details['Owner'][i]):
            owns = str(trip_details['Owner'][i]).split('|')
            if owns is not None:
                owns = [j.replace(' ','') for j in owns]
                owns = [j for j in owns if len(j) > 0]
        if owns is not None:
            for j in owns:
                if j is not None:
                    u_list.append(j)
        likes = None
        if pd.notnull(trip_details['Likes'][i]):
            likes = str(trip_details['Likes'][i]).split('|')
            if likes is not None:
                likes = [j.replace(' ','') for j in likes]
                likes = [j for j in likes if len(j) > 0]
        if likes is not None:
            for j in likes:
                if j is not None:
                    u_list.append(j)
        comments = None
        if pd.notnull(trip_details['Comments'][i]):
            comments = str(trip_details['Comments'][i]).split('|')
            if comments is not None:
                comments = [j.replace(' ','') for j in comments]
                comments = [j for j in comments if len(j) > 0]
        if comments is not None:
            for j in comments:
                if j is not None:
                    u_list.append(j)
        u_list = list(set(u_list))
        for k in u_list:
            if k not in user_list:
                user_list.append(k)
    for i in user_list:
        update_record = []
        update_record.append(i)
        ow = None
        li = None
        co = None
        for j in xrange(trip_details.shape[0]):
            if i in str(trip_details.Owner[j]):
                if ow is not None:
                    ow = ow + '|' + trip_details.TripID[j]
                else:
                    ow = trip_details.TripID[j]
            if i in str(trip_details.Likes[j]):
                if li is not None:
                    li = li + '|' + trip_details.TripID[j]
                else:
                    li = trip_details.TripID[j]
            if i in str(trip_details.Comments[j]):
                if co is not None:
                    co = co + '|' + trip_details.TripID[j]
                else:
                    co = trip_details.TripID[j]
        update_record.append(ow)
        update_record.append(li)
        update_record.append(co)
        user_action_trip.loc[len(user_action_trip)] = update_record
    
    diff = datetime.now() - time
    print('Time taken to user action trip: ' + str(diff.seconds  ) + ' seconds')
    return user_action_trip

def search_query_trip(trip_query, user_id):
    print('Processing user search query...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    trip_ix = open_dir("tripindex")
    multi_query_trip = MultifieldParser(["TripID","Description", "CommentList", "Dest_Point", "Sour_Point", "Sugg_Places", "Tags", "Trip_Name"], schema = trip_ix.schema, group = OrGroup)
    multi_query_trip.add_plugin(FuzzyTermPlugin())
    #multi_query_trip.add_plugin(WildcardPlugin())
    trip_query = unicode(str(trip_query), encoding="utf-8", errors="ignore")
    # trip_query = trip_query.lower()
    #trip_query = '#hello th@re! how are y&u'
#    print('************** printing raw search string from user ***********************')
#    print(trip_query)
#    print(type(trip_query))
    #trip_query = re.findall('[@#$&a-z0-9]+', trip_query.lower())
    
    trip_query = str(replace_all(trip_query)).lower()
#    print('Print trip query after processing')
#    print(trip_query)
#    print(type(trip_query))
    
    #trip_query = trip_query.split()
    trip_query = ' '.join([word + ('~2') for word in trip_query.split() if word not in stop_words and len(word) > 0])
#    print('******************* final trip_query for search ******************* ')
#    print(trip_query)
#    mug = []
#    for words in trip_query:
#        print(words)
#        words = words + ('~2/3')
#        mug.append(words)
#    trip_query = mug
#    
#    trip_query = ' '.join([word for word in trip_query.split()])
    #print('******************* PARSED QUERY ******************* ')
    q = multi_query_trip.parse(trip_query)
    #print(q)
    
    search_trip_ids = []
    search_trip_owners = []    
    with trip_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'

        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_trip_ids.append(str(results[i]['TripID']))
                search_trip_owners.append(str(results[i]['Owner']))
    trip_results = pd.DataFrame(columns = ['TripID', 'Owner', 'Score'])
    trip_results['TripID'] = search_trip_ids
    trip_results['Owner'] = search_trip_owners
    trip_similarity = pd.read_csv('trip_similarity.csv')
    if user_id in trip_similarity.columns:
        for i in xrange(trip_results.shape[0]):
            j = trip_results['TripID'][i]
            k = trip_similarity[trip_similarity.TripID == j][user_id].values
            trip_results['Score'][i] = k
            trip_results = trip_results.sort_values(['Score'], ascending=[0]).reset_index(drop = True )
        
        diff = datetime.now() - time
        print('Time taken to get the search results: ' + str(diff.seconds  ) + ' seconds')
        return list(trip_results['TripID'][:].values), list(trip_results['Owner'][:].values), list(trip_results['Score'][:].values)
    else:
        diff = datetime.now() - time
        print('Time taken to get the search results: ' + str(diff.seconds  ) + ' seconds')
        return search_trip_ids[:10], search_trip_owners[:10], None


"""
PLACE FILES
"""
def remove_deleted_places(place_details):
    deleted_places = []
    for i in xrange(place_details.shape[0]):
        if pd.isnull(place_details['Place_Name'][i]):
            j = place_details['PlaceID'][i]
            place_details = place_details[place_details.PlaceID != j]
            deleted_places.append(j)
    place_details = place_details.reset_index(drop=True)
    if len(deleted_places) == 0:
        deleted_places = None
    return place_details, deleted_places

def read_files_place():
    place_details = pd.read_csv('place_file.csv', encoding = 'latin-1')
    place_details_old = None
    if os.path.exists('place_details.csv'):
        place_details_old = pd.read_csv('place_details.csv', encoding = 'latin-1')
        #print 'Place detail file exists. Reading file...'
    if os.path.exists('place_profile.csv'):
        place_profile = pd.read_csv('place_profile.csv', encoding = 'utf-8')
        #print 'Place Profile found. Updating file...'
    else:
        place_profile = None
        #print 'Warning: Place Profile not found in path. Creating new one...'
    return place_details, place_profile, place_details_old

def item_profile_place(input_file, output_file = None):
    input_file['Create_Date'] = pd.to_datetime(input_file['Create_Date'], format = '%Y-%m-%d')
    if output_file is None:
        output_file = create_item_profile_place(input_file)
    else:
        output_file = update_item_profile_place(input_file, output_file)
    return output_file

def update_item_profile_place(input_file, output_file):
    
    print('Updating place item profile...')
    time = datetime.now()
    profile_var = list(output_file.columns)
    placeid_list = list(output_file.PlaceID)
    for i in xrange(0, input_file.shape[0]):
        if input_file['PlaceID'][i] not in placeid_list and not pd.isnull(input_file['Create_Date'][i]):
            update_record = {}
            update_record['PlaceID'] = input_file['PlaceID'][i]
            Comment_Count = input_file['Comment_Count'][i]
            if Comment_Count == 0:
                update_record['comments_count_0'] = 1
            elif Comment_Count < 6:
                update_record['comments_count_5'] = 1
            elif Comment_Count < 21:
                update_record['comments_count_20'] = 1
            else:
                update_record['comments_count_more'] = 1
            Like_Count = input_file['Like_Count'][i]
            if Like_Count == 0:
                update_record['likes_count_0'] = 1
            elif Like_Count < 11:
                update_record['likes_count_10'] = 1
            elif Like_Count < 51:
                update_record['likes_count_50'] = 1
            else:
                update_record['likes_count_more'] = 1
            re_count = input_file['Reshare_Count'][i]
            if re_count == 0:
                update_record['reshare_0'] = 1
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 0
            elif re_count <= 3:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 1
                update_record['reshare_m'] = 0
            else:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 1
            category = input_file['Category'][i]
            if pd.notnull(category):
                category_label = 'cat_' + category
                if category_label not in profile_var:
                    profile_var.append(category_label)
                    output_file[category_label] = 0
            else:
                category_label = 'cat_nan'
            update_record[category_label] = 1
            city = input_file['City'][i]
            if pd.notnull(city):
                city_label = 'city_' + city
                if city_label not in profile_var:
                    profile_var.append(city_label)
                    output_file[city_label] = 0
            else:
                city_label = 'city_nan'
            update_record[city_label] = 1
            subcategory = input_file['Subcategory'][i]
            if pd.notnull(subcategory):
                subcat_label = 'sub_' + subcategory
                if subcat_label not in profile_var:
                    profile_var.append(subcat_label)
                    output_file[subcat_label] = 0
            else:
                subcat_label = 'sub_nan'
            update_record[subcat_label] = 1
            
            email_check = input_file['Contact_Email'][i]
            if pd.isnull(email_check):
                update_record['email_yes_no'] = 0
            else:
                update_record['email_yes_no'] = 1
            
            phone_check = input_file['Phone'][i]
            if pd.isnull(phone_check):
                update_record['phone_yes_no'] = 0
            else:
                update_record['phone_yes_no'] = 1
            
            website_check = input_file['Website'][i]
            if pd.isnull(website_check):
                update_record['website_yes_no'] = 0
            else:
                update_record['website_yes_no'] = 1
            
            update_record['placeimg_yes_no'] = input_file['placeimg_yes_no'][i]
            
            update_list = []
            for m in profile_var:
                if m in update_record.keys():
                    update_list.append(update_record[m])
                else:
                    update_list.append(0)
            output_file.loc[len(output_file)] = update_list
        else:
            co_count = input_file['Comment_Count'][i]
            li_count = input_file['Like_Count'][i]
            re_count = input_file['Reshare_Count'][i]
            placeimg = input_file['placeimg_yes_no'][i]
#            website = input_file['Website'][i]
#            phone = input_file['Phone'][i]
#            email = input_file['Contact_Email'][i]
            category = input_file['Category'][i]
            subcategory = input_file['Subcategory'][i]
            city = input_file['City'][i]
            
            if pd.notnull(city):            
                city_label = 'city_' + city
                if city_label not in profile_var:
                    profile_var.append(city_label)
                    output_file[city_label] = 0
            else:
                city_label = 'city_nan'
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], city_label] = 1
            
            if pd.notnull(category): 
                cat_label = 'cat_' + category
                if cat_label not in profile_var:
                    profile_var.append(cat_label)
                    output_file[cat_label] = 0
            else:
                cat_label = 'cat_nan'
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], cat_label] = 1
            
            if pd.notnull(subcategory): 
                sub_label = 'sub_' + subcategory
                if sub_label not in profile_var:
                    profile_var.append(sub_label)
                    output_file[sub_label] = 0
            else:
                sub_label = 'sub_nan'
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], sub_label] = 1
                              
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'placeimg_yes_no'] = placeimg
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'website_yes_no'] = output_file['website_yes_no'][i]
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'phone_yes_no'] = output_file['phone_yes_no'][i]
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'email_yes_no'] = output_file['email_yes_no'][i]
            
            if co_count == 0:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 0
            elif co_count < 6:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 0
            elif co_count < 21:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 0
            else:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 1
            if li_count == 0:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 0
            elif li_count < 11:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 0
            elif li_count < 51:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 0
            else:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 1
            if re_count == 0:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_0'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_3'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_m'] = 0
                
            elif re_count <= 3:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_3'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_m'] = 0
            else:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_3'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_m'] = 1

    for i in xrange(input_file.shape[0]):
        if pd.isnull(input_file['Place_Name'][i]):
            j = input_file['PlaceID'][i]
            output_file = output_file[output_file.PlaceID != j]
    
    diff = datetime.now() - time
    print('Time taken to update palce item profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file

def create_item_profile_place(input_file):
    
    print('Creating place item profile...')
    time = datetime.now()
    profile_var = []
    profile_var.append('PlaceID')
    create_list = ['create_today', 'create_1week', 'create_1month', 'create_3month', 'create_old']
    city_list = list(input_file['City'].unique())
    city_list1 = []
    for cit in city_list:
        try:
            city_list1.append('city_' + cit)
        except:
            city_list1.append('city_' + str(cit))
    city_list = city_list1[:]
    if 'city_nan' not in city_list:
        city_list.append('city_nan')
    category_list = list(input_file['Category'].unique())
    category_list1 = []
    for cat in category_list:
        try:
            category_list1.append('cat_' + cat)
        except:
            category_list1.append('cat_' + str(cat))
    category_list = category_list1[:]
    if 'cat_nan' not in category_list:
        category_list.append('cat_nan')
    comment_list = ['comments_count_0', 'comments_count_5', 'comments_count_20', 'comments_count_more']
    profile_var.append('email_yes_no')
    profile_var.append('phone_yes_no')
    profile_var.append('website_yes_no')
    like_list = ['likes_count_0', 'likes_count_10', 'likes_count_50', 'likes_count_more']
    profile_var.append('placeimg_yes_no')
    reshare_list = ['reshare_0', 'reshare_3', 'reshare_m']
    subcat_list = list(input_file['Subcategory'].unique())
    subcat_list1 = []
    for sub in subcat_list:
        try:
            subcat_list1.append('sub_' + sub)
        except:
            subcat_list1.append('sub_' + str(sub))
    subcat_list = subcat_list1[:]
    if 'sub_nan' not in subcat_list:
        subcat_list.append('sub_nan')

    profile_var = profile_var + create_list + city_list + category_list + comment_list + like_list + reshare_list + subcat_list
    output_file = pd.DataFrame(columns = profile_var)
    for i in xrange(0, input_file.shape[0]):
        update_record = {}
        update_record['PlaceID'] = input_file['PlaceID'][i]
        datediff = (date.today() - input_file['Create_Date'][i].date()).days
        if datediff == 0:
            update_record['create_today'] = 1
        elif datediff < 8:
            update_record['create_1week'] = 1
        elif datediff < 31:
            update_record['create_1month'] = 1
        elif datediff < 91:
            update_record['create_3month'] = 1
        else:
            update_record['create_old'] = 1
        try:
            city = 'city_' + input_file['City'][i]
        except:
            city = 'city_' + str(input_file['City'][i])
        update_record[city] = 1
        try:
            category = 'cat_' + input_file['Category'][i]
        except:
            category = 'cat_' + str(input_file['Category'][i])
        update_record[category] = 1
        Comment_Count = input_file['Comment_Count'][i]
        if Comment_Count == 0:
            update_record['comments_count_0'] = 1
        elif Comment_Count < 6:
            update_record['comments_count_5'] = 1
        elif Comment_Count < 21:
            update_record['comments_count_20'] = 1
        else:
            update_record['comments_count_more'] = 1
        
        email_check = input_file['Contact_Email'][i]
        #print('************* #print email ****************')
        #print(email_check)
        #print(type(email_check))
        if pd.isnull(email_check):
            update_record['email_yes_no'] = 0
        else:
            update_record['email_yes_no'] = 1
        
        phone_check = input_file['Phone'][i]
        if pd.isnull(phone_check):
            update_record['phone_yes_no'] = 0
        else:
            update_record['phone_yes_no'] = 1
        
        website_check = input_file['Website'][i]
        if pd.isnull(website_check):
            update_record['website_yes_no'] = 0
        else:
            update_record['website_yes_no'] = 1
        
        update_record['placeimg_yes_no'] = input_file['placeimg_yes_no'][i]

        
        Like_Count = input_file['Like_Count'][i]
        if Like_Count == 0:
            update_record['likes_count_0'] = 1
        elif Like_Count < 11:
            update_record['likes_count_10'] = 1
        elif Like_Count < 51:
            update_record['likes_count_50'] = 1
        else:
            update_record['likes_count_more'] = 1
        reshare_count = input_file['Reshare_Count'][i]
        if reshare_count == 0:
            update_record['reshare_0'] = 1
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 0
        elif reshare_count <= 3:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 1
            update_record['reshare_m'] = 0
        else:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 1
        try:
            subcat = 'sub_' + input_file['Subcategory'][i]
        except:
            subcat = 'sub_' + str(input_file['Subcategory'][i])
        update_record[subcat] = 1

        update_list = []
        for m in profile_var:
            if m in update_record.keys():
                update_list.append(update_record[m])
            else:
                update_list.append(0)
        output_file.loc[len(output_file)] = update_list
    diff = datetime.now() - time
    print('Time taken to create palce item profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file

def create_flat_place_fn(place_details_flat, deleted_places = None):
    print('Creating place flat file...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    
    place_details_flat = place_details_flat.fillna('i')
    #place_details_flat = place_details_flat.astype('unicode')

    place_details_flat['Place_Name'] = place_details_flat['Place_Name'].apply(lambda x: replace_all(x))
    place_details_flat['Place_Name'] = place_details_flat['Place_Name'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['City'] = place_details_flat['City'].apply(lambda x: replace_all(x))
    place_details_flat['City'] = place_details_flat['City'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Country'] = place_details_flat['Country'].apply(lambda x: replace_all(x))
    place_details_flat['Country'] = place_details_flat['Country'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['District'] = place_details_flat['District'].apply(lambda x: replace_all(x))
    place_details_flat['District'] = place_details_flat['District'].apply(lambda x: str(x.encode('utf-8')))
        
    place_details_flat['Add1'] = place_details_flat['Add1'].apply(lambda x: replace_all(x))
    place_details_flat['Add1'] = place_details_flat['Add1'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['State'] = place_details_flat['State'].apply(lambda x: replace_all(x))
    place_details_flat['State'] = place_details_flat['State'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Street'] = place_details_flat['Street'].apply(lambda x: replace_all(x))
    place_details_flat['Street'] = place_details_flat['Street'].apply(lambda x: str(x.encode('utf-8')))
        
    place_details_flat['Detail_Desc'] = place_details_flat['Detail_Desc'].apply(lambda x: replace_all(x))
    place_details_flat['Detail_Desc'] = place_details_flat['Detail_Desc'].apply(lambda x: str(x.encode('utf8')))
    
    place_details_flat['Info_Decor'] = place_details_flat['Info_Decor'].apply(lambda x: replace_all(x))
    place_details_flat['Info_Decor'] = place_details_flat['Info_Decor'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Info_Limit'] = place_details_flat['Info_Limit'].apply(lambda x: replace_all(x))
    place_details_flat['Info_Limit'] = place_details_flat['Info_Limit'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Info_Perm'] = place_details_flat['Info_Perm'].apply(lambda x: replace_all(x))
    place_details_flat['Info_Perm'] = place_details_flat['Info_Perm'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Tags'] = place_details_flat['Tags'].apply(lambda x: replace_all(x))
    place_details_flat['Tags'] = place_details_flat['Tags'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['CommentList'] = place_details_flat['CommentList'].apply(lambda x: replace_all(x))
    place_details_flat['CommentList'] = place_details_flat['CommentList'].apply(lambda x: str(x.encode('utf-8')))
    
    if os.path.exists('place_details_flat.csv'):
        place_details_flat_old = pd.read_csv('place_details_flat.csv', encoding = 'latin-1')
        
        place_details_flat_old = place_details_flat_old.fillna('i')
        
        place_details_flat_old['Owner'] = place_details_flat_old['Owner'].apply(lambda x: place_owner_int(x))
        
        place_details_flat_old['Place_Name'] = place_details_flat_old['Place_Name'].apply(lambda x: replace_all(x))
        place_details_flat_old['Place_Name'] = place_details_flat_old['Place_Name'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['City'] = place_details_flat_old['City'].apply(lambda x: replace_all(x))
        place_details_flat_old['City'] = place_details_flat_old['City'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Country'] = place_details_flat_old['Country'].apply(lambda x: replace_all(x))
        place_details_flat_old['Country'] = place_details_flat_old['Country'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['District'] = place_details_flat_old['District'].apply(lambda x: replace_all(x))
        place_details_flat_old['District'] = place_details_flat_old['District'].apply(lambda x: str(x.encode('utf-8')))
                
        place_details_flat_old['Add1'] = place_details_flat_old['Add1'].apply(lambda x: replace_all(x))
        place_details_flat_old['Add1'] = place_details_flat_old['Add1'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['State'] = place_details_flat_old['State'].apply(lambda x: replace_all(x))
        place_details_flat_old['State'] = place_details_flat_old['State'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Street'] = place_details_flat_old['Street'].apply(lambda x: replace_all(x))
        place_details_flat_old['Street'] = place_details_flat_old['Street'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Detail_Desc'] = place_details_flat_old['Detail_Desc'].apply(lambda x: replace_all(x))
        place_details_flat_old['Detail_Desc'] = place_details_flat_old['Detail_Desc'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Info_Decor'] = place_details_flat_old['Info_Decor'].apply(lambda x: replace_all(x))
        place_details_flat_old['Info_Decor'] = place_details_flat_old['Info_Decor'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Info_Limit'] = place_details_flat_old['Info_Limit'].apply(lambda x: replace_all(x))
        place_details_flat_old['Info_Limit'] = place_details_flat_old['Info_Limit'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Info_Perm'] = place_details_flat_old['Info_Perm'].apply(lambda x: replace_all(x))
        place_details_flat_old['Info_Perm'] = place_details_flat_old['Info_Perm'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Tags'] = place_details_flat_old['Tags'].apply(lambda x: replace_all(x))
        place_details_flat_old['Tags'] = place_details_flat_old['Tags'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['CommentList'] = place_details_flat_old['CommentList'].apply(lambda x: replace_all(x))
        place_details_flat_old['CommentList'] = place_details_flat_old['CommentList'].apply(lambda x: str(x.encode('utf-8')))
        
        old_place_ids = list(place_details_flat_old['PlaceID'])
        for i in xrange(place_details_flat.shape[0]):
            j = place_details_flat['PlaceID'][i]
#            #print('********************************** place details flat *********************** ')
#            #print(j)
#            #print(type(j))
            if j in old_place_ids:
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Place_Name'] = place_details_flat[place_details_flat.PlaceID == j]['Place_Name'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'City'] = place_details_flat[place_details_flat.PlaceID == j]['City'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Country'] = place_details_flat[place_details_flat.PlaceID == j]['Country'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'District'] = place_details_flat[place_details_flat.PlaceID == j]['District'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Add1'] = place_details_flat[place_details_flat.PlaceID == j]['Add1'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'State'] = place_details_flat[place_details_flat.PlaceID == j]['State'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Street'] = place_details_flat[place_details_flat.PlaceID == j]['Street'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Detail_Desc'] = place_details_flat[place_details_flat.PlaceID == j]['Detail_Desc'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Info_Decor'] = place_details_flat[place_details_flat.PlaceID == j]['Info_Decor'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Info_Limit'] = place_details_flat[place_details_flat.PlaceID == j]['Info_Limit'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Info_Perm'] = place_details_flat[place_details_flat.PlaceID == j]['Info_Perm'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Tags'] = place_details_flat[place_details_flat.PlaceID == j]['Tags'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'CommentList'] = place_details_flat[place_details_flat.PlaceID == j]['CommentList'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Owner'] = place_details_flat[place_details_flat.PlaceID == j]['Owner'].values[0]
                
            else:
                place_details_flat_old.loc[len(place_details_flat_old)] = place_details_flat[place_details_flat.PlaceID == j].values[0]
        if deleted_places is not None:
            for del_pla in deleted_places:
                place_details_flat_old = place_details_flat_old[place_details_flat_old.PlaceID != del_pla]
        place_details_flat = place_details_flat_old.reset_index(drop=True)
        
    
       
    if os.path.exists("placeindex"):
        shutil.rmtree("placeindex")    
    
    place_details_flat['Owner'] = place_details_flat['Owner'].astype('str')
    data_list = place_details_flat.values.tolist()
    collect_clean = []
    for items in data_list:
        ##print items
        ##print '------------------------------------>'
        bucket = []
        for text in items:
            #print text
            #print type(text)
            #clean_txt = ' '.join([word.encode('latin-1').lower() for word in str(text).decode('latin-1').split() if word not in stop_words])
            #clean_txt = ' '.join([word.lower() for word in text if word not in stop_words])
            clean_txt = ' '.join([word.lower() for word in text.split() if word not in stop_words])
#            
#            if ' ' in text:
#                clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
#                
#            else:
#                
#                clean_txt = ' '.join([word.lower() for word in text.split() if word not in stop_words])

            bucket.append(clean_txt)
        collect_clean.append(bucket)
    
    column = place_details_flat.columns
    place_details_flat = pd.DataFrame(collect_clean,columns = column)
    place_details_flat.to_csv('place_details_flat.csv', index = False, encoding = 'latin-1')
    
    schema_place = Schema(PlaceID = ID(stored=True),
                          Place_Name = KEYWORD(field_boost=1.0, stored=True),
                          City = KEYWORD(field_boost=1.0, stored=True),
                          Country = KEYWORD(field_boost=1.0, stored=True),
                          District = KEYWORD(field_boost=1.0, stored=True),                 
                          Add1 = TEXT(field_boost=1.0, stored=True),
                          State = KEYWORD(field_boost=1.0, stored=True),           
                          Street = TEXT(field_boost=1.0, stored=True),
                          Detail_Desc = TEXT(field_boost=2.0, stored=True),
                          Info_Decor = TEXT(field_boost=1.0, stored=True),
                          Info_Limit = TEXT(field_boost=1.0, stored=True),
                          Info_Perm = TEXT(field_boost=1.0, stored=True),
                          Tags = TEXT(field_boost=2.0, stored=True),
                          CommentList = TEXT(field_boost=1.0, stored=True),
                          Owner = KEYWORD(stored=True))

    if not os.path.exists("placeindex"):
        os.mkdir("placeindex")
    place_ix = create_in("placeindex", schema = schema_place)
    place_ix = open_dir("placeindex")
    place_writer = place_ix.writer()
    for val in collect_clean:
        #print(val[4])
        #print(type(val[4]))
        place_writer.add_document(PlaceID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                  Place_Name = unicode((str(val[1]) if ' ' in val[1] else val[1])),
                                  City = unicode((str(val[2]) if ' ' in val[2] else val[2])),
                                  Country = unicode((str(val[3]) if ' ' in val[3] else val[3])),
                                  District = unicode((str(val[4]) if ' ' in val[4] else val[4])),
                                  Add1 = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"),
                                  State = unicode((str(val[6]) if ' ' in val[6] else val[6])),
                                  Street = unicode((str(val[7]) if ' ' in val[7] else val[7])),
                                  Detail_Desc = unicode((str(val[8]) if ' ' in val[8] else val[8]),encoding="utf-8", errors="ignore"),
                                  Info_Decor = unicode((str(val[9]) if ' ' in val[9] else val[9])),
                                  Info_Limit = unicode((str(val[10]) if ' ' in val[10] else val[10])),
                                  Info_Perm = unicode((str(val[11]) if ' ' in val[11] else val[11])),
                                  Tags = unicode((str(val[12]) if ' ' in val[12] else val[12])),
                                  CommentList = unicode((str(val[13]) if ' ' in val[13] else val[13])),
                                  Owner = unicode(str(val[14]), encoding="utf-8", errors="ignore"))
    place_writer.commit()
    diff = datetime.now() - time
    print('Time taken to create place flat file: ' + str(diff.seconds  ) + ' seconds')

def user_action_proc_place(place_details, place_details_old, deleted_places = None):
    if place_details_old is not None:
        place_details1 = place_details_proc(place_details, place_details_old, deleted_places)
        user_action_place = create_user_action_place(place_details1)
        return user_action_place, place_details1
    else:
        user_action_place = create_user_action_place(place_details)
        return user_action_place, place_details
    
def create_user_profile_place(user_action_place, place_profile, user_weights):
    print('Creating user place profile...')
    time = datetime.now()
    
    col_names = ['UserID'] + list(place_profile.columns[1:])
    user_profile_place = pd.DataFrame(columns = col_names)
    for i in xrange(user_action_place.shape[0]):
        k = user_action_place['UserID'][i]
        total_count = 0
        owns = str(user_action_place['Owner'][i]).split('|')
        likes = str(user_action_place['Likes'][i]).split('|')
        comments = str(user_action_place['Comments'][i]).split('|')
        
        total_count = len(owns) * user_weights[0] + len(likes) * user_weights[1] + len(comments) * user_weights[2]
        update_record = []
        update_record.append(k)
        summation = np.zeros((1, place_profile.shape[1]-1))[0]
        if owns is not None:
            for j in owns:
                #print('******************** Owners ******************')
                #print(j)
                if j not in ['None','nan']:
                    #print((place_profile[place_profile.PlaceID == j]).values[0][1:])
                    summation = summation + (place_profile[place_profile.PlaceID == j]).values[0][1:] * user_weights[0]
        else:
            summation = summation
        if likes is not None:
            for j in likes:
                if j not in ['None','nan']:
                    summation = summation + (place_profile[place_profile.PlaceID == j]).values[0][1:] * user_weights[1]
        else:
            summation = summation
        if comments is not None:
            for j in comments:
                if j not in ['None','nan']:
                    summation = summation + (place_profile[place_profile.PlaceID == j]).values[0][1:] * user_weights[2]
        else:
            summation = summation
        summation /= total_count
        update_record = update_record + list(summation)
        user_profile_place.loc[len(user_profile_place)] = update_record
    diff = datetime.now() - time
    print('Time taken to create user place profile: ' + str(diff.seconds  ) + ' seconds')
    return user_profile_place 

def creat_place_similarity(place_profile, user_profile_place):
    print('creating place similarity matrix...')
    time = datetime.now()
    col_names = ['PlaceID'] + list(user_profile_place['UserID'])
    place_similarity = pd.DataFrame(columns = col_names)
    place_list = list(place_profile['PlaceID'])
    for i in place_list:
        update_record = [i]
        for k, j in enumerate(col_names):
            if k != 0:
                list1 = list(user_profile_place[user_profile_place.UserID == j].values[0][1:])
                list2 = list(place_profile[place_profile.PlaceID == i].values[0][1:])
                update_record.append(cos_sim(list1, list2))
        place_similarity.loc[len(place_similarity)] = update_record
    diff = datetime.now() - time
    print('Time taken to create place similarity matrix: ' + str(diff.seconds  ) + ' seconds')
    return place_similarity

def place_details_proc(place_details, place_details_old, deleted_places = None):
    place_list_old = list(place_details_old['PlaceID'])
    place_list_new = list(place_details['PlaceID'])
    for i,j in enumerate(place_list_new):
        if j in place_list_old:
            place_details_old.loc[place_details_old.PlaceID == j, 'Owner'] = place_details[place_details.PlaceID == j]['Owner'].values[0]
            place_details_old.loc[place_details_old.PlaceID == j, 'Likes'] = place_details[place_details.PlaceID == j]['Likes'].values[0]
            place_details_old.loc[place_details_old.PlaceID == j, 'Comments'] = place_details[place_details.PlaceID == j]['Comments'].values[0]
        else:
            place_details_old.loc[len(place_details_old)] = place_details[place_details.PlaceID == j].values[0]
    if deleted_places is not None:
        for del_plac in deleted_places:
            place_details_old = place_details_old[place_details_old.PlaceID != del_plac]
    place_details_old = place_details_old.reset_index(drop=True)
    return place_details_old

def create_user_action_place(place_details):
    print('Creating place user action file...')
    time =  datetime.now()
    ''' Converting a column to string if its data type is float/int type '''
    com_list = place_details['Comments'].tolist()
    com_list = float_to_string(com_list)
    
    like_list = place_details['Likes'].tolist()
    like_list = float_to_string(like_list)
    #trip_details.drop('Comments', axis=1, inplace=True)
        
    place_details['Comments'] = pd.DataFrame(com_list, columns=['Comments'])
    place_details['Likes'] = pd.DataFrame(like_list, columns=['Likes'])
        
    user_action_place = pd.DataFrame(columns = ['UserID', 'Owner', 'Likes', 'Comments'])
    user_list = []
    
    for i in xrange(place_details.shape[0]):
        u_list = []
        owns = None
        if pd.notnull(place_details['Owner'][i]):
            owns = str(place_details['Owner'][i]).split('|')
            if owns is not None:
                owns = [j.replace(' ','') for j in owns]
                owns = [j for j in owns if len(j) > 0]
        if owns is not None:
            for j in owns:
                if j is not None:
                    u_list.append(j)
        likes = None
        if pd.notnull(place_details['Likes'][i]):
            likes = str(place_details['Likes'][i]).split('|')
            if likes is not None:
                likes = [j.replace(' ','') for j in likes]
                likes = [j for j in likes if len(j) > 0]
        if likes is not None:
            for j in likes:
                if j is not None:
                    u_list.append(j)
        comments = None
        if pd.notnull(place_details['Comments'][i]):
            comments = str(place_details['Comments'][i]).split('|')
            if comments is not None:
                comments = [j.replace(' ','') for j in comments]
                comments = [j for j in comments if len(j) > 0]
        if comments is not None:
            for j in comments:
                if j is not None:
                    u_list.append(j)
        u_list = list(set(u_list))
        for k in u_list:
            if k not in user_list:
                user_list.append(k)
    for i in user_list:
        update_record = []
        update_record.append(i)
        ow = None
        li = None
        co = None
        for j in xrange(place_details.shape[0]):
            if i in str(place_details.Owner[j]):
                if ow is not None:
                    ow = ow + '|' + place_details.PlaceID[j]
                else:
                    ow = place_details.PlaceID[j]
            if i in str(place_details.Likes[j]):
                if li is not None:
                    li = li + '|' + place_details.PlaceID[j]
                else:
                    li = place_details.PlaceID[j]
            if i in str(place_details.Comments[j]):
                if co is not None:
                    co = co + '|' + place_details.PlaceID[j]
                else:
                    co = place_details.PlaceID[j]
        update_record.append(ow)
        update_record.append(li)
        update_record.append(co)
        user_action_place.loc[len(user_action_place)] = update_record
    diff = datetime.now() - time
    print('Time taken to create place user action: ' + str(diff.seconds  ) + ' seconds')
    return user_action_place

def search_query_place(place_query, user_id):
    print('Processing users query for place...')
    time = datetime.now()
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    place_ix = open_dir("placeindex")
    multi_query_place = MultifieldParser(['PlaceID', 'Place_Name', 'City', 'Country', 'District', 'Add1', 'State', 'Street', 'Detail_Desc', 'Info_Decor', 'Info_Limit', 'Info_Perm', 'Tags', 'CommentList'], schema = place_ix.schema, group = OrGroup)
    multi_query_place.add_plugin(FuzzyTermPlugin())
    
#    print('Printing raw search string from user...')
#    print(place_query)
#    #print(type(place_query))
    
    place_query = unicode(str(place_query), encoding="utf-8", errors="ignore")
    place_query = str(replace_all(place_query)).lower()
    
#    print('Printing clean search string from user...')
#    print(place_query)
    #print(type(place_query))
    
    place_query = ' '.join([word + ('~2') for word in place_query.split() if word not in stop_words and len(word) > 0])
#    print(place_query)
    
    q = multi_query_place.parse(place_query)
    
#    print('******************* PARSED QUERY ******************* ')
#    print(q)
    
    search_place_ids = []
    search_place_owners = []
        
    with place_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'
               
        
        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_place_ids.append(str(results[i]['PlaceID']))
                search_place_owners.append(str(results[i]['Owner']))
    place_results = pd.DataFrame(columns = ['PlaceID', 'Owner', 'Score'])
    place_results['PlaceID'] = search_place_ids
    place_results['Owner'] = search_place_owners
    place_similarity = pd.read_csv('place_similarity.csv')
    if user_id in place_similarity.columns:
        for i in xrange(place_results.shape[0]):
            j = place_results['PlaceID'][i]
            k = place_similarity[place_similarity.PlaceID == j][user_id].values
            place_results['Score'][i] = k
            place_results = place_results.sort_values(['Score'], ascending=[0]).reset_index(drop = True )
        diff = datetime.now() - time
        print('Time taken to retreive results for place: ' + str(diff.seconds  ) + ' seconds')
        return list(place_results['PlaceID'][:].values), list(place_results['Owner'][:].values), list(place_results['Score'][:].values)
    else:
        diff = datetime.now() - time
        print('Time taken to retreive results for place: ' + str(diff.seconds  ) + ' seconds')
        return search_place_ids[:10], search_place_owners[:10], None

def place_owner_int(x):
    x = str(x)
    if '|' in x:
        return x
    elif x == 'i':
        return x
    else:
        #return str(int(float(x)))
        #print "*********************** Type value of x *********************" 
        #print type(x)
        return x

"""
SHARE FILES
"""	

def remove_deleted_shares(share_details):
    deleted_shares = []
    for i in xrange(share_details.shape[0]):
        if pd.isnull(share_details['Owner'][i]):
            j = share_details['ShareID'][i]
            share_details = share_details[share_details.ShareID != j]
            deleted_shares.append(j)
    share_details = share_details.reset_index(drop=True)
    if len(deleted_shares) == 0:
        deleted_shares = None
    return share_details, deleted_shares

def read_files_share():
    share_details = pd.read_csv('share_file.csv', encoding = 'latin-1')
    share_details_old = None
    if os.path.exists('share_details.csv'):
        share_details_old = pd.read_csv('share_details.csv', encoding = 'latin-1')
        #print 'Share detail file exists. Reading file...'
    if os.path.exists('share_profile.csv'):
        share_profile = pd.read_csv('share_profile.csv', encoding = 'utf-8')
        #print 'Share Profile found. Updating file...'
    else:
        share_profile = None
        #print 'Warning: Share Profile not found in path. Creating new one...'
    return share_details, share_profile, share_details_old

def item_profile_share(input_file, output_file = None):
    input_file['Create_Date'] = pd.to_datetime(input_file['Create_Date'], format = '%Y-%m-%d')
    if output_file is None:
        output_file = create_item_profile_share(input_file)
    else:
        output_file = update_item_profile_share(input_file, output_file)
    return output_file

def update_item_profile_share(input_file, output_file):
    print('Updating share item profile...')
    time = datetime.now()
    profile_var = list(output_file.columns)
    shareid_list = list(output_file.ShareID)
    for i in xrange(0, input_file.shape[0]):
        if input_file['ShareID'][i] not in shareid_list and not pd.isnull(input_file['Create_Date'][i]):
            update_record = {}
            update_record['ShareID'] = input_file['ShareID'][i]
            car_cl = input_file['Car_Class'][i]
            try:
                car_cl_label = 'user_car_class_' + car_cl
            except:
                car_cl_label = 'user_car_class_' + str(car_cl)
            if car_cl_label not in profile_var:
                profile_var.append(car_cl_label)
                output_file[car_cl_label] = 0
            update_record[car_cl_label] = 1
            user_interest_list = input_file['Interests'][i]
            if pd.notnull(user_interest_list):
                user_interest_list = input_file['Interests'][i].split(',')
                user_interest_list = [j.replace(' ', '') for j in user_interest_list]
            
           
                for k in user_interest_list:
                    int_cl = k[:6]
                    int_cl_label = 'user_int_' + int_cl
                    if int_cl_label not in profile_var:
                        profile_var.append(int_cl_label)
                        output_file[int_cl_label] = 0
                    update_record[int_cl_label] = 1
                
            datediff = (date.today() - input_file['Create_Date'][i].date()).days
            if datediff == 0:
                update_record['create_today'] = 1
            elif datediff < 8:
                update_record['create_1week'] = 1
            elif datediff < 31:
                update_record['create_1month'] = 1
            elif datediff < 91:
                update_record['create_3month'] = 1
            else:
                update_record['create_old'] = 1
            Comment_Count = input_file['Comment_Count'][i]
            if Comment_Count == 0:
                update_record['comments_count_0'] = 1
            elif Comment_Count < 6:
                update_record['comments_count_5'] = 1
            elif Comment_Count < 21:
                update_record['comments_count_20'] = 1
            else:
                update_record['comments_count_more'] = 1
            Like_Count = input_file['Like_Count'][i]
            if Like_Count == 0:
                update_record['likes_count_0'] = 1
            elif Like_Count < 11:
                update_record['likes_count_10'] = 1
            elif Like_Count < 51:
                update_record['likes_count_50'] = 1
            else:
                update_record['likes_count_more'] = 1
            cit = input_file['City'][i]
            if cit not in profile_var:
                profile_var.append(cit)
                output_file[cit] = 0
            update_record[cit] = 1
            re_count = input_file['Reshare_Count'][i]
            if re_count == 0:
                update_record['reshare_0'] = 1
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 0
            elif re_count <= 3:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 1
                update_record['reshare_m'] = 0
            else:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 1
            update_record['placeimg_yes_no'] = input_file['Placeimg'][i]
            st = 'sharetype_' + input_file['Sharetype'][i]
            update_record[st] = 1
            #stl = len(str(input_file['Sharetext'][i]))
            if input_file['Sharetext'][i] == 'nan':
                stl = 0
            elif pd.isnull(input_file['Sharetext'][i]):
                stl = 0
            else:
                stl = len(input_file['Sharetext'][i].encode('utf-8'))
            if stl < 26:
                update_record['sharetext_len_sh'] = 1
            elif stl < 141:
                update_record['sharetext_len_me'] = 1
            else:
                update_record['sharetext_len_lo'] = 1
            update_list = []
            for m in profile_var:
                if m in update_record.keys():
                    update_list.append(update_record[m])
                else:
                    update_list.append(0)
            output_file.loc[len(output_file)] = update_list
        else:
            co_count = input_file['Comment_Count'][i]
            li_count = input_file['Like_Count'][i]
            re_count = input_file['Reshare_Count'][i]
            if co_count == 0:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 0
            elif co_count < 6:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 0
            elif co_count < 21:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 0
            else:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 1
            if li_count == 0:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 0
            elif li_count < 11:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 0
            elif li_count < 51:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 0
            else:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 1
            if re_count == 0:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_0'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_3'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_m'] = 0
                
            elif re_count <= 3:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_3'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_m'] = 0
            else:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_3'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_m'] = 1
    for i in xrange(input_file.shape[0]):
        if pd.isnull(input_file['Owner'][i]):
            j = input_file['ShareID'][i]
            output_file = output_file[output_file.ShareID != j]
    diff = datetime.now() - time
    print('Time taken to update share item profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file
                                    
def create_item_profile_share(input_file):
    print('Creating share item profile...')
    time = datetime.now()
    
    profile_var = []
    profile_var.append('ShareID')
    car_class_list = list(input_file['Car_Class'].unique())
    car_class_list1 = []
    for carc in car_class_list:
        try:
            car_class_list1.append('user_car_class_' + carc)
        except:
            car_class_list1.append('user_car_class_' + str(carc))
    car_class_list = car_class_list1[:]
    if 'user_car_class_nan' not in car_class_list:
        car_class_list.append('user_car_class_nan')
    
    interest_list = list(input_file['Interests'].unique())
    int_list = []
    for x in interest_list:
        if pd.notnull(x):
            for y in x.split(','):
                temp_int  = 'user_int_' + y.replace(' ', '')[:6]
                if temp_int not in int_list:
                    int_list.append(temp_int)
        
    create_list = ['create_today', 'create_1week', 'create_1month', 'create_3month', 'create_old']
    comment_list = ['comments_count_0', 'comments_count_5', 'comments_count_20', 'comments_count_more']
    like_list = ['likes_count_0', 'likes_count_10', 'likes_count_50', 'likes_count_more']
    city_list = list(input_file['City'].unique())
    
    reshare_list = ['reshare_0', 'reshare_3', 'reshare_m']
    share_list = ['placeimg_yes_no', 'sharetype_video', 'sharetype_image', 'sharetype_text', 'sharetext_len_sh', 'sharetext_len_me', 'sharetext_len_lo']
    profile_var = profile_var + car_class_list + int_list + create_list + comment_list + like_list + city_list + reshare_list + share_list
    output_file = pd.DataFrame(columns = profile_var)
    for i in xrange(0, input_file.shape[0]):
        update_record = {}
        update_record['ShareID'] = input_file['ShareID'][i]
        car_cl = str(input_file['Car_Class'][i])
        car_cl_label = 'user_car_class_' + car_cl
        update_record[car_cl_label] = 1
        user_interest_list = input_file['Interests'][i]
        if pd.notnull(user_interest_list):
            int_lis = user_interest_list.split(',')
            int_list = ['user_int_' + il.replace(' ','')[:6] for il in int_lis]
        for i_l in int_list:
            update_record[il] = 1

        datediff = (date.today() - input_file['Create_Date'][i].date()).days
        if datediff == 0:
            update_record['create_today'] = 1
        elif datediff < 8:
            update_record['create_1week'] = 1
        elif datediff < 31:
            update_record['create_1month'] = 1
        elif datediff < 91:
            update_record['create_3month'] = 1
        else:
            update_record['create_old'] = 1
        Comment_Count = input_file['Comment_Count'][i]
        if Comment_Count == 0:
            update_record['comments_count_0'] = 1
        elif Comment_Count < 6:
            update_record['comments_count_5'] = 1
        elif Comment_Count < 21:
            update_record['comments_count_20'] = 1
        else:
            update_record['comments_count_more'] = 1
        Like_Count = input_file['Like_Count'][i]
        if Like_Count == 0:
            update_record['likes_count_0'] = 1
        elif Like_Count < 11:
            update_record['likes_count_10'] = 1
        elif Like_Count < 51:
            update_record['likes_count_50'] = 1
        else:
            update_record['likes_count_more'] = 1
        update_record[input_file['City'][i]] = 1
        reshare_count = input_file['Reshare_Count'][i]
        if reshare_count == 0:
            update_record['reshare_0'] = 1
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 0
        elif reshare_count <= 3:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 1
            update_record['reshare_m'] = 0
        else:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 1
        update_record['placeimg_yes_no'] = input_file['Placeimg'][i]
        st = 'sharetype_' + input_file['Sharetype'][i]
        update_record[st] = 1
        #stl = len(str(input_file['Sharetext'][i].decode('latin-1')))
        if input_file['Sharetext'][i] == 'nan':
            stl = 0
        elif pd.isnull(input_file['Sharetext'][i]):
            stl = 0
        else:
            stl = len(input_file['Sharetext'][i].encode('utf-8'))
        if stl < 26:
            update_record['sharetext_len_sh'] = 1
        elif stl < 141:
            update_record['sharetext_len_me'] = 1
        else:
            update_record['sharetext_len_lo'] = 1
        update_list = []
        for m in profile_var:
            if m in update_record.keys():
                update_list.append(update_record[m])
            else:
                update_list.append(0)
        output_file.loc[len(output_file)] = update_list
    
    diff = datetime.now() - time
    print('Time taken to create share item profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file

def create_flat_share_fn(share_details_flat, deleted_shares = None):
    print('Creating share flat file...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    
    share_details_flat = share_details_flat.fillna('i')
    
    share_details_flat = share_details_flat.astype('unicode')
    
#    share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: replace_all(x))
#    share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['City'] = share_details_flat['City'].apply(lambda x: replace_all(x))
    share_details_flat['City'] = share_details_flat['City'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['Sharetext'] = share_details_flat['Sharetext'].apply(lambda x: replace_all(x))
    share_details_flat['Sharetext'] = share_details_flat['Sharetext'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['CommentList'] = share_details_flat['CommentList'].apply(lambda x: replace_all(x))
    share_details_flat['CommentList'] = share_details_flat['CommentList'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['PlaceAddr'] = share_details_flat['PlaceAddr'].apply(lambda x: replace_all(x))
    share_details_flat['PlaceAddr'] = share_details_flat['PlaceAddr'].apply(lambda x: str(x.encode('utf-8')))
    
    if os.path.exists('share_details_flat.csv'):
        share_details_flat_old = pd.read_csv('share_details_flat.csv', encoding = 'latin-1')
        share_details_flat_old = share_details_flat_old.fillna('i')
        
#        share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: replace_all(x))
#        share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['City'] = share_details_flat_old['City'].apply(lambda x: replace_all(x))
        share_details_flat_old['City'] = share_details_flat_old['City'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['Sharetext'] = share_details_flat_old['Sharetext'].apply(lambda x: replace_all(x))
        share_details_flat_old['Sharetext'] = share_details_flat_old['Sharetext'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['CommentList'] = share_details_flat_old['CommentList'].apply(lambda x: replace_all(x))
        share_details_flat_old['CommentList'] = share_details_flat_old['CommentList'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['PlaceAddr'] = share_details_flat_old['PlaceAddr'].apply(lambda x: replace_all(x))
        share_details_flat_old['PlaceAddr'] = share_details_flat_old['PlaceAddr'].apply(lambda x: str(x.encode('utf-8')))
        
        old_share_ids = list(share_details_flat_old['ShareID'])
        for i in xrange(share_details_flat.shape[0]):
            j = share_details_flat['ShareID'][i]
            if j in old_share_ids:
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'Sharetext'] = share_details_flat[share_details_flat.ShareID == j]['Sharetext'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'CommentList'] = share_details_flat[share_details_flat.ShareID == j]['CommentList'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'PlaceAddr'] = share_details_flat[share_details_flat.ShareID == j]['PlaceAddr'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'City'] = share_details_flat[share_details_flat.ShareID == j]['City'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'Owner'] = share_details_flat[share_details_flat.ShareID == j]['Owner'].values[0]
            else:
                share_details_flat_old.loc[len(share_details_flat_old)] = share_details_flat[share_details_flat.ShareID == j].values[0]
        if deleted_shares is not None:
            for del_sha in deleted_shares:
                share_details_flat_old = share_details_flat_old[share_details_flat_old.ShareID != del_sha]
        share_details_flat = share_details_flat_old.reset_index(drop=True)
    
    
    if os.path.exists("shareindex"):
        shutil.rmtree("shareindex")
    
    data_list = share_details_flat.values.tolist()
    collect_clean = []
    for items in data_list:
        bucket = []
        for text in items:
            clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
            bucket.append(clean_txt)
        collect_clean.append(bucket)
        
    column = share_details_flat.columns
    share_details_flat = pd.DataFrame(collect_clean,columns = column)    
    share_details_flat.to_csv('share_details_flat.csv', index = False, encoding = 'latin-1')
        
    schema_share = Schema(ShareID = ID(stored=True),
                          Sharetext = TEXT(field_boost=2.0, stored=True),
                          CommentList = TEXT(field_boost=1.0, stored=True),
                          PlaceAddr = TEXT(field_boost=1.0, stored=True),
                          City = TEXT(field_boost=1.0, stored=True),
                          Owner = KEYWORD(stored=True))
    if not os.path.exists("shareindex"):
        os.mkdir("shareindex")
    share_ix = create_in("shareindex", schema = schema_share)
    share_ix = open_dir("shareindex")
    share_writer = share_ix.writer()
    for val in collect_clean:
        share_writer.add_document(ShareID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                  Sharetext = unicode((str(val[1]) if ' ' in val[1] else val[1]), encoding="utf-8", errors="ignore"),
                                  CommentList = unicode((str(val[2]) if ' ' in val[2] else val[2]), encoding="utf-8", errors="ignore"),
                                  PlaceAddr = unicode((str(val[3]) if ' ' in val[3] else val[3]), encoding="utf-8", errors="ignore"),
                                  City = unicode((str(val[4]) if ' ' in val[4] else val[4]), encoding="utf-8", errors="ignore"),
                                  Owner = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"))
    share_writer.commit()
    diff = datetime.now() - time
    print('Time taken to create share flat file: ' + str(diff.seconds  ) + ' seconds')

def user_action_proc_share(share_details, share_details_old, deleted_shares = None):
    if share_details_old is not None:
        share_details1 = share_details_proc(share_details, share_details_old, deleted_shares)
        user_action = create_user_action_share(share_details1)
        return user_action, share_details1
    else:
        user_action = create_user_action_share(share_details)
        return user_action, share_details

def create_user_profile_share(user_action, share_profile, user_weights):
    print('Creating user share profile...')
    time = datetime.now()
    
    col_names = ['UserID'] + list(share_profile.columns[1:])
    user_profile_share = pd.DataFrame(columns = col_names)
    for i in xrange(user_action.shape[0]):
        k = user_action['UserID'][i]
        total_count = 0
        owns = str(user_action['Owner'][i]).split('|')
        likes = str(user_action['Likes'][i]).split('|')
        comments = str(user_action['Comments'][i]).split('|')
        
        total_count = len(owns) * user_weights[0] + len(likes) * user_weights[1] + len(comments) * user_weights[2]
        update_record = []
        update_record.append(k)
        summation = np.zeros((1, share_profile.shape[1]-1))[0]
        if owns is not None:
            for j in owns:
                if j not in ['None','nan']:
                    summation = summation + (share_profile[share_profile.ShareID == j]).values[0][1:] * user_weights[0]
        if likes is not None:
            for j in likes:
                if j not in ['None','nan']:
                    summation = summation + (share_profile[share_profile.ShareID == j]).values[0][1:] * user_weights[1]
        if comments is not None:
            for j in comments:
                if j not in ['None','nan']:
                    summation = summation + (share_profile[share_profile.ShareID == j]).values[0][1:] * user_weights[2]
        summation /= total_count
        update_record = update_record + list(summation)
        user_profile_share.loc[len(user_profile_share)] = update_record
    
    diff = datetime.now() - time
    print('Time taken to create user share profile: ' + str(diff.seconds  ) + ' seconds')
    return user_profile_share

def creat_share_similarity(share_profile, user_profile_share):
    print('Creating share similarity matrix...')
    time = datetime.now()
    
    col_names = ['ShareID'] + list(user_profile_share['UserID'])
    share_similarity = pd.DataFrame(columns = col_names)
    share_list = list(share_profile['ShareID'])
    for i in share_list:
        update_record = [i]
        for k, j in enumerate(col_names):
            if k != 0:
                list1 = list(user_profile_share[user_profile_share.UserID == j].values[0][1:])
                list2 = list(share_profile[share_profile.ShareID == i].values[0][1:])
                update_record.append(cos_sim(list1, list2))
        share_similarity.loc[len(share_similarity)] = update_record
    diff = datetime.now() - time
    print('Time taken to create share similarity matrix: ' + str(diff.seconds  ) + ' seconds')
    return share_similarity

def share_details_proc(share_details, share_details_old, deleted_shares = None):
    share_list_old = list(share_details_old['ShareID'])
    share_list_new = list(share_details['ShareID'])
    for i,j in enumerate(share_list_new):
        if j in share_list_old:
            if pd.isnull(share_details['Owner'][i]):
                share_details_old = share_details_old[share_details_old.ShareID != j]
            elif str(share_details['Owner'][i]).split('|') is None:
                share_details_old = share_details_old[share_details_old.ShareID != j]
            else:
                share_details_old.loc[share_details_old.ShareID == j, 'Owner'] = share_details[share_details.ShareID == j]['Owner'].values[0]
                share_details_old.loc[share_details_old.ShareID == j, 'Likes'] = share_details[share_details.ShareID == j]['Likes'].values[0]
                share_details_old.loc[share_details_old.ShareID == j, 'Comments'] = share_details[share_details.ShareID == j]['Comments'].values[0]
        else:
            share_details_old.loc[len(share_details_old)] = share_details[share_details.ShareID == j].values[0]
    if deleted_shares is not None:
        for del_shar in deleted_shares:
            share_details_old = share_details_old[share_details_old.ShareID != del_shar]
    share_details_old = share_details_old.reset_index(drop=True)
    return share_details_old

def create_user_action_share(share_details):
    print('Creating share user action...')
    time = datetime.now()
    
    ''' Converting a column to string if its data type is float/int type '''
    com_list = share_details['Comments'].tolist()
    com_list = float_to_string(com_list)
    
    like_list = share_details['Likes'].tolist()
    like_list = float_to_string(like_list)
    #trip_details.drop('Comments', axis=1, inplace=True)
        
    share_details['Comments'] = pd.DataFrame(com_list, columns=['Comments'])
    share_details['Likes'] = pd.DataFrame(like_list, columns=['Likes'])
    
    user_action = pd.DataFrame(columns = ['UserID', 'Owner', 'Likes', 'Comments'])
    user_list = []
    
    for i in xrange(share_details.shape[0]):
        u_list = []
        if pd.notnull(share_details['Owner'][i]):
            owns = str(share_details['Owner'][i]).split('|')
            if owns is not None:
                owns = [j.replace(' ','') for j in owns]
                owns = [j for j in owns if len(j) > 0]
        if owns is not None:
            for j in owns:
                if j is not None:
                    u_list.append(j)
        likes = None
        if pd.notnull(share_details['Likes'][i]):
            likes = str(share_details['Likes'][i]).split('|')
            if likes is not None:
                likes = [j.replace(' ','') for j in likes]
                likes = [j for j in likes if len(j) > 0]
        if likes is not None:
            for j in likes:
                if j is not None:
                    u_list.append(j)
        comments = None
        if pd.notnull(share_details['Comments'][i]):
            comments = str(share_details['Comments'][i]).split('|')
            if comments is not None:
                comments = [j.replace(' ','') for j in comments]
                comments = [j for j in comments if len(j) > 0]
        if comments is not None:
            for j in comments:
                if j is not None:
                    u_list.append(j)
        u_list = list(set(u_list))
        for k in u_list:
            if k not in user_list:
                user_list.append(k)
    for i in user_list:
        update_record = []
        update_record.append(i)
        ow = None
        li = None
        co = None
        for j in xrange(share_details.shape[0]):
            if i in str(share_details.Owner[j]):
                if ow is not None:
                    ow = ow + '|' + share_details.ShareID[j]
                else:
                    ow = share_details.ShareID[j]
            if i in str(share_details.Likes[j]):
                if li is not None:
                    li = li + '|' + share_details.ShareID[j]
                else:
                    li = share_details.ShareID[j]
            if i in str(share_details.Comments[j]):
                if co is not None:
                    co = co + '|' + share_details.ShareID[j]
                else:
                    co = share_details.ShareID[j]
        update_record.append(ow)
        update_record.append(li)
        update_record.append(co)
        user_action.loc[len(user_action)] = update_record
    diff = datetime.now() - time
    print('Time taken to create share user action: ' + str(diff.seconds  ) + ' seconds')
    return user_action 

def search_query_share(share_query, user_id):
    print('Processing users search query for share...')
    time = datetime.now()
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    share_ix = open_dir("shareindex")
    multi_query_share = MultifieldParser(["ShareID","Sharetext", "CommentList", "PlaceAddr", "City"], schema = share_ix.schema, group = OrGroup)
    
    multi_query_share.add_plugin(FuzzyTermPlugin())
    
#    print('Printing raw search string from user...')
#    print(share_query)
#    print(type(share_query))
    
    share_query = unicode(str(share_query), encoding="utf-8", errors="ignore")
    share_query = str(replace_all(share_query)).lower()
    
#    print('Printing clean search string from user...')
#    print(share_query)
#    print(type(share_query))
    
    share_query = ' '.join([word + ('~2') for word in share_query.split() if word not in stop_words and len(word) > 0])
    #print(share_query)
    
    q = multi_query_share.parse(share_query)
    
#    print('******************* PARSED QUERY ******************* ')
#    print(q)
    
    #share_query = unicode(share_query)
    #share_query = share_query.lower()
#    share_query = re.findall('[a-z]+', share_query.lower())
#    
#    
#    share_query = ' '.join([word for word in share_query if word not in stop_words])
#    
#    q = multi_query_share.parse(share_query)
    
    search_share_ids = []
    search_share_owners = []
    
        
    with share_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'
        ##print results[0]["ShareID"]+' - ' + results[0]["Sharetext"]+' - '+results[0]["CommentList"]+' - '+results[0]["PlaceAddr"]
        
        
        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_share_ids.append(str(results[i]['ShareID']))
                search_share_owners.append(str(results[i]['Owner']))
    share_results = pd.DataFrame(columns = ['ShareID', 'Owner', 'Score'])
    share_results['ShareID'] = search_share_ids
    share_results['Owner'] = search_share_owners
    share_similarity = pd.read_csv('share_similarity.csv')
    if user_id in share_similarity.columns:
        for i in xrange(share_results.shape[0]):
            j = share_results['ShareID'][i]
            k = share_similarity[share_similarity.ShareID == j][user_id].values
            share_results['Score'][i] = k
            share_results = share_results.sort_values(['Score'], ascending=[0]).reset_index(drop = True )
        
        diff = datetime.now() - time
        print('Time taken to retreive share results: ' + str(diff.seconds  ) + ' seconds')
        return list(share_results['ShareID'][:].values), list(share_results['Owner'][:].values), list(share_results['Score'][:].values)
    else:
        
        diff = datetime.now() - time
        print('Time taken to retreive share results: ' + str(diff.seconds  ) + ' seconds')
        return search_share_ids[:10], search_share_owners[:10], None

"""
USER FILES
"""

def create_flat_user_fn():
    print('Creating user flat file...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    user_details_flat = pd.read_csv('user_file.csv', encoding = 'latin-1')
    
    user_details_flat = user_details_flat.fillna('i')
    
    user_details_flat['UserName_Middle'] = user_details_flat['UserName_Middle'].apply(lambda x: replace_null(x))
    user_details_flat['UserName_Last'] = user_details_flat['UserName_Last'].apply(lambda x: replace_null(x))
    user_details_flat['UserID'] = user_details_flat['UserID'].astype('int')
    user_details_flat['UserID'] = user_details_flat['UserID'].astype('str')
    user_details_flat['UserID'] = user_details_flat['UserID'].apply(lambda x: 'u' + str(x) + 'u')
    user_details_flat['UserName_First'] = user_details_flat['UserName_First'].apply(lambda x: str(x.encode('utf-8')))
    user_details_flat['UserName_Last'] = user_details_flat['UserName_Last'].apply(lambda x: str(x.encode('utf-8')))
    user_details_flat['UserName_Middle'] = user_details_flat['UserName_Middle'].apply(lambda x: str(x.encode('utf-8')))
    user_details_flat['City'] = user_details_flat['City'].apply(lambda x: str(x.encode('utf-8')))
        
    if os.path.exists('user_details_flat.csv'):
        user_details_flat_old = pd.read_csv('user_details_flat.csv', encoding = 'latin-1')
        user_details_flat_old = user_details_flat_old.fillna('i')
        
        old_user_ids = list(user_details_flat_old['UserID'])
        
        for i in xrange(user_details_flat.shape[0]):
            j = str(user_details_flat['UserID'][i])
            
            if j in old_user_ids:
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'UserName_First'] = user_details_flat[user_details_flat.UserID == str(j)]['UserName_First'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'UserName_Last'] = user_details_flat[user_details_flat.UserID == str(j)]['UserName_Last'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'UserName_Middle'] = user_details_flat[user_details_flat.UserID == str(j)]['UserName_Middle'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'ScreenName'] = user_details_flat[user_details_flat.UserID == str(j)]['ScreenName'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'City'] = user_details_flat[user_details_flat.UserID == str(j)]['City'].values[0]

                
            else:
                user_details_flat_old.loc[len(user_details_flat_old)] = user_details_flat[user_details_flat.UserID == str(j)].values[0]
        
        
        user_details_flat_old = user_details_flat_old.dropna(axis = 0, subset = [['UserName_First']])
        
        user_details_flat = user_details_flat_old.reset_index(drop=True)
               
    
    user_details_flat.to_csv('user_details_flat.csv', index = False, encoding = 'latin-1')    
    if os.path.exists("userindex"):
        shutil.rmtree("userindex")
    data_list = user_details_flat.values.tolist()
    collect_clean = []
    
    for items in data_list:
        bucket = []
        for text in items:
            clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
            bucket.append(clean_txt)
        collect_clean.append(bucket)
    
    column = user_details_flat.columns
    user_details_flat = pd.DataFrame(collect_clean,columns = column)             
    user_details_flat.to_csv('user_details_flat.csv', index = False, encoding = 'latin-1')
            
    schema_user = Schema(UserID = ID(stored=True),
                          UserName_First = TEXT(field_boost=1.0, stored=True),
                          UserName_Last = TEXT(field_boost=1.0, stored=True),
                          UserName_Middle = TEXT(field_boost=1.0, stored=True),
                          ScreenName = TEXT(field_boost=1.0, stored=True),
                          City = TEXT(field_boost=1.0, stored=True))



    if not os.path.exists("userindex"):
        os.mkdir("userindex")
    user_ix = create_in("userindex", schema = schema_user)
    user_ix = open_dir("userindex")
    user_writer = user_ix.writer()
    for val in collect_clean:
        
        user_writer.add_document(UserID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                  UserName_First = unicode((str(val[1]) if ' ' in val[1] else val[1]), encoding="utf-8", errors="ignore"),
                                  UserName_Last = unicode((str(val[2]) if ' ' in val[2] else val[2]), encoding="utf-8", errors="ignore"),
                                  UserName_Middle = unicode((str(val[3]) if ' ' in val[3] else val[3]), encoding="utf-8", errors="ignore"),
                                  ScreenName = unicode((str(val[4]) if ' ' in val[4] else val[4]), encoding="utf-8", errors="ignore"),
                                  City = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"))
    user_writer.commit()

    diff = datetime.now() - time
    print('Time taken to create user flat file: ' + str(diff.seconds  ) + ' seconds')

def search_query_user_alone(user_query):
    print('Processing user search query for user...')
    time = datetime.now()
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    user_ix = open_dir("userindex")
    multi_query_user = MultifieldParser(["UserID","UserName_First", "UserName_Last", "UserName_Middle", "ScreenName", "City"], schema = user_ix.schema, group = OrGroup)
    #user_query = unicode(str(user_query))
    # user_query = user_query.lower()
    
    multi_query_user.add_plugin(FuzzyTermPlugin())
    
#    print('Printing raw search string from user...')
#    print(user_query)
#    print(type(user_query))
    
    user_query = unicode(str(user_query), encoding="utf-8", errors="ignore")
    user_query = str(replace_all(user_query)).lower()
    
#    print('Printing clean search string from user...')
#    print(place_query)
#    print(type(place_query))
    
    user_query = ' '.join([word + ('~2') for word in user_query.split() if word not in stop_words and len(word) > 0])
#    print(user_query)
    
    q = multi_query_user.parse(user_query)
    
#    user_query = re.findall('[a-z0-9]+', user_query.lower())
#    user_query = ' '.join([word for word in user_query if word not in stop_words])
#    q = multi_query_user.parse(user_query)
 
    search_user_ids = []
        
    with user_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'
        
               
        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_user_ids.append(str(results[i]['UserID']))
                
    search_user_ids = [res[1:-1] for res in search_user_ids]
    

    diff = datetime.now() - time
    print('Time taken to retreive user results: ' + str(diff.seconds  ) + ' seconds')
    return search_user_ids

def f7(seq):
    new_seq = []
    for elem in seq:
        if elem not in new_seq:
            new_seq.append(elem)
    return new_seq

def search_query_all(query, user_id):
    trip_results, trip_owners, trip_scores = search_query_trip(query, user_id)
    place_results, place_owners, place_scores = search_query_place(query, user_id)
    share_results, share_owners, share_scores = search_query_share(query, user_id)
    user_results_alone = search_query_user_alone(query)

    user_id_list = []
    score_list = []
    user_id_list = user_id_list + trip_owners
    user_id_list = user_id_list + place_owners
    user_id_list = user_id_list + share_owners
    if trip_scores is None:
        score_list = score_list + list(np.zeros(len(trip_results)))
    else:
        score_list = score_list + trip_scores
    if place_scores is None:
        score_list = score_list + list(np.zeros(len(place_results)))
    else:
        score_list = score_list + place_scores
    if share_scores is None:
        score_list = score_list + list(np.zeros(len(share_results)))
    else:
        score_list = score_list + share_scores
    new_score_list = []
    new_user_id_list = []
    for numb, userid in enumerate(user_id_list):
        if userid != 'nan':
            new_list = userid.split('|')
            
            for new_entry in new_list:
                if len(new_entry) > 0:
                    new_user_id_list.append(str(int(float(new_entry))))
                    new_score_list.append(score_list[numb])
                
    if len(new_score_list) > 0:
        user_results = [list(x) for x in zip(*sorted(zip(new_score_list, new_user_id_list), key=lambda pair: pair[0]))][1]
    
        user_results = user_results_alone + user_results
        user_results = f7(user_results)
        if user_id in user_results:
            user_results.remove(user_id)
            if len(user_results) > 10:
                user_results = user_results[:10]
    else:
        user_results = user_results_alone
    final_user_results = []
    for us in user_results:
        
        if pd.notnull(us):
            user_l = us.split('|')
            new_user_l = []
            for cu in user_l:
                if cu != '':
                    new_user_l.append(cu)
            #user_l = [str(int(float(e))) for e in user_l]
            final_user_results = final_user_results + new_user_l
    return trip_results, place_results, share_results, final_user_results    

def replace_null(x):
    if pd.isnull(x):
        return ' ' 
    else:
        return x
    
if __name__ == "__main__":
    app.run()
