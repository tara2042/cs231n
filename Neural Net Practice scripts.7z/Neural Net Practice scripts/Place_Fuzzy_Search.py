# -*- coding: utf-8 -*-
"""
Created on Wed Apr 12 16:28:09 2017

@author: tarachy

"""

# Load Libraries
import web
#import xml.etree.ElementTree as ET
import os
import pandas as pd
from nltk.corpus import stopwords
import re
import string
#from whoosh.analysis import StemmingAnalyzer
from whoosh.index import create_in
from whoosh.fields import Schema, ID, KEYWORD, TEXT
from whoosh.qparser import MultifieldParser, OrGroup, FuzzyTermPlugin, AndGroup
from whoosh.index import open_dir

from datetime import date
import numpy as np

#from math import isnan
import math
from math import sqrt

import shutil


# Define urls (to be used in web service)
urls = (
    '/batch', 'create_flat_files',
    '/places/(.*)', 'search_place',
)
  
app = web.application(urls, globals())

# Define classes

class create_flat_files(object):
    
    def GET(self):
        batch_proc()    
    
    
class search_place(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        place_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        place_query = place_query.split(' ')
        place_query_1 = [i.encode('latin-1') for i in place_query]
        place_query = ' '.join(place_query_1)
        
        self.place_query = place_query
        
        return search_query_place(place_query, user_id)[0]

#Stadtbücherei
# Replacing all special characters with user defined
def replace_all(text):
    reps = {u'ö':'oe', u'ß':'ss', u'ß':'ss', u'ü':'ue', u'ä':'ae', u'Å':'ae', u'é':'e', u'Ä':'ae', u'Ö':'oe', u'Ü':'ue', u',':' ',  u'|':' ', u'-':' '}
    for i, j in reps.iteritems():
        #print('******** printing raw search text *************')
        #print(text)
        #print(type(text))
        #text = unicode(text, encoding="utf-8", errors="ignore")
        text = text.replace(i, j)
        #print('******** printing clean search text *************')
        #print(text)
        
    return text

def square_rooted(x): 
    return round(sqrt(sum([a*a for a in x])),3)
 
def cos_sim(x,y):
    numerator = sum(a*b for a,b in zip(x,y))
    denominator = square_rooted(x)*square_rooted(y)
    return round(numerator/float(denominator + 1e-11),4)

## Converting floating/nan User Ids to string
def float_to_string(x):
    cln_lst = []
    for i in x:
        if type(i) == float:
            if not math.isnan(i):
                val = str(int(float(i)))
                cln_lst.append(val)
        else:
            cln_lst.append(i)
    return cln_lst

# Define all functions

def batch_proc():
    user_weights = [5.0, 1.0, 1.0]
    
    place_details, place_profile, place_details_old = read_files_place()
    
    place_profile = item_profile_place(input_file = place_details, output_file = place_profile)
    #print 'Processed Place Profile. Saving file in path...'
    place_profile.to_csv('place_profile.csv', index = False, encoding = 'utf-8')
    place_details, deleted_places = remove_deleted_places(place_details)
    place_details_flat = place_details[['PlaceID', 'Place_Name', 'City', 'Country', 'District', 'Add1', 'State', 'Street', 'Detail_Desc', 'Info_Decor', 'Info_Limit', 'Info_Perm', 'Tags', 'CommentList', 'Owner']]
    create_flat_place_fn(place_details_flat, deleted_places)
    place_details = place_details[['PlaceID', 'Owner', 'Likes', 'Comments']]
    user_action_place, place_details = user_action_proc_place(place_details, place_details_old, deleted_places)
    #print 'Processed place details. Saving file in path...'
    place_details.to_csv('place_details.csv', index = False, encoding = 'latin-1')
    #print 'Processed user actions for place. Saving file in path...'
    user_action_place.to_csv('user_action_place.csv', index = False, encoding = 'utf-8')
    user_profile_place = create_user_profile_place(user_action_place, place_profile, user_weights)
    user_profile_place.to_csv('user_profile_place.csv', index = False, encoding = 'utf-8')
    place_similarity = creat_place_similarity(place_profile, user_profile_place)
    place_similarity.to_csv('place_similarity.csv', index = False)

"""
PLACE FILES
"""
def remove_deleted_places(place_details):
    deleted_places = []
    for i in xrange(place_details.shape[0]):
        if pd.isnull(place_details['Place_Name'][i]):
            j = place_details['PlaceID'][i]
            place_details = place_details[place_details.PlaceID != j]
            deleted_places.append(j)
    place_details = place_details.reset_index(drop=True)
    if len(deleted_places) == 0:
        deleted_places = None
    return place_details, deleted_places

def read_files_place():
    place_details = pd.read_csv('place_file.csv', encoding = 'latin-1')
    place_details_old = None
    if os.path.exists('place_details.csv'):
        place_details_old = pd.read_csv('place_details.csv', encoding = 'latin-1')
        #print 'Place detail file exists. Reading file...'
    if os.path.exists('place_profile.csv'):
        place_profile = pd.read_csv('place_profile.csv', encoding = 'utf-8')
        #print 'Place Profile found. Updating file...'
    else:
        place_profile = None
        #print 'Warning: Place Profile not found in path. Creating new one...'
    return place_details, place_profile, place_details_old

def item_profile_place(input_file, output_file = None):
    input_file['Create_Date'] = pd.to_datetime(input_file['Create_Date'], format = '%Y-%m-%d')
    if output_file is None:
        output_file = create_item_profile_place(input_file)
    else:
        output_file = update_item_profile_place(input_file, output_file)
    return output_file

def update_item_profile_place(input_file, output_file):
    
    profile_var = list(output_file.columns)
    placeid_list = list(output_file.PlaceID)
    for i in xrange(0, input_file.shape[0]):
        if input_file['PlaceID'][i] not in placeid_list and not pd.isnull(input_file['Create_Date'][i]):
            update_record = {}
            update_record['PlaceID'] = input_file['PlaceID'][i]
            Comment_Count = input_file['Comment_Count'][i]
            if Comment_Count == 0:
                update_record['comments_count_0'] = 1
            elif Comment_Count < 6:
                update_record['comments_count_5'] = 1
            elif Comment_Count < 21:
                update_record['comments_count_20'] = 1
            else:
                update_record['comments_count_more'] = 1
            Like_Count = input_file['Like_Count'][i]
            if Like_Count == 0:
                update_record['likes_count_0'] = 1
            elif Like_Count < 11:
                update_record['likes_count_10'] = 1
            elif Like_Count < 51:
                update_record['likes_count_50'] = 1
            else:
                update_record['likes_count_more'] = 1
            re_count = input_file['Reshare_Count'][i]
            if re_count == 0:
                update_record['reshare_0'] = 1
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 0
            elif re_count <= 3:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 1
                update_record['reshare_m'] = 0
            else:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 1
            category = input_file['Category'][i]
            if pd.notnull(category):
                category_label = 'cat_' + category
                if category_label not in profile_var:
                    profile_var.append(category_label)
                    output_file[category_label] = 0
            else:
                category_label = 'cat_nan'
            update_record[category_label] = 1
            city = input_file['City'][i]
            if pd.notnull(city):
                city_label = 'city_' + city
                if city_label not in profile_var:
                    profile_var.append(city_label)
                    output_file[city_label] = 0
            else:
                city_label = 'city_nan'
            update_record[city_label] = 1
            subcategory = input_file['Subcategory'][i]
            if pd.notnull(subcategory):
                subcat_label = 'sub_' + subcategory
                if subcat_label not in profile_var:
                    profile_var.append(subcat_label)
                    output_file[subcat_label] = 0
            else:
                subcat_label = 'sub_nan'
            update_record[subcat_label] = 1
            
            email_check = input_file['Contact_Email'][i]
            if pd.isnull(email_check):
                update_record['email_yes_no'] = 0
            else:
                update_record['email_yes_no'] = 1
            
            phone_check = input_file['Phone'][i]
            if pd.isnull(phone_check):
                update_record['phone_yes_no'] = 0
            else:
                update_record['phone_yes_no'] = 1
            
            website_check = input_file['Website'][i]
            if pd.isnull(website_check):
                update_record['website_yes_no'] = 0
            else:
                update_record['website_yes_no'] = 1
            
            update_record['placeimg_yes_no'] = input_file['placeimg_yes_no'][i]
            
            update_list = []
            for m in profile_var:
                if m in update_record.keys():
                    update_list.append(update_record[m])
                else:
                    update_list.append(0)
            output_file.loc[len(output_file)] = update_list
        else:
            co_count = input_file['Comment_Count'][i]
            li_count = input_file['Like_Count'][i]
            re_count = input_file['Reshare_Count'][i]
            placeimg = input_file['placeimg_yes_no'][i]
#            website = input_file['Website'][i]
#            phone = input_file['Phone'][i]
#            email = input_file['Contact_Email'][i]
            category = input_file['Category'][i]
            subcategory = input_file['Subcategory'][i]
            city = input_file['City'][i]
            
            if pd.notnull(city):            
                city_label = 'city_' + city
                if city_label not in profile_var:
                    profile_var.append(city_label)
                    output_file[city_label] = 0
            else:
                city_label = 'city_nan'
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], city_label] = 1
            
            if pd.notnull(category): 
                cat_label = 'cat_' + category
                if cat_label not in profile_var:
                    profile_var.append(cat_label)
                    output_file[cat_label] = 0
            else:
                cat_label = 'cat_nan'
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], cat_label] = 1
            
            if pd.notnull(subcategory): 
                sub_label = 'sub_' + subcategory
                if sub_label not in profile_var:
                    profile_var.append(sub_label)
                    output_file[sub_label] = 0
            else:
                sub_label = 'sub_nan'
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], sub_label] = 1
                              
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'placeimg_yes_no'] = placeimg
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'website_yes_no'] = output_file['website_yes_no'][i]
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'phone_yes_no'] = output_file['phone_yes_no'][i]
            output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'email_yes_no'] = output_file['email_yes_no'][i]
            
            if co_count == 0:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 0
            elif co_count < 6:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 0
            elif co_count < 21:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 0
            else:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'comments_count_more'] = 1
            if li_count == 0:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 0
            elif li_count < 11:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 0
            elif li_count < 51:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 0
            else:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'likes_count_more'] = 1
            if re_count == 0:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_0'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_3'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_m'] = 0
                
            elif re_count <= 3:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_3'] = 1
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_m'] = 0
            else:
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_0'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_3'] = 0
                output_file.ix[output_file.PlaceID == input_file.PlaceID[i], 'reshare_m'] = 1

    for i in xrange(input_file.shape[0]):
        if pd.isnull(input_file['Place_Name'][i]):
            j = input_file['PlaceID'][i]
            output_file = output_file[output_file.PlaceID != j]
    return output_file

def create_item_profile_place(input_file):
    
    profile_var = []
    profile_var.append('PlaceID')
    create_list = ['create_today', 'create_1week', 'create_1month', 'create_3month', 'create_old']
    city_list = list(input_file['City'].unique())
    city_list1 = []
    for cit in city_list:
        try:
            city_list1.append('city_' + cit)
        except:
            city_list1.append('city_' + str(cit))
    city_list = city_list1[:]
    if 'city_nan' not in city_list:
        city_list.append('city_nan')
    category_list = list(input_file['Category'].unique())
    category_list1 = []
    for cat in category_list:
        try:
            category_list1.append('cat_' + cat)
        except:
            category_list1.append('cat_' + str(cat))
    category_list = category_list1[:]
    if 'cat_nan' not in category_list:
        category_list.append('cat_nan')
    comment_list = ['comments_count_0', 'comments_count_5', 'comments_count_20', 'comments_count_more']
    profile_var.append('email_yes_no')
    profile_var.append('phone_yes_no')
    profile_var.append('website_yes_no')
    like_list = ['likes_count_0', 'likes_count_10', 'likes_count_50', 'likes_count_more']
    profile_var.append('placeimg_yes_no')
    reshare_list = ['reshare_0', 'reshare_3', 'reshare_m']
    subcat_list = list(input_file['Subcategory'].unique())
    subcat_list1 = []
    for sub in subcat_list:
        try:
            subcat_list1.append('sub_' + sub)
        except:
            subcat_list1.append('sub_' + str(sub))
    subcat_list = subcat_list1[:]
    if 'sub_nan' not in subcat_list:
        subcat_list.append('sub_nan')

    profile_var = profile_var + create_list + city_list + category_list + comment_list + like_list + reshare_list + subcat_list
    output_file = pd.DataFrame(columns = profile_var)
    for i in xrange(0, input_file.shape[0]):
        update_record = {}
        update_record['PlaceID'] = input_file['PlaceID'][i]
        datediff = (date.today() - input_file['Create_Date'][i].date()).days
        if datediff == 0:
            update_record['create_today'] = 1
        elif datediff < 8:
            update_record['create_1week'] = 1
        elif datediff < 31:
            update_record['create_1month'] = 1
        elif datediff < 91:
            update_record['create_3month'] = 1
        else:
            update_record['create_old'] = 1
        try:
            city = 'city_' + input_file['City'][i]
        except:
            city = 'city_' + str(input_file['City'][i])
        update_record[city] = 1
        try:
            category = 'cat_' + input_file['Category'][i]
        except:
            category = 'cat_' + str(input_file['Category'][i])
        update_record[category] = 1
        Comment_Count = input_file['Comment_Count'][i]
        if Comment_Count == 0:
            update_record['comments_count_0'] = 1
        elif Comment_Count < 6:
            update_record['comments_count_5'] = 1
        elif Comment_Count < 21:
            update_record['comments_count_20'] = 1
        else:
            update_record['comments_count_more'] = 1
        
        email_check = input_file['Contact_Email'][i]
        #print('************* #print email ****************')
        #print(email_check)
        #print(type(email_check))
        if pd.isnull(email_check):
            update_record['email_yes_no'] = 0
        else:
            update_record['email_yes_no'] = 1
        
        phone_check = input_file['Phone'][i]
        if pd.isnull(phone_check):
            update_record['phone_yes_no'] = 0
        else:
            update_record['phone_yes_no'] = 1
        
        website_check = input_file['Website'][i]
        if pd.isnull(website_check):
            update_record['website_yes_no'] = 0
        else:
            update_record['website_yes_no'] = 1
        
        update_record['placeimg_yes_no'] = input_file['placeimg_yes_no'][i]

        
        Like_Count = input_file['Like_Count'][i]
        if Like_Count == 0:
            update_record['likes_count_0'] = 1
        elif Like_Count < 11:
            update_record['likes_count_10'] = 1
        elif Like_Count < 51:
            update_record['likes_count_50'] = 1
        else:
            update_record['likes_count_more'] = 1
        reshare_count = input_file['Reshare_Count'][i]
        if reshare_count == 0:
            update_record['reshare_0'] = 1
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 0
        elif reshare_count <= 3:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 1
            update_record['reshare_m'] = 0
        else:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 1
        try:
            subcat = 'sub_' + input_file['Subcategory'][i]
        except:
            subcat = 'sub_' + str(input_file['Subcategory'][i])
        update_record[subcat] = 1

        update_list = []
        for m in profile_var:
            if m in update_record.keys():
                update_list.append(update_record[m])
            else:
                update_list.append(0)
        output_file.loc[len(output_file)] = update_list
    return output_file

def create_flat_place_fn(place_details_flat, deleted_places = None):
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    
    place_details_flat = place_details_flat.fillna('i')
    #place_details_flat = place_details_flat.astype('unicode')

    place_details_flat['Place_Name'] = place_details_flat['Place_Name'].apply(lambda x: replace_all(x))
    place_details_flat['Place_Name'] = place_details_flat['Place_Name'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['City'] = place_details_flat['City'].apply(lambda x: replace_all(x))
    place_details_flat['City'] = place_details_flat['City'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Country'] = place_details_flat['Country'].apply(lambda x: replace_all(x))
    place_details_flat['Country'] = place_details_flat['Country'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['District'] = place_details_flat['District'].apply(lambda x: replace_all(x))
    place_details_flat['District'] = place_details_flat['District'].apply(lambda x: str(x.encode('utf-8')))
        
    place_details_flat['Add1'] = place_details_flat['Add1'].apply(lambda x: replace_all(x))
    place_details_flat['Add1'] = place_details_flat['Add1'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['State'] = place_details_flat['State'].apply(lambda x: replace_all(x))
    place_details_flat['State'] = place_details_flat['State'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Street'] = place_details_flat['Street'].apply(lambda x: replace_all(x))
    place_details_flat['Street'] = place_details_flat['Street'].apply(lambda x: str(x.encode('utf-8')))
        
    place_details_flat['Detail_Desc'] = place_details_flat['Detail_Desc'].apply(lambda x: replace_all(x))
    place_details_flat['Detail_Desc'] = place_details_flat['Detail_Desc'].apply(lambda x: str(x.encode('utf8')))
    
    place_details_flat['Info_Decor'] = place_details_flat['Info_Decor'].apply(lambda x: replace_all(x))
    place_details_flat['Info_Decor'] = place_details_flat['Info_Decor'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Info_Limit'] = place_details_flat['Info_Limit'].apply(lambda x: replace_all(x))
    place_details_flat['Info_Limit'] = place_details_flat['Info_Limit'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Info_Perm'] = place_details_flat['Info_Perm'].apply(lambda x: replace_all(x))
    place_details_flat['Info_Perm'] = place_details_flat['Info_Perm'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['Tags'] = place_details_flat['Tags'].apply(lambda x: replace_all(x))
    place_details_flat['Tags'] = place_details_flat['Tags'].apply(lambda x: str(x.encode('utf-8')))
    
    place_details_flat['CommentList'] = place_details_flat['CommentList'].apply(lambda x: replace_all(x))
    place_details_flat['CommentList'] = place_details_flat['CommentList'].apply(lambda x: str(x.encode('utf-8')))
    
    if os.path.exists('place_details_flat.csv'):
        place_details_flat_old = pd.read_csv('place_details_flat.csv', encoding = 'latin-1')
        
        place_details_flat_old = place_details_flat_old.fillna('i')
        
        place_details_flat_old['Owner'] = place_details_flat_old['Owner'].apply(lambda x: place_owner_int(x))
        
        place_details_flat_old['Place_Name'] = place_details_flat_old['Place_Name'].apply(lambda x: replace_all(x))
        place_details_flat_old['Place_Name'] = place_details_flat_old['Place_Name'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['City'] = place_details_flat_old['City'].apply(lambda x: replace_all(x))
        place_details_flat_old['City'] = place_details_flat_old['City'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Country'] = place_details_flat_old['Country'].apply(lambda x: replace_all(x))
        place_details_flat_old['Country'] = place_details_flat_old['Country'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['District'] = place_details_flat_old['District'].apply(lambda x: replace_all(x))
        place_details_flat_old['District'] = place_details_flat_old['District'].apply(lambda x: str(x.encode('utf-8')))
                
        place_details_flat_old['Add1'] = place_details_flat_old['Add1'].apply(lambda x: replace_all(x))
        place_details_flat_old['Add1'] = place_details_flat_old['Add1'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['State'] = place_details_flat_old['State'].apply(lambda x: replace_all(x))
        place_details_flat_old['State'] = place_details_flat_old['State'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Street'] = place_details_flat_old['Street'].apply(lambda x: replace_all(x))
        place_details_flat_old['Street'] = place_details_flat_old['Street'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Detail_Desc'] = place_details_flat_old['Detail_Desc'].apply(lambda x: replace_all(x))
        place_details_flat_old['Detail_Desc'] = place_details_flat_old['Detail_Desc'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Info_Decor'] = place_details_flat_old['Info_Decor'].apply(lambda x: replace_all(x))
        place_details_flat_old['Info_Decor'] = place_details_flat_old['Info_Decor'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Info_Limit'] = place_details_flat_old['Info_Limit'].apply(lambda x: replace_all(x))
        place_details_flat_old['Info_Limit'] = place_details_flat_old['Info_Limit'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Info_Perm'] = place_details_flat_old['Info_Perm'].apply(lambda x: replace_all(x))
        place_details_flat_old['Info_Perm'] = place_details_flat_old['Info_Perm'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['Tags'] = place_details_flat_old['Tags'].apply(lambda x: replace_all(x))
        place_details_flat_old['Tags'] = place_details_flat_old['Tags'].apply(lambda x: str(x.encode('utf-8')))
        
        place_details_flat_old['CommentList'] = place_details_flat_old['CommentList'].apply(lambda x: replace_all(x))
        place_details_flat_old['CommentList'] = place_details_flat_old['CommentList'].apply(lambda x: str(x.encode('utf-8')))
        
        old_place_ids = list(place_details_flat_old['PlaceID'])
        for i in xrange(place_details_flat.shape[0]):
            j = place_details_flat['PlaceID'][i]
#            #print('********************************** place details flat *********************** ')
#            #print(j)
#            #print(type(j))
            if j in old_place_ids:
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Place_Name'] = place_details_flat[place_details_flat.PlaceID == j]['Place_Name'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'City'] = place_details_flat[place_details_flat.PlaceID == j]['City'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Country'] = place_details_flat[place_details_flat.PlaceID == j]['Country'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'District'] = place_details_flat[place_details_flat.PlaceID == j]['District'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Add1'] = place_details_flat[place_details_flat.PlaceID == j]['Add1'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'State'] = place_details_flat[place_details_flat.PlaceID == j]['State'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Street'] = place_details_flat[place_details_flat.PlaceID == j]['Street'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Detail_Desc'] = place_details_flat[place_details_flat.PlaceID == j]['Detail_Desc'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Info_Decor'] = place_details_flat[place_details_flat.PlaceID == j]['Info_Decor'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Info_Limit'] = place_details_flat[place_details_flat.PlaceID == j]['Info_Limit'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Info_Perm'] = place_details_flat[place_details_flat.PlaceID == j]['Info_Perm'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Tags'] = place_details_flat[place_details_flat.PlaceID == j]['Tags'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'CommentList'] = place_details_flat[place_details_flat.PlaceID == j]['CommentList'].values[0]
                place_details_flat_old.loc[place_details_flat_old.PlaceID == j, 'Owner'] = place_details_flat[place_details_flat.PlaceID == j]['Owner'].values[0]
                
            else:
                place_details_flat_old.loc[len(place_details_flat_old)] = place_details_flat[place_details_flat.PlaceID == j].values[0]
        if deleted_places is not None:
            for del_pla in deleted_places:
                place_details_flat_old = place_details_flat_old[place_details_flat_old.PlaceID != del_pla]
        place_details_flat = place_details_flat_old.reset_index(drop=True)
        
    
       
    if os.path.exists("placeindex"):
        shutil.rmtree("placeindex")    
    
    place_details_flat['Owner'] = place_details_flat['Owner'].astype('str')
    data_list = place_details_flat.values.tolist()
    collect_clean = []
    for items in data_list:
        ##print items
        ##print '------------------------------------>'
        bucket = []
        for text in items:
            #print text
            #print type(text)
            #clean_txt = ' '.join([word.encode('latin-1').lower() for word in str(text).decode('latin-1').split() if word not in stop_words])
            #clean_txt = ' '.join([word.lower() for word in text if word not in stop_words])
            clean_txt = ' '.join([word.lower() for word in text.split() if word not in stop_words])
#            
#            if ' ' in text:
#                clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
#                
#            else:
#                
#                clean_txt = ' '.join([word.lower() for word in text.split() if word not in stop_words])

            bucket.append(clean_txt)
        collect_clean.append(bucket)
    
    column = place_details_flat.columns
    place_details_flat = pd.DataFrame(collect_clean,columns = column)
    place_details_flat.to_csv('place_details_flat.csv', index = False, encoding = 'latin-1')
    
    schema_place = Schema(PlaceID = ID(stored=True),
                          Place_Name = TEXT(field_boost=2.0, stored=True),
                          City = TEXT(field_boost=2.0, stored=True),
                          Country = TEXT(field_boost=2.0, stored=True),
                          District = TEXT(field_boost=2.0, stored=True),                 
                          Add1 = TEXT(field_boost=2.0, stored=True),
                          State = KEYWORD(field_boost=1.0, stored=True),           
                          Street = TEXT(field_boost=1.0, stored=True),
                          Detail_Desc = TEXT(field_boost=2.0, stored=True),
                          Info_Decor = TEXT(field_boost=1.0, stored=True),
                          Info_Limit = TEXT(field_boost=1.0, stored=True),
                          Info_Perm = TEXT(field_boost=1.0, stored=True),
                          Tags = TEXT(field_boost=2.0, stored=True),
                          CommentList = TEXT(field_boost=1.0, stored=True),
                          Owner = KEYWORD(stored=True))

    if not os.path.exists("placeindex"):
        os.mkdir("placeindex")
    place_ix = create_in("placeindex", schema = schema_place)
    place_ix = open_dir("placeindex")
    place_writer = place_ix.writer()
    for val in collect_clean:
        #print(val[4])
        #print(type(val[4]))
        place_writer.add_document(PlaceID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                  Place_Name = unicode((str(val[1]) if ' ' in val[1] else val[1])),
                                  City = unicode((str(val[2]) if ' ' in val[2] else val[2])),
                                  Country = unicode((str(val[3]) if ' ' in val[3] else val[3])),
                                  District = unicode((str(val[4]) if ' ' in val[4] else val[4])),
                                  Add1 = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"),
                                  State = unicode((str(val[6]) if ' ' in val[6] else val[6])),
                                  Street = unicode((str(val[7]) if ' ' in val[7] else val[7])),
                                  Detail_Desc = unicode((str(val[8]) if ' ' in val[8] else val[8]),encoding="utf-8", errors="ignore"),
                                  Info_Decor = unicode((str(val[9]) if ' ' in val[9] else val[9])),
                                  Info_Limit = unicode((str(val[10]) if ' ' in val[10] else val[10])),
                                  Info_Perm = unicode((str(val[11]) if ' ' in val[11] else val[11])),
                                  Tags = unicode((str(val[12]) if ' ' in val[12] else val[12])),
                                  CommentList = unicode((str(val[13]) if ' ' in val[13] else val[13])),
                                  Owner = unicode(str(val[14]), encoding="utf-8", errors="ignore"))
    place_writer.commit()

def user_action_proc_place(place_details, place_details_old, deleted_places = None):
    if place_details_old is not None:
        place_details1 = place_details_proc(place_details, place_details_old, deleted_places)
        user_action_place = create_user_action_place(place_details1)
        return user_action_place, place_details1
    else:
        user_action_place = create_user_action_place(place_details)
        return user_action_place, place_details
    
def create_user_profile_place(user_action_place, place_profile, user_weights):
    col_names = ['UserID'] + list(place_profile.columns[1:])
    user_profile_place = pd.DataFrame(columns = col_names)
    for i in xrange(user_action_place.shape[0]):
        k = user_action_place['UserID'][i]
        total_count = 0
        owns = str(user_action_place['Owner'][i]).split('|')
        likes = str(user_action_place['Likes'][i]).split('|')
        comments = str(user_action_place['Comments'][i]).split('|')
        
        total_count = len(owns) * user_weights[0] + len(likes) * user_weights[1] + len(comments) * user_weights[2]
        update_record = []
        update_record.append(k)
        summation = np.zeros((1, place_profile.shape[1]-1))[0]
        if owns is not None:
            for j in owns:
                #print('******************** Owners ******************')
                #print(j)
                if j not in ['None','nan']:
                    #print((place_profile[place_profile.PlaceID == j]).values[0][1:])
                    summation = summation + (place_profile[place_profile.PlaceID == j]).values[0][1:] * user_weights[0]
        else:
            summation = summation
        if likes is not None:
            for j in likes:
                if j not in ['None','nan']:
                    summation = summation + (place_profile[place_profile.PlaceID == j]).values[0][1:] * user_weights[1]
        else:
            summation = summation
        if comments is not None:
            for j in comments:
                if j not in ['None','nan']:
                    summation = summation + (place_profile[place_profile.PlaceID == j]).values[0][1:] * user_weights[2]
        else:
            summation = summation
        summation /= total_count
        update_record = update_record + list(summation)
        user_profile_place.loc[len(user_profile_place)] = update_record
    return user_profile_place 

def creat_place_similarity(place_profile, user_profile_place):
    col_names = ['PlaceID'] + list(user_profile_place['UserID'])
    place_similarity = pd.DataFrame(columns = col_names)
    place_list = list(place_profile['PlaceID'])
    for i in place_list:
        update_record = [i]
        for k, j in enumerate(col_names):
            if k != 0:
                list1 = list(user_profile_place[user_profile_place.UserID == j].values[0][1:])
                list2 = list(place_profile[place_profile.PlaceID == i].values[0][1:])
                update_record.append(cos_sim(list1, list2))
        place_similarity.loc[len(place_similarity)] = update_record
    return place_similarity

def place_details_proc(place_details, place_details_old, deleted_places = None):
    place_list_old = list(place_details_old['PlaceID'])
    place_list_new = list(place_details['PlaceID'])
    for i,j in enumerate(place_list_new):
        if j in place_list_old:
            place_details_old.loc[place_details_old.PlaceID == j, 'Owner'] = place_details[place_details.PlaceID == j]['Owner'].values[0]
            place_details_old.loc[place_details_old.PlaceID == j, 'Likes'] = place_details[place_details.PlaceID == j]['Likes'].values[0]
            place_details_old.loc[place_details_old.PlaceID == j, 'Comments'] = place_details[place_details.PlaceID == j]['Comments'].values[0]
        else:
            place_details_old.loc[len(place_details_old)] = place_details[place_details.PlaceID == j].values[0]
    if deleted_places is not None:
        for del_plac in deleted_places:
            place_details_old = place_details_old[place_details_old.PlaceID != del_plac]
    place_details_old = place_details_old.reset_index(drop=True)
    return place_details_old

def create_user_action_place(place_details):
    
    ''' Converting a column to string if its data type is float/int type '''
    com_list = place_details['Comments'].tolist()
    com_list = float_to_string(com_list)
    
    like_list = place_details['Likes'].tolist()
    like_list = float_to_string(like_list)
    #trip_details.drop('Comments', axis=1, inplace=True)
        
    place_details['Comments'] = pd.DataFrame(com_list, columns=['Comments'])
    place_details['Likes'] = pd.DataFrame(like_list, columns=['Likes'])
        
    user_action_place = pd.DataFrame(columns = ['UserID', 'Owner', 'Likes', 'Comments'])
    user_list = []
    
    for i in xrange(place_details.shape[0]):
        u_list = []
        owns = None
        if pd.notnull(place_details['Owner'][i]):
            owns = str(place_details['Owner'][i]).split('|')
            if owns is not None:
                owns = [j.replace(' ','') for j in owns]
                owns = [j for j in owns if len(j) > 0]
        if owns is not None:
            for j in owns:
                if j is not None:
                    u_list.append(j)
        likes = None
        if pd.notnull(place_details['Likes'][i]):
            likes = str(place_details['Likes'][i]).split('|')
            if likes is not None:
                likes = [j.replace(' ','') for j in likes]
                likes = [j for j in likes if len(j) > 0]
        if likes is not None:
            for j in likes:
                if j is not None:
                    u_list.append(j)
        comments = None
        if pd.notnull(place_details['Comments'][i]):
            comments = str(place_details['Comments'][i]).split('|')
            if comments is not None:
                comments = [j.replace(' ','') for j in comments]
                comments = [j for j in comments if len(j) > 0]
        if comments is not None:
            for j in comments:
                if j is not None:
                    u_list.append(j)
        u_list = list(set(u_list))
        for k in u_list:
            if k not in user_list:
                user_list.append(k)
    for i in user_list:
        update_record = []
        update_record.append(i)
        ow = None
        li = None
        co = None
        for j in xrange(place_details.shape[0]):
            if i in str(place_details.Owner[j]):
                if ow is not None:
                    ow = ow + '|' + place_details.PlaceID[j]
                else:
                    ow = place_details.PlaceID[j]
            if i in str(place_details.Likes[j]):
                if li is not None:
                    li = li + '|' + place_details.PlaceID[j]
                else:
                    li = place_details.PlaceID[j]
            if i in str(place_details.Comments[j]):
                if co is not None:
                    co = co + '|' + place_details.PlaceID[j]
                else:
                    co = place_details.PlaceID[j]
        update_record.append(ow)
        update_record.append(li)
        update_record.append(co)
        user_action_place.loc[len(user_action_place)] = update_record
    return user_action_place

def search_query_place(place_query, user_id):
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    place_ix = open_dir("placeindex")
    multi_query_place = MultifieldParser(['PlaceID', 'Place_Name', 'City', 'Country', 'District', 'Add1', 'State', 'Street', 'Detail_Desc', 'Info_Decor', 'Info_Limit', 'Info_Perm', 'Tags', 'CommentList'], schema = place_ix.schema, group = OrGroup)
    multi_query_place.add_plugin(FuzzyTermPlugin())
    
#    print('************** printing raw search string from user ***********************')
#    print(place_query)
#    print(type(place_query))
    
    place_query = unicode(str(place_query), encoding="utf-8", errors="ignore")
    place_query = str(replace_all(place_query)).lower()
    
#    print('************** printing clean search string from user ***********************')
#    print(place_query)
#    print(type(place_query))
    
    place_query = ' '.join([word + ('~2') for word in place_query.split() if word not in stop_words and len(word) > 0])
    print(place_query)
    
    q = multi_query_place.parse(place_query)
    
    print('******************* PARSED QUERY ******************* ')
    print(q)
    
    search_place_ids = []
    search_place_owners = []
        
    with place_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'
               
        
        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_place_ids.append(str(results[i]['PlaceID']))
                search_place_owners.append(str(results[i]['Owner']))
    place_results = pd.DataFrame(columns = ['PlaceID', 'Owner', 'Score'])
    place_results['PlaceID'] = search_place_ids
    place_results['Owner'] = search_place_owners
    place_similarity = pd.read_csv('place_similarity.csv')
    if user_id in place_similarity.columns:
        for i in xrange(place_results.shape[0]):
            j = place_results['PlaceID'][i]
            k = place_similarity[place_similarity.PlaceID == j][user_id].values
            place_results['Score'][i] = k
            place_results = place_results.sort_values(['Score'], ascending=[0]).reset_index(drop = True )
        return list(place_results['PlaceID'][:].values), list(place_results['Owner'][:].values), list(place_results['Score'][:].values)
    else:
        return search_place_ids[:10], search_place_owners[:10], None

def place_owner_int(x):
    x = str(x)
    if '|' in x:
        return x
    elif x == 'i':
        return x
    else:
        #return str(int(float(x)))
        #print "*********************** Type value of x *********************" 
        #print type(x)
        return x

if __name__ == "__main__":
    app.run()