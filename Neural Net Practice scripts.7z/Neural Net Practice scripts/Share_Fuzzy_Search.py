# -*- coding: utf-8 -*-
"""
Created on Mon Apr 24 12:04:31 2017

@author: tarachy
"""

# Load Libraries
import web
#import xml.etree.ElementTree as ET
import os
import pandas as pd
from nltk.corpus import stopwords
import re
import string
#from whoosh.analysis import StemmingAnalyzer
from whoosh.index import create_in
from whoosh.fields import Schema, ID, KEYWORD, TEXT
from whoosh.qparser import MultifieldParser, OrGroup, FuzzyTermPlugin, AndGroup
from whoosh.index import open_dir

from datetime import date, datetime
import numpy as np

#from math import isnan
import math
from math import sqrt

import shutil


# Define urls (to be used in web service)
urls = (
    '/batch', 'create_flat_files',
    '/share/(.*)', 'search_share'
)
  
app = web.application(urls, globals())

# Define classes

class create_flat_files(object):
    
    def GET(self):
        batch_proc()    
    
    
class search_share(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        share_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        share_query = share_query.split(' ')
        share_query_1 = [i.encode('latin-1') for i in share_query]
        share_query = ' '.join(share_query_1)
        
        self.share_query = share_query
        
        return search_query_share(share_query, user_id)[0]

#Stadtbücherei
# Replacing all special characters with user defined
def replace_all(text):
    reps = {u'ö':'oe', u'ß':'ss', u'ß':'ss', u'ü':'ue', u'ä':'ae', u'Å':'ae', u'é':'e', u'Ä':'ae', u'Ö':'oe', u'Ü':'ue', u',':' ',  u'|':' ', u'-':' '}
    for i, j in reps.iteritems():
        #print('******** printing raw search text *************')
        #print(text)
        #print(type(text))
        #text = unicode(text, encoding="utf-8", errors="ignore")
        text = text.replace(i, j)
        #print('******** printing clean search text *************')
        #print(text)
        
    return text

def square_rooted(x): 
    return round(sqrt(sum([a*a for a in x])),3)
 
def cos_sim(x,y):
    numerator = sum(a*b for a,b in zip(x,y))
    denominator = square_rooted(x)*square_rooted(y)
    return round(numerator/float(denominator + 1e-11),4)

## Converting floating/nan User Ids to string
def float_to_string(x):
    cln_lst = []
    for i in x:
        if type(i) == float:
            if not math.isnan(i):
                val = str(int(float(i)))
                cln_lst.append(val)
        else:
            cln_lst.append(i)
    return cln_lst


# Define all functions

def batch_proc():
    user_weights = [5.0, 1.0, 1.0]
    
    share_details, share_profile, share_details_old = read_files_share()
    
    share_profile = item_profile_share(input_file = share_details, output_file = share_profile)
    
    print 'Processed Share Profile. Saving file in path...'
    share_profile.to_csv('share_profile.csv', index = False, encoding = 'utf-8')
    share_details, deleted_shares = remove_deleted_shares(share_details)
    share_details_flat = share_details[['ShareID', 'Sharetext', 'CommentList', 'PlaceAddr', 'City', 'Owner']]
    create_flat_share_fn(share_details_flat, deleted_shares)
    share_details = share_details[['ShareID', 'Owner', 'Likes', 'Comments']]
    user_action_share, share_details = user_action_proc_share(share_details, share_details_old, deleted_shares)
    
    print 'Processed share details. Saving file in path...'
    share_details.to_csv('share_details.csv', index = False, encoding = 'utf-8')
    
    print 'Processed user actions for share. Saving file in path...'
    
    user_action_share.to_csv('user_action_share.csv', index = False, encoding = 'utf-8')
    user_profile_share = create_user_profile_share(user_action_share, share_profile, user_weights)
    user_profile_share.to_csv('user_profile_share.csv', index = False, encoding = 'utf-8')
    share_similarity = creat_share_similarity(share_profile, user_profile_share)
    share_similarity.to_csv('share_similarity.csv', index = False)
    
"""
SHARE FILES
"""	

def remove_deleted_shares(share_details):
    deleted_shares = []
    for i in xrange(share_details.shape[0]):
        if pd.isnull(share_details['Owner'][i]):
            j = share_details['ShareID'][i]
            share_details = share_details[share_details.ShareID != j]
            deleted_shares.append(j)
    share_details = share_details.reset_index(drop=True)
    if len(deleted_shares) == 0:
        deleted_shares = None
    return share_details, deleted_shares

def read_files_share():
    share_details = pd.read_csv('share_file.csv', encoding = 'latin-1')
    share_details_old = None
    if os.path.exists('share_details.csv'):
        share_details_old = pd.read_csv('share_details.csv', encoding = 'latin-1')
        #print 'Share detail file exists. Reading file...'
    if os.path.exists('share_profile.csv'):
        share_profile = pd.read_csv('share_profile.csv', encoding = 'utf-8')
        #print 'Share Profile found. Updating file...'
    else:
        share_profile = None
        #print 'Warning: Share Profile not found in path. Creating new one...'
    return share_details, share_profile, share_details_old

def item_profile_share(input_file, output_file = None):
    input_file['Create_Date'] = pd.to_datetime(input_file['Create_Date'], format = '%Y-%m-%d')
    if output_file is None:
        output_file = create_item_profile_share(input_file)
    else:
        output_file = update_item_profile_share(input_file, output_file)
    return output_file

def update_item_profile_share(input_file, output_file):
    
    print('Updating share item profile...')
    time = datetime.now()
    profile_var = list(output_file.columns)
    shareid_list = list(output_file.ShareID)
    for i in xrange(0, input_file.shape[0]):
        if input_file['ShareID'][i] not in shareid_list and not pd.isnull(input_file['Create_Date'][i]):
            update_record = {}
            update_record['ShareID'] = input_file['ShareID'][i]
            car_cl = input_file['Car_Class'][i]
            try:
                car_cl_label = 'user_car_class_' + car_cl
            except:
                car_cl_label = 'user_car_class_' + str(car_cl)
            if car_cl_label not in profile_var:
                profile_var.append(car_cl_label)
                output_file[car_cl_label] = 0
            update_record[car_cl_label] = 1
            user_interest_list = input_file['Interests'][i]
            if pd.notnull(user_interest_list):
                user_interest_list = input_file['Interests'][i].split(',')
                user_interest_list = [j.replace(' ', '') for j in user_interest_list]
            
           
                for k in user_interest_list:
                    int_cl = k[:6]
                    int_cl_label = 'user_int_' + int_cl
                    if int_cl_label not in profile_var:
                        profile_var.append(int_cl_label)
                        output_file[int_cl_label] = 0
                    update_record[int_cl_label] = 1
                
            datediff = (date.today() - input_file['Create_Date'][i].date()).days
            if datediff == 0:
                update_record['create_today'] = 1
            elif datediff < 8:
                update_record['create_1week'] = 1
            elif datediff < 31:
                update_record['create_1month'] = 1
            elif datediff < 91:
                update_record['create_3month'] = 1
            else:
                update_record['create_old'] = 1
            Comment_Count = input_file['Comment_Count'][i]
            if Comment_Count == 0:
                update_record['comments_count_0'] = 1
            elif Comment_Count < 6:
                update_record['comments_count_5'] = 1
            elif Comment_Count < 21:
                update_record['comments_count_20'] = 1
            else:
                update_record['comments_count_more'] = 1
            Like_Count = input_file['Like_Count'][i]
            if Like_Count == 0:
                update_record['likes_count_0'] = 1
            elif Like_Count < 11:
                update_record['likes_count_10'] = 1
            elif Like_Count < 51:
                update_record['likes_count_50'] = 1
            else:
                update_record['likes_count_more'] = 1
            cit = input_file['City'][i]
            if cit not in profile_var:
                profile_var.append(cit)
                output_file[cit] = 0
            update_record[cit] = 1
            re_count = input_file['Reshare_Count'][i]
            if re_count == 0:
                update_record['reshare_0'] = 1
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 0
            elif re_count <= 3:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 1
                update_record['reshare_m'] = 0
            else:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 1
            update_record['placeimg_yes_no'] = input_file['Placeimg'][i]
            st = 'sharetype_' + input_file['Sharetype'][i]
            update_record[st] = 1
            #stl = len(str(input_file['Sharetext'][i]))
            if input_file['Sharetext'][i] == 'nan':
                stl = 0
            elif pd.isnull(input_file['Sharetext'][i]):
                stl = 0
            else:
                stl = len(input_file['Sharetext'][i].encode('utf-8'))
            if stl < 26:
                update_record['sharetext_len_sh'] = 1
            elif stl < 141:
                update_record['sharetext_len_me'] = 1
            else:
                update_record['sharetext_len_lo'] = 1
            update_list = []
            for m in profile_var:
                if m in update_record.keys():
                    update_list.append(update_record[m])
                else:
                    update_list.append(0)
            output_file.loc[len(output_file)] = update_list
        else:
            co_count = input_file['Comment_Count'][i]
            li_count = input_file['Like_Count'][i]
            re_count = input_file['Reshare_Count'][i]
            if co_count == 0:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 0
            elif co_count < 6:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 0
            elif co_count < 21:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 0
            else:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'comments_count_more'] = 1
            if li_count == 0:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 0
            elif li_count < 11:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 0
            elif li_count < 51:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 0
            else:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'likes_count_more'] = 1
            if re_count == 0:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_0'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_3'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_m'] = 0
                
            elif re_count <= 3:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_3'] = 1
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_m'] = 0
            else:
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_0'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_3'] = 0
                output_file.ix[output_file.ShareID == input_file.ShareID[i], 'reshare_m'] = 1
    for i in xrange(input_file.shape[0]):
        if pd.isnull(input_file['Owner'][i]):
            j = input_file['ShareID'][i]
            output_file = output_file[output_file.ShareID != j]
    diff = datetime.now() - time
    print('Time taken to update share profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file
                                    
def create_item_profile_share(input_file):
    
    print('Creating share item profile...')
    time = datetime.now()
    
    profile_var = []
    profile_var.append('ShareID')
    car_class_list = list(input_file['Car_Class'].unique())
    car_class_list1 = []
    for carc in car_class_list:
        try:
            car_class_list1.append('user_car_class_' + carc)
        except:
            car_class_list1.append('user_car_class_' + str(carc))
    car_class_list = car_class_list1[:]
    if 'user_car_class_nan' not in car_class_list:
        car_class_list.append('user_car_class_nan')
    
    interest_list = list(input_file['Interests'].unique())
    int_list = []
    for x in interest_list:
        if pd.notnull(x):
            for y in x.split(','):
                temp_int  = 'user_int_' + y.replace(' ', '')[:6]
                if temp_int not in int_list:
                    int_list.append(temp_int)
        
    create_list = ['create_today', 'create_1week', 'create_1month', 'create_3month', 'create_old']
    comment_list = ['comments_count_0', 'comments_count_5', 'comments_count_20', 'comments_count_more']
    like_list = ['likes_count_0', 'likes_count_10', 'likes_count_50', 'likes_count_more']
    city_list = list(input_file['City'].unique())
    
    reshare_list = ['reshare_0', 'reshare_3', 'reshare_m']
    share_list = ['placeimg_yes_no', 'sharetype_video', 'sharetype_image', 'sharetype_text', 'sharetext_len_sh', 'sharetext_len_me', 'sharetext_len_lo']
    profile_var = profile_var + car_class_list + int_list + create_list + comment_list + like_list + city_list + reshare_list + share_list
    output_file = pd.DataFrame(columns = profile_var)
    for i in xrange(0, input_file.shape[0]):
        update_record = {}
        update_record['ShareID'] = input_file['ShareID'][i]
        car_cl = str(input_file['Car_Class'][i])
        car_cl_label = 'user_car_class_' + car_cl
        update_record[car_cl_label] = 1
        user_interest_list = input_file['Interests'][i]
        if pd.notnull(user_interest_list):
            int_lis = user_interest_list.split(',')
            int_list = ['user_int_' + il.replace(' ','')[:6] for il in int_lis]
        for i_l in int_list:
            update_record[il] = 1

        datediff = (date.today() - input_file['Create_Date'][i].date()).days
        if datediff == 0:
            update_record['create_today'] = 1
        elif datediff < 8:
            update_record['create_1week'] = 1
        elif datediff < 31:
            update_record['create_1month'] = 1
        elif datediff < 91:
            update_record['create_3month'] = 1
        else:
            update_record['create_old'] = 1
        Comment_Count = input_file['Comment_Count'][i]
        if Comment_Count == 0:
            update_record['comments_count_0'] = 1
        elif Comment_Count < 6:
            update_record['comments_count_5'] = 1
        elif Comment_Count < 21:
            update_record['comments_count_20'] = 1
        else:
            update_record['comments_count_more'] = 1
        Like_Count = input_file['Like_Count'][i]
        if Like_Count == 0:
            update_record['likes_count_0'] = 1
        elif Like_Count < 11:
            update_record['likes_count_10'] = 1
        elif Like_Count < 51:
            update_record['likes_count_50'] = 1
        else:
            update_record['likes_count_more'] = 1
        update_record[input_file['City'][i]] = 1
        reshare_count = input_file['Reshare_Count'][i]
        if reshare_count == 0:
            update_record['reshare_0'] = 1
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 0
        elif reshare_count <= 3:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 1
            update_record['reshare_m'] = 0
        else:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 1
        update_record['placeimg_yes_no'] = input_file['Placeimg'][i]
        st = 'sharetype_' + input_file['Sharetype'][i]
        update_record[st] = 1
        #stl = len(str(input_file['Sharetext'][i].decode('latin-1')))
        if input_file['Sharetext'][i] == 'nan':
            stl = 0
        elif pd.isnull(input_file['Sharetext'][i]):
            stl = 0
        else:
            stl = len(input_file['Sharetext'][i].encode('utf-8'))
        if stl < 26:
            update_record['sharetext_len_sh'] = 1
        elif stl < 141:
            update_record['sharetext_len_me'] = 1
        else:
            update_record['sharetext_len_lo'] = 1
        update_list = []
        for m in profile_var:
            if m in update_record.keys():
                update_list.append(update_record[m])
            else:
                update_list.append(0)
        output_file.loc[len(output_file)] = update_list
    
    diff = datetime.now() - time
    print('Time taken to update share profile: ' + str(diff.seconds  ) + ' seconds')
    return output_file

def create_flat_share_fn(share_details_flat, deleted_shares = None):
    
    print('Creating share flat file...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    
    share_details_flat = share_details_flat.fillna('i')
    
    share_details_flat = share_details_flat.astype('unicode')
    
#    share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: replace_all(x))
#    share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['City'] = share_details_flat['City'].apply(lambda x: replace_all(x))
    share_details_flat['City'] = share_details_flat['City'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['Sharetext'] = share_details_flat['Sharetext'].apply(lambda x: replace_all(x))
    share_details_flat['Sharetext'] = share_details_flat['Sharetext'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['CommentList'] = share_details_flat['CommentList'].apply(lambda x: replace_all(x))
    share_details_flat['CommentList'] = share_details_flat['CommentList'].apply(lambda x: str(x.encode('utf-8')))
    
    share_details_flat['PlaceAddr'] = share_details_flat['PlaceAddr'].apply(lambda x: replace_all(x))
    share_details_flat['PlaceAddr'] = share_details_flat['PlaceAddr'].apply(lambda x: str(x.encode('utf-8')))
    
    if os.path.exists('share_details_flat.csv'):
        share_details_flat_old = pd.read_csv('share_details_flat.csv', encoding = 'latin-1')
        share_details_flat_old = share_details_flat_old.fillna('i')
        
#        share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: replace_all(x))
#        share_details_flat['Interests'] = share_details_flat['Interests'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['City'] = share_details_flat_old['City'].apply(lambda x: replace_all(x))
        share_details_flat_old['City'] = share_details_flat_old['City'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['Sharetext'] = share_details_flat_old['Sharetext'].apply(lambda x: replace_all(x))
        share_details_flat_old['Sharetext'] = share_details_flat_old['Sharetext'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['CommentList'] = share_details_flat_old['CommentList'].apply(lambda x: replace_all(x))
        share_details_flat_old['CommentList'] = share_details_flat_old['CommentList'].apply(lambda x: str(x.encode('utf-8')))
        
        share_details_flat_old['PlaceAddr'] = share_details_flat_old['PlaceAddr'].apply(lambda x: replace_all(x))
        share_details_flat_old['PlaceAddr'] = share_details_flat_old['PlaceAddr'].apply(lambda x: str(x.encode('utf-8')))
        
        old_share_ids = list(share_details_flat_old['ShareID'])
        for i in xrange(share_details_flat.shape[0]):
            j = share_details_flat['ShareID'][i]
            if j in old_share_ids:
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'Sharetext'] = share_details_flat[share_details_flat.ShareID == j]['Sharetext'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'CommentList'] = share_details_flat[share_details_flat.ShareID == j]['CommentList'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'PlaceAddr'] = share_details_flat[share_details_flat.ShareID == j]['PlaceAddr'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'City'] = share_details_flat[share_details_flat.ShareID == j]['City'].values[0]
                share_details_flat_old.loc[share_details_flat_old.ShareID == j, 'Owner'] = share_details_flat[share_details_flat.ShareID == j]['Owner'].values[0]
            else:
                share_details_flat_old.loc[len(share_details_flat_old)] = share_details_flat[share_details_flat.ShareID == j].values[0]
        if deleted_shares is not None:
            for del_sha in deleted_shares:
                share_details_flat_old = share_details_flat_old[share_details_flat_old.ShareID != del_sha]
        share_details_flat = share_details_flat_old.reset_index(drop=True)
    
    
    if os.path.exists("shareindex"):
        shutil.rmtree("shareindex")
    
    data_list = share_details_flat.values.tolist()
    collect_clean = []
    for items in data_list:
        bucket = []
        for text in items:
            clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
            bucket.append(clean_txt)
        collect_clean.append(bucket)
        
    column = share_details_flat.columns
    share_details_flat = pd.DataFrame(collect_clean,columns = column)    
    share_details_flat.to_csv('share_details_flat.csv', index = False, encoding = 'latin-1')
        
    schema_share = Schema(ShareID = ID(stored=True),
                          Sharetext = TEXT(field_boost=2.0, stored=True),
                          CommentList = TEXT(field_boost=1.0, stored=True),
                          PlaceAddr = TEXT(field_boost=1.0, stored=True),
                          City = TEXT(field_boost=1.0, stored=True),
                          Owner = KEYWORD(stored=True))
    if not os.path.exists("shareindex"):
        os.mkdir("shareindex")
    share_ix = create_in("shareindex", schema = schema_share)
    share_ix = open_dir("shareindex")
    share_writer = share_ix.writer()
    for val in collect_clean:
        share_writer.add_document(ShareID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                  Sharetext = unicode((str(val[1]) if ' ' in val[1] else val[1]), encoding="utf-8", errors="ignore"),
                                  CommentList = unicode((str(val[2]) if ' ' in val[2] else val[2]), encoding="utf-8", errors="ignore"),
                                  PlaceAddr = unicode((str(val[3]) if ' ' in val[3] else val[3]), encoding="utf-8", errors="ignore"),
                                  City = unicode((str(val[4]) if ' ' in val[4] else val[4]), encoding="utf-8", errors="ignore"),
                                  Owner = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"))
    share_writer.commit()
    diff = datetime.now() - time
    print('Time taken to create share flat file: ' + str(diff.seconds  ) + ' seconds')

def user_action_proc_share(share_details, share_details_old, deleted_shares = None):
    if share_details_old is not None:
        share_details1 = share_details_proc(share_details, share_details_old, deleted_shares)
        user_action = create_user_action_share(share_details1)
        return user_action, share_details1
    else:
        user_action = create_user_action_share(share_details)
        return user_action, share_details

def create_user_profile_share(user_action, share_profile, user_weights):
    
    print('Creating User profile based on share...')
    time = datetime.now()
    
    col_names = ['UserID'] + list(share_profile.columns[1:])
    user_profile_share = pd.DataFrame(columns = col_names)
    for i in xrange(user_action.shape[0]):
        k = user_action['UserID'][i]
        total_count = 0
        owns = str(user_action['Owner'][i]).split('|')
        likes = str(user_action['Likes'][i]).split('|')
        comments = str(user_action['Comments'][i]).split('|')
        
        total_count = len(owns) * user_weights[0] + len(likes) * user_weights[1] + len(comments) * user_weights[2]
        update_record = []
        update_record.append(k)
        summation = np.zeros((1, share_profile.shape[1]-1))[0]
        if owns is not None:
            for j in owns:
                if j not in ['None','nan']:
                    summation = summation + (share_profile[share_profile.ShareID == j]).values[0][1:] * user_weights[0]
        if likes is not None:
            for j in likes:
                if j not in ['None','nan']:
                    summation = summation + (share_profile[share_profile.ShareID == j]).values[0][1:] * user_weights[1]
        if comments is not None:
            for j in comments:
                if j not in ['None','nan']:
                    summation = summation + (share_profile[share_profile.ShareID == j]).values[0][1:] * user_weights[2]
        summation /= total_count
        update_record = update_record + list(summation)
        user_profile_share.loc[len(user_profile_share)] = update_record
    
    diff = datetime.now() - time
    print('Time taken to create user profile based on share: ' + str(diff.seconds  ) + ' seconds')
    return user_profile_share

def creat_share_similarity(share_profile, user_profile_share):
    
    print('Creatig Share similarity matrix...')
    time = datetime.now()
    
    col_names = ['ShareID'] + list(user_profile_share['UserID'])
    share_similarity = pd.DataFrame(columns = col_names)
    share_list = list(share_profile['ShareID'])
    for i in share_list:
        update_record = [i]
        for k, j in enumerate(col_names):
            if k != 0:
                list1 = list(user_profile_share[user_profile_share.UserID == j].values[0][1:])
                list2 = list(share_profile[share_profile.ShareID == i].values[0][1:])
                update_record.append(cos_sim(list1, list2))
        share_similarity.loc[len(share_similarity)] = update_record
    
    diff = datetime.now() - time
    print('Time taken to creat share similarity matrix: ' + str(diff.seconds  ) + ' seconds')    
    return share_similarity

def share_details_proc(share_details, share_details_old, deleted_shares = None):
    share_list_old = list(share_details_old['ShareID'])
    share_list_new = list(share_details['ShareID'])
    for i,j in enumerate(share_list_new):
        if j in share_list_old:
            if pd.isnull(share_details['Owner'][i]):
                share_details_old = share_details_old[share_details_old.ShareID != j]
            elif str(share_details['Owner'][i]).split('|') is None:
                share_details_old = share_details_old[share_details_old.ShareID != j]
            else:
                share_details_old.loc[share_details_old.ShareID == j, 'Owner'] = share_details[share_details.ShareID == j]['Owner'].values[0]
                share_details_old.loc[share_details_old.ShareID == j, 'Likes'] = share_details[share_details.ShareID == j]['Likes'].values[0]
                share_details_old.loc[share_details_old.ShareID == j, 'Comments'] = share_details[share_details.ShareID == j]['Comments'].values[0]
        else:
            share_details_old.loc[len(share_details_old)] = share_details[share_details.ShareID == j].values[0]
    if deleted_shares is not None:
        for del_shar in deleted_shares:
            share_details_old = share_details_old[share_details_old.ShareID != del_shar]
    share_details_old = share_details_old.reset_index(drop=True)
    return share_details_old

def create_user_action_share(share_details):
    
    print('Creating users share action based on their activites...')
    time = datetime.now()
    ''' Converting a column to string if its data type is float/int type '''
    com_list = share_details['Comments'].tolist()
    com_list = float_to_string(com_list)
    
    like_list = share_details['Likes'].tolist()
    like_list = float_to_string(like_list)
    #trip_details.drop('Comments', axis=1, inplace=True)
        
    share_details['Comments'] = pd.DataFrame(com_list, columns=['Comments'])
    share_details['Likes'] = pd.DataFrame(like_list, columns=['Likes'])
    
    user_action = pd.DataFrame(columns = ['UserID', 'Owner', 'Likes', 'Comments'])
    user_list = []
    
    for i in xrange(share_details.shape[0]):
        u_list = []
        if pd.notnull(share_details['Owner'][i]):
            owns = str(share_details['Owner'][i]).split('|')
            if owns is not None:
                owns = [j.replace(' ','') for j in owns]
                owns = [j for j in owns if len(j) > 0]
        if owns is not None:
            for j in owns:
                if j is not None:
                    u_list.append(j)
        likes = None
        if pd.notnull(share_details['Likes'][i]):
            likes = str(share_details['Likes'][i]).split('|')
            if likes is not None:
                likes = [j.replace(' ','') for j in likes]
                likes = [j for j in likes if len(j) > 0]
        if likes is not None:
            for j in likes:
                if j is not None:
                    u_list.append(j)
        comments = None
        if pd.notnull(share_details['Comments'][i]):
            comments = str(share_details['Comments'][i]).split('|')
            if comments is not None:
                comments = [j.replace(' ','') for j in comments]
                comments = [j for j in comments if len(j) > 0]
        if comments is not None:
            for j in comments:
                if j is not None:
                    u_list.append(j)
        u_list = list(set(u_list))
        for k in u_list:
            if k not in user_list:
                user_list.append(k)
    for i in user_list:
        update_record = []
        update_record.append(i)
        ow = None
        li = None
        co = None
        for j in xrange(share_details.shape[0]):
            if i in str(share_details.Owner[j]):
                if ow is not None:
                    ow = ow + '|' + share_details.ShareID[j]
                else:
                    ow = share_details.ShareID[j]
            if i in str(share_details.Likes[j]):
                if li is not None:
                    li = li + '|' + share_details.ShareID[j]
                else:
                    li = share_details.ShareID[j]
            if i in str(share_details.Comments[j]):
                if co is not None:
                    co = co + '|' + share_details.ShareID[j]
                else:
                    co = share_details.ShareID[j]
        update_record.append(ow)
        update_record.append(li)
        update_record.append(co)
        user_action.loc[len(user_action)] = update_record
    
    diff = datetime.now() - time
    print('Time taken to create user action share based on activities: ' + str(diff.seconds  ) + ' seconds')
    return user_action 

def search_query_share(share_query, user_id):
    
    print('Searching for the record as per users search query...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    share_ix = open_dir("shareindex")
    multi_query_share = MultifieldParser(["ShareID","Sharetext", "CommentList", "PlaceAddr", "City"], schema = share_ix.schema, group = OrGroup)
    
    multi_query_share.add_plugin(FuzzyTermPlugin())
    
    print('Printing raw search string from user...')
    print(share_query)
    print(type(share_query))
    
    share_query = unicode(str(share_query), encoding="utf-8", errors="ignore")
    share_query = str(replace_all(share_query)).lower()
    
    print('Printing clean search string from user...')
    print(share_query)
    print(type(share_query))
    
    share_query = ' '.join([word + ('~2') for word in share_query.split() if word not in stop_words and len(word) > 0])
    print(share_query)
    
    q = multi_query_share.parse(share_query)
    
    print('Paresed Query...')
    print(q)
    
    #share_query = unicode(share_query)
    #share_query = share_query.lower()
#    share_query = re.findall('[a-z]+', share_query.lower())
#    
#    
#    share_query = ' '.join([word for word in share_query if word not in stop_words])
#    
#    q = multi_query_share.parse(share_query)
    
    search_share_ids = []
    search_share_owners = []
    
        
    with share_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'
        ##print results[0]["ShareID"]+' - ' + results[0]["Sharetext"]+' - '+results[0]["CommentList"]+' - '+results[0]["PlaceAddr"]
        
        
        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_share_ids.append(str(results[i]['ShareID']))
                search_share_owners.append(str(results[i]['Owner']))
    share_results = pd.DataFrame(columns = ['ShareID', 'Owner', 'Score'])
    share_results['ShareID'] = search_share_ids
    share_results['Owner'] = search_share_owners
    share_similarity = pd.read_csv('share_similarity.csv')
    print('Reading share similarity matrix for personalization...')
    
    if user_id in share_similarity.columns:
        for i in xrange(share_results.shape[0]):
            j = share_results['ShareID'][i]
            k = share_similarity[share_similarity.ShareID == j][user_id].values
            share_results['Score'][i] = k
            share_results = share_results.sort_values(['Score'], ascending=[0]).reset_index(drop = True )
        
        diff = datetime.now() - time
        print('Results found in : ' + str(diff.seconds  ) + ' seconds')
        
        return list(share_results['ShareID'][:].values), list(share_results['Owner'][:].values), list(share_results['Score'][:].values)
    else:
        diff = datetime.now() - time
        print('Results found in : ' + str(diff.seconds  ) + ' seconds')
        return search_share_ids[:10], search_share_owners[:10], None
    


if __name__ == "__main__":
    app.run()
