# -*- coding: utf-8 -*-
"""
Created on Tue May 02 11:05:51 2017

@author: tarachy
"""
# Load Libraries
import web
#import xml.etree.ElementTree as ET
import os
import pandas as pd
from nltk.corpus import stopwords
import re
import string
#from whoosh.analysis import StemmingAnalyzer
from whoosh.index import create_in
from whoosh.fields import Schema, ID, KEYWORD, TEXT
from whoosh.qparser import MultifieldParser, OrGroup, FuzzyTermPlugin, AndGroup
from whoosh.index import open_dir

from datetime import date, datetime
import numpy as np

#from math import isnan
import math
from math import sqrt

import shutil

# Define urls (to be used in web service)
urls = (
    '/batch', 'create_flat_files',
    '/user/(.*)', 'search_user',

)
  
app = web.application(urls, globals())

# Define classes

class create_flat_files(object):
    
    def GET(self):
        batch_proc()

class search_user(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        user_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        user_query = user_query.split(' ')
        user_query_1 = [i.encode('latin-1') for i in user_query]
        user_query = ' '.join(user_query_1)
        
        self.user_query = user_query
        
        return search_query_user_alone(user_query)

# Replacing all special characters with user defined
def replace_all(text):
    reps = {u'ö':'oe', u'ß':'ss', u'ß':'ss', u'ü':'ue', u'ä':'ae', u'Å':'ae', u'é':'e', u'Ä':'ae', u'Ö':'oe', u'Ü':'ue', u',':' ',  u'|':' ', u'-':' '}
    for i, j in reps.iteritems():
        #print('******** printing raw search text *************')
        #print(text)
        #print(type(text))
        #text = unicode(text, encoding="utf-8", errors="ignore")
        text = text.replace(i, j)
        #print('******** printing clean search text *************')
        #print(text)
        
    return text

def square_rooted(x): 
    return round(sqrt(sum([a*a for a in x])),3)
 
def cos_sim(x,y):
    numerator = sum(a*b for a,b in zip(x,y))
    denominator = square_rooted(x)*square_rooted(y)
    return round(numerator/float(denominator + 1e-11),4)

## Converting floating/nan User Ids to string
def float_to_string(x):
    cln_lst = []
    for i in x:
        if type(i) == float:
            if not math.isnan(i):
                val = str(int(float(i)))
                cln_lst.append(val)
        else:
            cln_lst.append(i)
    return cln_lst

# Define all functions

def batch_proc():
    create_flat_user_fn()


"""
USER FILES
"""

def create_flat_user_fn():
    print('Creating user flat file...')
    time = datetime.now()
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    user_details_flat = pd.read_csv('user_file.csv', encoding = 'latin-1')
    
    user_details_flat = user_details_flat.fillna('i')
    
    user_details_flat['UserID'] = user_details_flat['UserID'].astype('int')
    user_details_flat['UserID'] = user_details_flat['UserID'].astype('str')
    user_details_flat['UserID'] = user_details_flat['UserID'].apply(lambda x: 'u' + str(x) + 'u')
    
    user_details_flat['UserName_First'] = user_details_flat['UserName_First'].apply(lambda x: replace_all(x))
    user_details_flat['UserName_First'] = user_details_flat['UserName_First'].apply(lambda x: str(x.encode('utf-8')))
    
    user_details_flat['UserName_Last'] = user_details_flat['UserName_Last'].apply(lambda x: replace_all(x))
    user_details_flat['UserName_Last'] = user_details_flat['UserName_Last'].apply(lambda x: str(x.encode('utf-8')))
    
    user_details_flat['UserName_Middle'] = user_details_flat['UserName_Middle'].apply(lambda x: replace_all(x))
    user_details_flat['UserName_Middle'] = user_details_flat['UserName_Middle'].apply(lambda x: str(x.encode('utf-8')))
    
    #user_details_flat['UserName_Middle'] = user_details_flat['UserName_Middle'].apply(lambda x: replace_null(x))
    #user_details_flat['UserName_Last'] = user_details_flat['UserName_Last'].apply(lambda x: replace_null(x))

#    user_details_flat['UserName_First'] = user_details_flat['UserName_First'].apply(lambda x: str(x.encode('utf-8')))
#    user_details_flat['UserName_Last'] = user_details_flat['UserName_Last'].apply(lambda x: str(x.encode('utf-8')))
#    user_details_flat['UserName_Middle'] = user_details_flat['UserName_Middle'].apply(lambda x: str(x.encode('utf-8')))
    
    user_details_flat['ScreenName'] = user_details_flat['ScreenName'].apply(lambda x: replace_all(x))
    user_details_flat['ScreenName'] = user_details_flat['ScreenName'].apply(lambda x: str(x.encode('utf-8')))

    user_details_flat['City'] = user_details_flat['City'].apply(lambda x: replace_all(x))
    user_details_flat['City'] = user_details_flat['City'].apply(lambda x: str(x.encode('utf-8')))
        
    if os.path.exists('user_details_flat.csv'):
        user_details_flat_old = pd.read_csv('user_details_flat.csv', encoding = 'latin-1')
        user_details_flat_old = user_details_flat_old.fillna('i')
        
        user_details_flat_old['UserName_First'] = user_details_flat_old['UserName_First'].apply(lambda x: replace_all(x))
        user_details_flat_old['UserName_First'] = user_details_flat_old['UserName_First'].apply(lambda x: str(x.encode('utf-8')))
        
        user_details_flat_old['UserName_Last'] = user_details_flat_old['UserName_Last'].apply(lambda x: replace_all(x))
        user_details_flat_old['UserName_Last'] = user_details_flat_old['UserName_Last'].apply(lambda x: str(x.encode('utf-8')))
        
        user_details_flat_old['UserName_Middle'] = user_details_flat_old['UserName_Middle'].apply(lambda x: replace_all(x))
        user_details_flat_old['UserName_Middle'] = user_details_flat_old['UserName_Middle'].apply(lambda x: str(x.encode('utf-8')))
        
        user_details_flat_old['ScreenName'] = user_details_flat_old['ScreenName'].apply(lambda x: replace_all(x))
        user_details_flat_old['ScreenName'] = user_details_flat_old['ScreenName'].apply(lambda x: str(x.encode('utf-8')))
        
        user_details_flat_old['City'] = user_details_flat_old['City'].apply(lambda x: str(x.encode('utf-8')))
        user_details_flat_old['City'] = user_details_flat_old['City'].apply(lambda x: replace_all(x))
        
        old_user_ids = list(user_details_flat_old['UserID'])
        
        for i in xrange(user_details_flat.shape[0]):
            j = str(user_details_flat['UserID'][i])
            
            if j in old_user_ids:
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'UserName_First'] = user_details_flat[user_details_flat.UserID == str(j)]['UserName_First'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'UserName_Last'] = user_details_flat[user_details_flat.UserID == str(j)]['UserName_Last'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'UserName_Middle'] = user_details_flat[user_details_flat.UserID == str(j)]['UserName_Middle'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'ScreenName'] = user_details_flat[user_details_flat.UserID == str(j)]['ScreenName'].values[0]
                user_details_flat_old.loc[user_details_flat_old.UserID == str(j), 'City'] = user_details_flat[user_details_flat.UserID == str(j)]['City'].values[0]
            
            else:
                user_details_flat_old.loc[len(user_details_flat_old)] = user_details_flat[user_details_flat.UserID == str(j)].values[0]
        
        
        user_details_flat_old = user_details_flat_old.dropna(axis = 0, subset = [['UserName_First']])
        
        user_details_flat = user_details_flat_old.reset_index(drop=True)
               
       
    if os.path.exists("userindex"):
        shutil.rmtree("userindex")
    data_list = user_details_flat.values.tolist()
    collect_clean = []
    
    for items in data_list:
        bucket = []
        for text in items:
            clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
            bucket.append(clean_txt)
        collect_clean.append(bucket)
    
    column = user_details_flat.columns
    user_details_flat = pd.DataFrame(collect_clean,columns = column)             
    user_details_flat.to_csv('user_details_flat.csv', index = False, encoding = 'latin-1')
            
    schema_user = Schema(UserID = ID(stored=True),
                          UserName_First = KEYWORD(field_boost=2.0, stored=True),
                          UserName_Last = KEYWORD(field_boost=1.0, stored=True),
                          UserName_Middle = KEYWORD(field_boost=1.0, stored=True),
                          ScreenName = TEXT(field_boost=2.0, sortable=True, phrase = False),
                          City = TEXT(field_boost=1.0, stored=True))



    if not os.path.exists("userindex"):
        os.mkdir("userindex")
    user_ix = create_in("userindex", schema = schema_user)
    user_ix = open_dir("userindex")
    user_writer = user_ix.writer()
    for val in collect_clean:
        
        user_writer.add_document(UserID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                  UserName_First = unicode((str(val[1]) if ' ' in val[1] else val[1]), encoding="utf-8", errors="ignore"),
                                  UserName_Last = unicode((str(val[2]) if ' ' in val[2] else val[2]), encoding="utf-8", errors="ignore"),
                                  UserName_Middle = unicode((str(val[3]) if ' ' in val[3] else val[3]), encoding="utf-8", errors="ignore"),
                                  ScreenName = unicode((str(val[4]) if ' ' in val[4] else val[4]), encoding="utf-8", errors="ignore"),
                                  City = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"))
    user_writer.commit()

    diff = datetime.now() - time
    print('Time taken to create user flat file: ' + str(diff.seconds  ) + ' seconds')

def search_query_user_alone(user_query):
    print('Processing user search query for user...' + '\n')
    time = datetime.now()
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    user_ix = open_dir("userindex")
    multi_query_user = MultifieldParser(["UserID","UserName_First", "UserName_Last", "UserName_Middle", "ScreenName", "City"], schema = user_ix.schema, group = OrGroup)
    #user_query = unicode(str(user_query))
    # user_query = user_query.lower()
    
    multi_query_user.add_plugin(FuzzyTermPlugin())
    
    print('Printing raw search string from user...' + '\n')
    print(user_query)
    print(type(user_query))
    
    user_query = unicode(str(user_query), encoding="utf-8", errors="ignore")
    user_query = str(replace_all(user_query)).lower()
    
    print('Printing clean search string from user...' + '\n')
    print(user_query)
    print(type(user_query))
    
    user_query = ' '.join([word + ('~2') for word in user_query.split() if word not in stop_words and len(word) > 0])
    print(user_query)
    
    q = multi_query_user.parse(user_query)
    print('Printing parsed search query...' + '\n')
    print(q)
 
    search_user_ids = []
        
    with user_ix.searcher() as searcher:
        results = searcher.search(q, sortedby='ScreenName')
        
        print '\n The total number of' +' hits: ' + str(len(results)) + '\n'
        
               
        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_user_ids.append(str(results[i]['UserID']))
                
    search_user_ids = [res[1:-1] for res in search_user_ids]
    

    diff = datetime.now() - time
    print('Time taken to retreive user results: ' + str(diff.seconds  ) + ' seconds' + '\n')
    return search_user_ids

def f7(seq):
    new_seq = []
    for elem in seq:
        if elem not in new_seq:
            new_seq.append(elem)
    return new_seq

if __name__ == "__main__":
    app.run()