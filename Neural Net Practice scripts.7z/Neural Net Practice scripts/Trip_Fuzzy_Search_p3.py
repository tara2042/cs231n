# -*- coding: utf-8 -*-
"""
Created on Fri Mar 17 08:33:40 2017

@author: seernes
"""

# Load Libraries
import web
#import xml.etree.ElementTree as ET
import os
import pandas as pd
from nltk.corpus import stopwords
import re
import string
#from whoosh.analysis import StemmingAnalyzer
from whoosh.index import create_in
from whoosh.fields import Schema, ID, KEYWORD, TEXT
from whoosh.qparser import MultifieldParser, OrGroup, FuzzyTermPlugin, AndGroup
from whoosh.index import open_dir

from datetime import date
import numpy as np

#from math import isnan
import math
from math import sqrt

import shutil

# Define urls (to be used in web service)
urls = (
    '/batch', 'create_flat_files',
    '/trips/(.*)', 'search_trip'
)

app = web.application(urls, globals())

# Define classes

class create_flat_files(object):
    
    def GET(self):
        batch_proc()    


class search_trip(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        trip_query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        
        trip_query = trip_query.split(' ')
        trip_query_1 = [i.encode('latin-1') for i in trip_query]
        trip_query = ' '.join(trip_query_1)
        
        self.trip_query = trip_query
        
        return search_query_trip(trip_query, user_id)[0]

class search_all(object):
    
    def GET(self, search_string):
        #print search_string
        
        user_id = search_string[-(int(search_string[-1])+1):-1]
        query = search_string[:-(int(search_string[-1])+1)]
        
        self.user_id = user_id
        self.query = query
        return search_query_all(query, user_id)

# Define all functions

def batch_proc():
    #user_weights = [.8, 0.1, 0.1]
    user_weights = [5.1,1.0,1.0]
    
    trip_details, trip_profile, trip_details_old = read_files_trip()
    
    trip_profile = item_profile_trip(input_file = trip_details, output_file = trip_profile)
    #print 'Processed Trip Profile. Saving file in path...'
    trip_profile.to_csv('trip_profile.csv', index = False, encoding = 'utf-8')
    trip_details, deleted_trips = remove_deleted_trips(trip_details)
    trip_details_flat = trip_details[['TripID', 'Description', 'Dest_Point', 'Sour_Point', 'Sugg_Places', 'Tags', 'Trip_Name', 'Owner', 'CommentList']]
    create_flat_trip_fn(trip_details_flat, deleted_trips)
    trip_details = trip_details[['TripID', 'Owner', 'Likes', 'Comments']]
    user_action_trip, trip_details = user_action_proc_trip(trip_details, trip_details_old, deleted_trips)
    #print 'Processed trip details. Saving file in path...'
    trip_details.to_csv('trip_details.csv', index = False, encoding = 'utf-8')
    #print 'Processed user actions for trip. Saving file in path...'
    user_action_trip.to_csv('user_action_trip.csv', index = False, encoding = 'utf-8')
    user_profile_trip = create_user_profile_trip(user_action_trip, trip_profile, user_weights)
    user_profile_trip.to_csv('user_profile_trip.csv', index = False, encoding = 'utf-8')
    trip_similarity = creat_trip_similarity(trip_profile, user_profile_trip)
    trip_similarity.to_csv('trip_similarity.csv', index = False)
    
# Replacing all special characters with user defined
def replace_all(text):
    reps = {u'ö':'oe', u'ß':'ss', u'ß':'ss', u'ü':'ue', u'ä':'ae', u'Å':'ae', u'é':'e', u'Ä':'ae', u'Ö':'oe', u'Ü':'ue', u',':' ',  u'|':' ', u'-':' '}
    for i, j in reps.iteritems():
        text = text.replace(i, j)
    return text

def square_rooted(x): 
    return round(sqrt(sum([a*a for a in x])),3)
 
def cos_sim(x,y):
    numerator = sum(a*b for a,b in zip(x,y))
    denominator = square_rooted(x)*square_rooted(y)
    return round(numerator/float(denominator + 1e-11),4)

## Converting floating/nan User Ids to string
def float_to_string(x):
    cln_lst = []
    for i in x:
        if type(i) == float:
            if not math.isnan(i):
                val = str(int(float(i)))
                cln_lst.append(val)
        else:
            cln_lst.append(i)
    return cln_lst

#trip_details = pd.read_csv('C:/Users/tarachy/Desktop/Trip Search/trip_file.csv', encoding = 'latin-1')
#trip_details = trip_details.fillna('i')
#trip_details['Sour_Point'] = trip_details['Sour_Point'].apply(lambda text: replace_all(text))
#trip_details['Dest_Point'] = trip_details['Dest_Point'].apply(lambda text: replace_all(text))



"""
TRIP FILES
"""
def remove_deleted_trips(trip_details):
    deleted_trips = []
    for i in range(trip_details.shape[0]):
        if pd.isnull(trip_details['Owner'][i]):
            j = trip_details['TripID'][i]
            trip_details = trip_details[trip_details.TripID != j]
            deleted_trips.append(j)
    trip_details = trip_details.reset_index(drop=True)
    if len(deleted_trips) == 0:
        deleted_trips = None
    return trip_details, deleted_trips


def read_files_trip():
    trip_details = pd.read_csv('trip_file.csv', encoding = 'latin-1')
    
    trip_details_old = None
    if os.path.exists('trip_details.csv'):
        trip_details_old = pd.read_csv('trip_details.csv', encoding = 'latin-1')
        #print 'Trip detail file exists. Reading file...'
    if os.path.exists('trip_profile.csv'):
        trip_profile = pd.read_csv('trip_profile.csv', encoding = 'utf-8')
        #print 'Trip Profile found. Updating file...'
    else:
        trip_profile = None
        #print 'Warning: Trip Profile not found in path. Creating new one...'
    return trip_details, trip_profile, trip_details_old

def item_profile_trip(input_file, output_file = None):
    input_file['Create_Date'] = pd.to_datetime(input_file['Create_Date'], format = '%Y-%m-%d')
    if output_file is None:
        output_file = create_item_profile_trip(input_file)
    else:
        output_file = update_item_profile_trip(input_file, output_file)
    return output_file

def update_item_profile_trip(input_file, output_file):
    
    profile_var = list(output_file.columns)
    tripid_list = list(output_file.TripID)
    for i in range(0, input_file.shape[0]):
        if input_file['TripID'][i] not in tripid_list and not pd.isnull(input_file['Create_Date'][i]):
            update_record = {}
            update_record['TripID'] = input_file['TripID'][i]
            Comment_Count = input_file['Comment_Count'][i]
            if Comment_Count == 0:
                update_record['comments_count_0'] = 1
            elif Comment_Count < 6:
                update_record['comments_count_5'] = 1
            elif Comment_Count < 21:
                update_record['comments_count_20'] = 1
            else:
                update_record['comments_count_more'] = 1
            Dist_Covered = input_file['Dist_Covered'][i]
            if Dist_Covered <= 50:
                update_record['Dist_Covered_50'] = 1
            elif Dist_Covered <= 200:
                update_record['Dist_Covered_200'] = 1
            elif Dist_Covered <=500:
                update_record['Dist_Covered_500'] = 1
            else:
                update_record['Dist_Covered_more'] = 1
            driving_exp = input_file['Driving_Exp'][i]
            if pd.notnull(driving_exp): 
                dri_exp_label = 'dri_exp_' + driving_exp
                if dri_exp_label not in profile_var:
                    profile_var.append(dri_exp_label)
                    output_file[dri_exp_label] = 0
            else:
                dri_exp_label = 'dri_exp_nan'
            update_record[dri_exp_label] = 1
            Like_Count = input_file['Like_Count'][i]
            if Like_Count == 0:
                update_record['likes_count_0'] = 1
            elif Like_Count < 11:
                update_record['likes_count_10'] = 1
            elif Like_Count < 51:
                update_record['likes_count_50'] = 1
            else:
                update_record['likes_count_more'] = 1
            my_car = input_file['My_Car'][i]
            if pd.notnull(my_car): 
                my_car_label = 'car_' + my_car
                if my_car_label not in profile_var:
                    profile_var.append(my_car_label)
                    output_file[my_car_label] = 0
            else:
                my_car_label = 'car_nan'
            update_record[my_car_label] = 1
            purp = input_file['Purpose'][i]
            if pd.notnull(purp): 
                purp_label = 'purp_' + purp
                if purp_label not in profile_var:
                    profile_var.append(purp_label)
                    output_file[purp_label] = 0
            else:
                purp_label = 'purp_nan'
                
            update_record[purp_label] = 1
            re_count = input_file['Reshare_Count'][i]
            datediff = (date.today() - input_file['Create_Date'][i].date()).days
            if datediff == 0:
                update_record['create_today'] = 1
            elif datediff < 8:
                update_record['create_1week'] = 1
            elif datediff < 31:
                update_record['create_1month'] = 1
            elif datediff < 91:
                update_record['create_3month'] = 1
            else:
                update_record['create_old'] = 1

            if re_count == 0:
                update_record['reshare_0'] = 1
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 0
            elif re_count <= 3:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 1
                update_record['reshare_m'] = 0
            else:
                update_record['reshare_0'] = 0
                update_record['reshare_3'] = 0
                update_record['reshare_m'] = 1
            travellers = input_file['Travellers'][i]
            if travellers == 0:
                update_record['travellers_0'] = 1
                update_record['travellers_2'] = 0
                update_record['travellers_m'] = 0
            elif travellers == 1:
                update_record['travellers_0'] = 0
                update_record['travellers_2'] = 1
                update_record['travellers_m'] = 0
            else:
                update_record['travellers_0'] = 0
                update_record['travellers_2'] = 0
                update_record['travellers_m'] = 1
            update_record['tripimg_yes_no'] = input_file['TripImage'][i]
            stat = input_file['Trip_Status'][i]
            if pd.notnull(stat): 
                stat_label = 'stat_' + stat
                if stat_label not in profile_var:
                    profile_var.append(stat_label)
                    output_file[stat_label] = 0
            else:
                stat_label = 'stat_nan'
            update_record[stat_label] = 1
            update_list = []
            for m in profile_var:
                if m in update_record.keys():
                    update_list.append(update_record[m])
                else:
                    update_list.append(0)
            output_file.loc[len(output_file)] = update_list
        else:
            co_count = input_file['Comment_Count'][i]
            li_count = input_file['Like_Count'][i]
            re_count = input_file['Reshare_Count'][i]
            di_covered = input_file['Dist_Covered'][i]
            driving_exp = input_file['Driving_Exp'][i]
            travellers = input_file['Travellers'][i]
            stat = input_file['Trip_Status'][i]
            if pd.notnull(driving_exp):            
                dri_exp_label = 'dri_exp_' + driving_exp
                if dri_exp_label not in profile_var:
                    profile_var.append(dri_exp_label)
                    output_file[dri_exp_label] = 0
            else:
                dri_exp_label = 'dri_exp_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], dri_exp_label] = 1
            my_car = input_file['My_Car'][i]
            if pd.notnull(my_car): 
                my_car_label = 'car_' + my_car
                if my_car_label not in profile_var:
                    profile_var.append(my_car_label)
                    output_file[my_car_label] = 0
            else:
                my_car_label = 'car_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], my_car_label] = 1
            purp = input_file['Purpose'][i]
            if pd.notnull(purp): 
                purp_label = 'purp_' + purp
                if purp_label not in profile_var:
                    profile_var.append(purp_label)
                    output_file[purp_label] = 0
            else:
                purp_label = 'purp_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], purp_label] = 1
            output_file.ix[output_file.TripID == input_file.TripID[i], 'tripimg_yes_no'] = input_file['TripImage'][i]              
            if pd.notnull(stat): 
                stat_label = 'stat_' + stat
                if stat_label not in profile_var:
                    profile_var.append(stat_label)
                    output_file[stat_label] = 0
            else:
                stat_label = 'stat_nan'
            output_file.ix[output_file.TripID == input_file.TripID[i], stat_label] = 1              
            if travellers == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_2'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_m'] = 0
                
            elif travellers == 1:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_2'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_m'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_2'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'travellers_m'] = 1
            
            if co_count == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 0
            elif co_count < 6:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 0
            elif co_count < 21:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_5'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_20'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'comments_count_more'] = 1
            if li_count == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 0
            elif li_count < 11:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 0
            elif li_count < 51:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_10'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'likes_count_more'] = 1
            if re_count == 0:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_0'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_3'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_m'] = 0
                
            elif re_count <= 3:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_3'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_m'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_0'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_3'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'reshare_m'] = 1
            if di_covered <= 50:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 0
            elif di_covered <= 200:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 0
            elif di_covered <= 500:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 1
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 0
            else:
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_50'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_200'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_500'] = 0
                output_file.ix[output_file.TripID == input_file.TripID[i], 'Dist_Covered_more'] = 1

    for i in range(input_file.shape[0]):
        if pd.isnull(input_file['Owner'][i]):
            j = input_file['TripID'][i]
            output_file = output_file[output_file.TripID != j]
    return output_file
                                    
def create_item_profile_trip(input_file):
    
    profile_var = []
    profile_var.append('TripID')
    profile_var.append('tripimg_yes_no')
    dri_exp_list = list(input_file['Driving_Exp'].unique())
    dri_exp_list1 = []
    for dri_exp in dri_exp_list:
        try:
            dri_exp_list1.append('dri_exp_' + dri_exp)
        except:
            dri_exp_list1.append('dri_exp_' + str(dri_exp))
    dri_exp_list = dri_exp_list1[:]
    if 'dri_exp_nan' not in dri_exp_list:
        dri_exp_list.append('dri_exp_nan')
    my_car_list = list(input_file['My_Car'].unique())
    my_car_list1 = []
    for my_car in my_car_list:
        try:
            my_car_list1.append('car_' + my_car)
        except:
            my_car_list1.append('car_' + str(my_car))
    my_car_list = my_car_list1[:]
    if 'car_nan' not in my_car_list:
        my_car_list.append('car_nan')
    purp_list = list(input_file['Purpose'].unique())
    purp_list1 = []
    for purp in purp_list:
        try:
            purp_list1.append('purp_' + purp)
        except:
            purp_list1.append('purp_' + str(purp))
    purp_list = purp_list1[:]
    if 'purp_nan' not in purp_list:
        purp_list.append('purp_nan')
    trip_status_list = list(input_file['Trip_Status'].unique())
    trip_status_list1 = []
    for trip_stat in trip_status_list:
        try:
            trip_status_list1.append('stat_' + trip_stat)
        except:
            trip_status_list1.append('stat_' + str(trip_stat))
    trip_status_list = trip_status_list1[:]
    if 'stat_nan' not in trip_status_list:
        trip_status_list.append('stat_nan')
    create_list = ['create_today', 'create_1week', 'create_1month', 'create_3month', 'create_old']
    comment_list = ['comments_count_0', 'comments_count_5', 'comments_count_20', 'comments_count_more']
    like_list = ['likes_count_0', 'likes_count_10', 'likes_count_50', 'likes_count_more']
    reshare_list = ['reshare_0', 'reshare_3', 'reshare_m']
    dist_covered_list = ['Dist_Covered_50', 'Dist_Covered_200', 'Dist_Covered_500', 'Dist_Covered_more']
    travellers_list = ['travellers_0', 'travellers_2', 'travellers_m']
    
    profile_var = profile_var + dri_exp_list + my_car_list + purp_list + trip_status_list + create_list + comment_list + like_list + reshare_list + dist_covered_list + travellers_list
    output_file = pd.DataFrame(columns = profile_var)
    for i in range(0, input_file.shape[0]):
        update_record = {}
        update_record['TripID'] = input_file['TripID'][i]
        Comment_Count = input_file['Comment_Count'][i]
        if Comment_Count == 0:
            update_record['comments_count_0'] = 1
        elif Comment_Count < 6:
            update_record['comments_count_5'] = 1
        elif Comment_Count < 21:
            update_record['comments_count_20'] = 1
        else:
            update_record['comments_count_more'] = 1
        dist_covered = input_file['Dist_Covered'][i]
        if dist_covered <= 50:
            update_record['Dist_Covered_50'] = 1
        elif dist_covered <= 200:
            update_record['Dist_Covered_200'] = 1
        elif dist_covered <= 500:
            update_record['Dist_Covered_500'] = 1
        else:
            update_record['Dist_Covered_more'] = 1
        try:
            driving_exp_label = 'dri_exp_' + input_file['Driving_Exp'][i]
        except:
            driving_exp_label = 'dri_exp_' + str(input_file['Driving_Exp'][i])
        
        update_record[driving_exp_label] = 1
        Like_Count = input_file['Like_Count'][i]
        if Like_Count == 0:
            update_record['likes_count_0'] = 1
        elif Like_Count < 11:
            update_record['likes_count_10'] = 1
        elif Like_Count < 51:
            update_record['likes_count_50'] = 1
        else:
            update_record['likes_count_more'] = 1
        try:
            my_car_label = 'car_' + input_file['My_Car'][i]
        except:
            my_car_label = 'car_' + str(input_file['My_Car'][i])

        update_record[my_car_label] = 1
                     
        try:
            purp_label = 'purp_' + input_file['Purpose'][i]
        except:
            purp_label = 'purp_' + str(input_file['Purpose'][i])
     
        update_record[purp_label] = 1
        reshare_count = input_file['Reshare_Count'][i]
        if reshare_count == 0:
            update_record['reshare_0'] = 1
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 0
        elif reshare_count <= 3:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 1
            update_record['reshare_m'] = 0
        else:
            update_record['reshare_0'] = 0
            update_record['reshare_3'] = 0
            update_record['reshare_m'] = 1
        datediff = (date.today() - input_file['Create_Date'][i].date()).days
        if datediff == 0:
            update_record['create_today'] = 1
        elif datediff < 8:
            update_record['create_1week'] = 1
        elif datediff < 31:
            update_record['create_1month'] = 1
        elif datediff < 91:
            update_record['create_3month'] = 1
        else:
            update_record['create_old'] = 1
        travellers = input_file['Travellers'][i]
        if travellers == 0:
            update_record['travellers_0'] = 1
        elif travellers == 1:
            update_record['travellers_2'] = 1
        else:
            update_record['travellers_m'] = 1
        update_record['tripimg_yes_no'] = input_file['TripImage'][i]
        
        try:
            stat_label = 'stat_' + input_file['Trip_Status'][i]
        except:
            stat_label = 'stat_' + str(input_file['Trip_Status'][i])

        update_record[stat_label] = 1
        update_list = []
        for m in profile_var:
            if m in update_record.keys():
                update_list.append(update_record[m])
            else:
                update_list.append(0)
        output_file.loc[len(output_file)] = update_list
    return output_file


# apply(lambda text: replace_all(text))

def create_flat_trip_fn(trip_details_flat, deleted_trips = None):
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    
    trip_details_flat = trip_details_flat.fillna('i')
    
    trip_details_flat = trip_details_flat.astype('unicode')

    trip_details_flat['Description'] = trip_details_flat['Description'].apply(lambda x: replace_all(x))
    trip_details_flat['Description'] = trip_details_flat['Description'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['Dest_Point'] = trip_details_flat['Dest_Point'].apply(lambda x: replace_all(x))
    trip_details_flat['Dest_Point'] = trip_details_flat['Dest_Point'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['Sour_Point'] = trip_details_flat['Sour_Point'].apply(lambda x: replace_all(x))
    trip_details_flat['Sour_Point'] = trip_details_flat['Sour_Point'].apply(lambda x: str(x.encode('utf-8')))
    
    
    trip_details_flat['Sugg_Places'] = trip_details_flat['Sugg_Places'].apply(lambda x: replace_all(x))
    trip_details_flat['Sugg_Places'] = trip_details_flat['Sugg_Places'].apply(lambda x: str(x.encode('utf-8')))
        
    trip_details_flat['Tags'] = trip_details_flat['Tags'].apply(lambda x: replace_all(x))
    trip_details_flat['Tags'] = trip_details_flat['Tags'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['Trip_Name'] = trip_details_flat['Trip_Name'].apply(lambda x: replace_all(x))
    trip_details_flat['Trip_Name'] = trip_details_flat['Trip_Name'].apply(lambda x: str(x.encode('utf-8')))
    
    trip_details_flat['CommentList'] = trip_details_flat['CommentList'].apply(lambda x: replace_all(x))
    trip_details_flat['CommentList'] = trip_details_flat['CommentList'].apply(lambda x: str(x.encode('utf-8')))
    
    if os.path.exists('trip_details_flat.csv'):
        trip_details_flat_old = pd.read_csv('trip_details_flat.csv', encoding = 'latin-1')
        trip_details_flat_old = trip_details_flat_old.fillna('i')
        trip_details_flat_old['Owner'] = trip_details_flat_old['Owner'].apply(lambda x: str(int(x)))
        
        trip_details_flat_old['Description'] = trip_details_flat_old['Description'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Description'] = trip_details_flat_old['Description'].apply(lambda x: str(x.encode('utf-8')))
        
        trip_details_flat_old['Dest_Point'] = trip_details_flat_old['Dest_Point'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Dest_Point'] = trip_details_flat_old['Dest_Point'].apply(lambda x: str(x.encode('utf-8')))
        
        trip_details_flat_old['Sour_Point'] = trip_details_flat_old['Sour_Point'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Sour_Point'] = trip_details_flat_old['Sour_Point'].apply(lambda x: str(x.encode('utf-8')))
                
        trip_details_flat_old['Sugg_Places'] = trip_details_flat_old['Sugg_Places'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Sugg_Places'] = trip_details_flat_old['Sugg_Places'].apply(lambda x: str(x.encode('utf-8')))
        
        trip_details_flat_old['Tags'] = trip_details_flat_old['Tags'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Tags'] = trip_details_flat_old['Tags'].apply(lambda x: str(x.encode('utf-8')))
        
        
        trip_details_flat_old['Trip_Name'] = trip_details_flat_old['Trip_Name'].apply(lambda x: replace_all(x))
        trip_details_flat_old['Trip_Name'] = trip_details_flat_old['Trip_Name'].apply(lambda x: str(x.encode('utf-8')))

        trip_details_flat_old['CommentList'] = trip_details_flat_old['CommentList'].apply(lambda x: replace_all(x))
        trip_details_flat_old['CommentList'] = trip_details_flat_old['CommentList'].apply(lambda x: str(x.encode('utf-8')))

        
        old_trip_ids = list(trip_details_flat_old['TripID'])
        
        for i in range(trip_details_flat.shape[0]):
            j = trip_details_flat['TripID'][i]
            
            if j in old_trip_ids:
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Description'] = trip_details_flat[trip_details_flat.TripID == j]['Description'].values[0]
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Dest_Point'] = trip_details_flat[trip_details_flat.TripID == j]['Dest_Point'].values[0]
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Sour_Point'] = trip_details_flat[trip_details_flat.TripID == j]['Sour_Point'].values[0]
                #sugg_temp = str(trip_details_flat[trip_details_flat.TripID == j]['Sugg_Places'].values[0])
                #sug_temp = sugg_temp.replace(',', ' ')
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Sugg_Places'] = str(trip_details_flat[trip_details_flat.TripID == j]['Sugg_Places'].values[0])
                #temp_tag = str(trip_details_flat[trip_details_flat.TripID == j]['Tags'].values[0])
                #temp_tag = temp_tag.replace(',', ' ')
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Tags'] = str(trip_details_flat[trip_details_flat.TripID == j]['Tags'].values[0])
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Trip_Name'] = trip_details_flat[trip_details_flat.TripID == j]['Trip_Name'].values[0]
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'Owner'] = trip_details_flat[trip_details_flat.TripID == j]['Owner'].values[0]

                #comm_temp = trip_details_flat[trip_details_flat.TripID == j]['CommentList'].values[0]
                #comm_temp = comm_temp.replace('|', ' ')
                trip_details_flat_old.loc[trip_details_flat_old.TripID == j, 'CommentList'] = trip_details_flat[trip_details_flat.TripID == j]['CommentList'].values[0]
                
            else:
                trip_details_flat_old.loc[len(trip_details_flat_old)] = trip_details_flat[trip_details_flat.TripID == j].values[0]
                
        
        if deleted_trips is not None:
            for del_trip in deleted_trips:
                
                trip_details_flat_old = trip_details_flat_old[trip_details_flat_old.TripID != del_trip]

        trip_details_flat = trip_details_flat_old.reset_index(drop=True)
        
    if os.path.exists("tripindex"):
        shutil.rmtree("tripindex")

    data_list = trip_details_flat.values.tolist()
    collect_clean = []
    for items in data_list:
        
        bucket = []
        for text in items:
            
            if ' ' in text:
                clean_txt = ' '.join([word.lower() for word in str(text).split() if word not in stop_words])
                
            else:
                
                clean_txt = ' '.join([word.lower() for word in text.split() if word not in stop_words])
            			
            bucket.append(clean_txt)
        collect_clean.append(bucket)
        
    column = trip_details_flat.columns    
    trip_details_flat = pd.DataFrame(collect_clean,columns = column)    
    trip_details_flat.to_csv('trip_details_flat.csv', index = False, encoding = 'latin-1')
    
    schema_trip = Schema(TripID = ID(stored=True),
                          Description = TEXT(field_boost=1.0, stored=True),
                          CommentList = TEXT(field_boost=1.0, stored=True),
                          Dest_Point = KEYWORD(field_boost=2.0, stored=True),
                          Sour_Point = KEYWORD(field_boost=2.0, stored=True),
                          Sugg_Places = KEYWORD(field_boost=1.0, stored=True),
                          Tags = TEXT(field_boost=2.0, stored=True),
                          Trip_Name = KEYWORD(field_boost=2.0, stored=True),
                          Owner = KEYWORD(stored=True))
    
    if not os.path.exists("tripindex"):
        os.mkdir("tripindex")
    trip_ix = create_in("tripindex", schema = schema_trip)
    trip_ix = open_dir("tripindex")
    trip_writer = trip_ix.writer()
    for val in collect_clean:
        #print unicode(val[2], encoding = "utf-8", errors = "ignore")
        trip_writer.add_document(TripID = unicode(str(val[0]), encoding="utf-8", errors="ignore"),
                                 Description = unicode((str(val[1]) if ' ' in val[1] else val[1]), encoding="utf-8", errors="ignore"),
                                 CommentList = unicode((str(val[8]) if ' ' in val[8] else val[8]), encoding="utf-8", errors="ignore"),
                                 Dest_Point = unicode((str(val[2]) if ' ' in val[2] else val[2]), encoding="utf-8", errors="ignore"),
                                 Sour_Point = unicode((str(val[3]) if ' ' in val[3] else val[3]), encoding="utf-8", errors="ignore"),
                                 Sugg_Places = unicode((str(val[4]) if ' ' in val[4] else val[4]), encoding="utf-8", errors="ignore"),
                                 Tags = unicode((str(val[5]) if ' ' in val[5] else val[5]), encoding="utf-8", errors="ignore"),
                                 Trip_Name = unicode((str(val[6]) if ' ' in val[6] else val[6]), encoding="utf-8", errors="ignore"),
                                 Owner = unicode(str(val[7]), encoding="utf-8", errors="ignore"))
    trip_writer.commit()


def user_action_proc_trip(trip_details, trip_details_old, deleted_trips = None):
    if trip_details_old is not None:
        trip_details1 = trip_details_proc(trip_details, trip_details_old, deleted_trips)
        user_action_trip = create_user_action_trip(trip_details1)
        return user_action_trip, trip_details1
    else:
        user_action_trip = create_user_action_trip(trip_details)
        return user_action_trip, trip_details

def create_user_profile_trip(user_action_trip, trip_profile, user_weights):
    col_names = ['UserID'] + list(trip_profile.columns[1:])
    user_profile_trip = pd.DataFrame(columns = col_names)
    for i in range(user_action_trip.shape[0]):
        k = user_action_trip['UserID'][i]
        total_count = 0
        owns = str(user_action_trip['Owner'][i]).split('|')
        likes = str(user_action_trip['Likes'][i]).split('|')
        comments = str(user_action_trip['Comments'][i]).split('|')
        
        total_count = len(owns) * user_weights[0] + len(likes) * user_weights[1] + len(comments) * user_weights[2]
        update_record = []
        update_record.append(k)
        summation = np.zeros((1, trip_profile.shape[1]-1))[0]
        if owns is not None:
            for j in owns:
                if j not in ['None','nan']:
                    summation = summation + (trip_profile[trip_profile.TripID == j]).values[0][1:] * user_weights[0]
        if likes is not None:
            for j in likes:
                if j not in ['None','nan']:
                    summation = summation + (trip_profile[trip_profile.TripID == j]).values[0][1:] * user_weights[1]
        if comments is not None:
            for j in comments:
                if j not in ['None','nan']:
                    summation = summation + (trip_profile[trip_profile.TripID == j]).values[0][1:] * user_weights[2]
        summation /= total_count
        update_record = update_record + list(summation)
        user_profile_trip.loc[len(user_profile_trip)] = update_record
    return user_profile_trip 

def creat_trip_similarity(trip_profile, user_profile_trip):
    col_names = ['TripID'] + list(user_profile_trip['UserID'])
    trip_similarity = pd.DataFrame(columns = col_names)
    trip_list = list(trip_profile['TripID'])
    for i in trip_list:
        update_record = [i]
        for k, j in enumerate(col_names):
            if k != 0:
                list1 = list(user_profile_trip[user_profile_trip.UserID == j].values[0][1:])
                list2 = list(trip_profile[trip_profile.TripID == i].values[0][1:])
                update_record.append(cos_sim(list1, list2))
        trip_similarity.loc[len(trip_similarity)] = update_record
    return trip_similarity

def trip_details_proc(trip_details, trip_details_old, deleted_trips = None):
    trip_list_old = list(trip_details_old['TripID'])
    trip_list_new = list(trip_details['TripID'])
    for i,j in enumerate(trip_list_new):
        if j in trip_list_old:
            if pd.isnull(trip_details['Owner'][i]):
                trip_details_old = trip_details_old[trip_details_old.TripID != j]
            elif str(trip_details['Owner'][i]).split('|') is None:
                trip_details_old = trip_details_old[trip_details_old.TripID != j]
            else:
                trip_details_old.loc[trip_details_old.TripID == j, 'Owner'] = trip_details[trip_details.TripID == j]['Owner'].values[0]
                trip_details_old.loc[trip_details_old.TripID == j, 'Likes'] = trip_details[trip_details.TripID == j]['Likes'].values[0]
                trip_details_old.loc[trip_details_old.TripID == j, 'Comments'] = trip_details[trip_details.TripID == j]['Comments'].values[0]
        else:
            trip_details_old.loc[len(trip_details_old)] = trip_details[trip_details.TripID == j].values[0]
    if deleted_trips is not None:
        for del_trip in deleted_trips:
            trip_details_old = trip_details_old[trip_details_old.TripID != del_trip]
    trip_details_old = trip_details_old.reset_index(drop=True)
    return trip_details_old 

def create_user_action_trip(trip_details):
    
    ''' Converting a column to string if its data type is float/int type '''
    com_list = trip_details['Comments'].tolist()
    com_list = float_to_string(com_list)
    
    like_list = trip_details['Likes'].tolist()
    like_list = float_to_string(like_list)
    #trip_details.drop('Comments', axis=1, inplace=True)
        
    trip_details['Comments'] = pd.DataFrame(com_list, columns=['Comments'])
    trip_details['Likes'] = pd.DataFrame(like_list, columns=['Likes'])
    
    user_action_trip = pd.DataFrame(columns = ['UserID', 'Owner', 'Likes', 'Comments'])
    user_list = []
    
    for i in range(trip_details.shape[0]):
        u_list = []
        if pd.notnull(trip_details['Owner'][i]):
            owns = str(trip_details['Owner'][i]).split('|')
            if owns is not None:
                owns = [j.replace(' ','') for j in owns]
                owns = [j for j in owns if len(j) > 0]
        if owns is not None:
            for j in owns:
                if j is not None:
                    u_list.append(j)
        likes = None
        if pd.notnull(trip_details['Likes'][i]):
            likes = str(trip_details['Likes'][i]).split('|')
            if likes is not None:
                likes = [j.replace(' ','') for j in likes]
                likes = [j for j in likes if len(j) > 0]
        if likes is not None:
            for j in likes:
                if j is not None:
                    u_list.append(j)
        comments = None
        if pd.notnull(trip_details['Comments'][i]):
            comments = str(trip_details['Comments'][i]).split('|')
            if comments is not None:
                comments = [j.replace(' ','') for j in comments]
                comments = [j for j in comments if len(j) > 0]
        if comments is not None:
            for j in comments:
                if j is not None:
                    u_list.append(j)
        u_list = list(set(u_list))
        for k in u_list:
            if k not in user_list:
                user_list.append(k)
    for i in user_list:
        update_record = []
        update_record.append(i)
        ow = None
        li = None
        co = None
        for j in range(trip_details.shape[0]):
            if i in str(trip_details.Owner[j]):
                if ow is not None:
                    ow = ow + '|' + trip_details.TripID[j]
                else:
                    ow = trip_details.TripID[j]
            if i in str(trip_details.Likes[j]):
                if li is not None:
                    li = li + '|' + trip_details.TripID[j]
                else:
                    li = trip_details.TripID[j]
            if i in str(trip_details.Comments[j]):
                if co is not None:
                    co = co + '|' + trip_details.TripID[j]
                else:
                    co = trip_details.TripID[j]
        update_record.append(ow)
        update_record.append(li)
        update_record.append(co)
        user_action_trip.loc[len(user_action_trip)] = update_record
    return user_action_trip

def search_query_trip(trip_query, user_id):
    
    stop_words = [i.encode('utf-8') for i in stopwords.words("english")]
    trip_ix = open_dir("tripindex")
    multi_query_trip = MultifieldParser(["TripID","Description", "CommentList", "Dest_Point", "Sour_Point", "Sugg_Places", "Tags", "Trip_Name"], schema = trip_ix.schema, group = OrGroup)
    multi_query_trip.add_plugin(FuzzyTermPlugin())
    #multi_query_trip.add_plugin(WildcardPlugin())
    trip_query = unicode(str(trip_query), encoding="utf-8", errors="ignore")
    # trip_query = trip_query.lower()
    #trip_query = '#hello th@re! how are y&u'
    print('************** printing raw search string from user ***********************')
    print(trip_query)
    print(type(trip_query))
    #trip_query = re.findall('[@#$&a-z0-9]+', trip_query.lower())
    
    trip_query = str(replace_all(trip_query)).lower()
    print('************* print trip query after removing punctuations*****************')
    print(trip_query)
    print(type(trip_query))
    
    #trip_query = trip_query.split()
    trip_query = ' '.join([word + ('~2/2') for word in trip_query.split() if word not in stop_words and len(word) > 0])
    print('******************* final trip_query for search ******************* ')
    print(trip_query)
#    mug = []
#    for words in trip_query:
#        print(words)
#        words = words + ('~2/3')
#        mug.append(words)
#    trip_query = mug
#    
#    trip_query = ' '.join([word for word in trip_query.split()])
    print('******************* PARSED QUERY ******************* ')
    q = multi_query_trip.parse(trip_query)
    print(q)
    
    search_trip_ids = []
    search_trip_owners = []    
    with trip_ix.searcher() as searcher:
        results = searcher.search(q)
        
        #print '\n The total number of' +' hits: ' + str(len(results)) + '\n'

        if len(results) > 0:
            for i in xrange(min(len(results), 10)):
                search_trip_ids.append(str(results[i]['TripID']))
                search_trip_owners.append(str(results[i]['Owner']))
    trip_results = pd.DataFrame(columns = ['TripID', 'Owner', 'Score'])
    trip_results['TripID'] = search_trip_ids
    trip_results['Owner'] = search_trip_owners
    trip_similarity = pd.read_csv('trip_similarity.csv')
    if user_id in trip_similarity.columns:
        for i in range(trip_results.shape[0]):
            j = trip_results['TripID'][i]
            k = trip_similarity[trip_similarity.TripID == j][user_id].values
            trip_results['Score'][i] = k
            trip_results = trip_results.sort_values(['Score'], ascending=[0]).reset_index(drop = True )
        return list(trip_results['TripID'][:].values), list(trip_results['Owner'][:].values), list(trip_results['Score'][:].values)
    else:
        return search_trip_ids[:10], search_trip_owners[:10], None

def f7(seq):
    new_seq = []
    for elem in seq:
        if elem not in new_seq:
            new_seq.append(elem)
    return new_seq

def search_query_all(query, user_id):
    trip_results, trip_owners, trip_scores = search_query_trip(query, user_id)
#    place_results, place_owners, place_scores = search_query_place(query, user_id)
#    share_results, share_owners, share_scores = search_query_share(query, user_id)
#    user_results_alone = search_query_user_alone(query)

    user_id_list = []
    score_list = []
    user_id_list = user_id_list + trip_owners
    if trip_scores is None:
        score_list = score_list + list(np.zeros(len(trip_results)))
    else:
        score_list = score_list + trip_scores

    new_score_list = []
    new_user_id_list = []
    for numb, userid in enumerate(user_id_list):
        if userid != 'nan':
            new_list = userid.split('|')
            
            for new_entry in new_list:
                if len(new_entry) > 0:
                    new_user_id_list.append(str(int(float(new_entry))))
                    new_score_list.append(score_list[numb])
                
    if len(new_score_list) > 0:
        user_results = [list(x) for x in zip(*sorted(zip(new_score_list, new_user_id_list), key=lambda pair: pair[0]))][1]
    
#        user_results = user_results_alone + user_results
        user_results = f7(user_results)
        if user_id in user_results:
            user_results.remove(user_id)
            if len(user_results) > 10:
                user_results = user_results[:10]
    else:
        user_results = new_user_id_list
    final_user_results = []
    for us in user_results:
        
        if pd.notnull(us):
            user_l = us.split('|')
            new_user_l = []
            for cu in user_l:
                if cu != '':
                    new_user_l.append(cu)
            #user_l = [str(int(float(e))) for e in user_l]
            final_user_results = final_user_results + new_user_l
    return trip_results, final_user_results    

def replace_null(x):
    if pd.isnull(x):
        return ' ' 
    else:
        return x


if __name__ == "__main__":
    app.run()
