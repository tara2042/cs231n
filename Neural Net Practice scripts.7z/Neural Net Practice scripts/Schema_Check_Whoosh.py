# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 12:12:55 2017

@author: tarachy
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 11:43:03 2017

@author: tarachy
"""
'C:\Users\tarachy\Desktop\Travelbook'

from whoosh.index import open_dir
ix = open_dir('C:/Users/tarachy/Desktop/tripindex')
#ix = open_dir('C:/Users/tarachy/Desktop/userindex')
ix.schema

from whoosh.query import Every

#results = ix.searcher().search(Every('ScreenName'))

results = ix.searcher().documents()

for doc in results:
    print(doc)

for i in range(len(results)):
    print(results['Place_Name'][i])
    places = result['Place_Name']
    for place in places:
        #print(place)