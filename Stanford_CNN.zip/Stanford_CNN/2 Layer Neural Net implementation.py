# -*- coding: utf-8 -*-
"""
Created on Tue May 30 10:21:46 2017

@author: tarachy
"""

''' Full implementation of training a 2 layer neural network '''

import numpy as np

X = np.array([[0,0,1],
              [0,1,1],
              [1,0,1],
              [1,1,1]])

y = np.array([[0,1,1,0]]).T

syna0 = 2 * np.random.random((3,4)) - 1 # Random weight initialization at input layer
syna1 = 2 * np.random.random((4,1)) - 1 # Random weight initialization at hidden layer 1
                            
for j in xrange(60000):
    
    score1 = np.dot(X, syna0) # (4X3 . 3X4) ==> (4X4) 
    lay_1 = 1 / (1 + np.exp(- score1)) # (4X4)
    
    score2 = np.dot(lay_1, syna1) # (4X4 . 4X1) ==> (4X1)
    lay_2 = 1 / (1 + np.exp(- score2)) # (4X1)
    
    lay_2_delta = (y - lay_2) * (lay_2 * (1 - lay_2)) # (4X1)
    lay_1_delta = lay_2_delta.dot(syna1.T) * (lay_1 * (1 - lay_1)) # (4X1 . 1X4) * (4X4) ==> (4X4)
    syna1 += lay_1.T.dot(lay_2_delta) # (4X4 . 4X1) ==> (4X1)
    syna0 += X.T.dot(lay_1_delta) # (3X4 . (4X4) ==> (3X4)
    