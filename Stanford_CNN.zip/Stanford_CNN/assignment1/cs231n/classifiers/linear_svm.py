import numpy as np
from random import shuffle
#from past.builtins import xrange

def svm_loss_naive(W, X, y, reg):
  """
  Structured SVM loss function, naive implementation (with loops).

  Inputs have dimension D, there are C classes, and we operate on minibatches
  of N examples.

  Inputs:
  - W: A numpy array of shape (D, C) containing weights.
  - X: A numpy array of shape (N, D) containing a minibatch of data.
  - y: A numpy array of shape (N,) containing training labels; y[i] = c means
    that X[i] has label c, where 0 <= c < C.
  - reg: (float) regularization strength

  Returns a tuple of:
  - loss as single float
  - gradient with respect to weights W; an array of same shape as W
  """
  dW = np.zeros(W.shape) # initialize the gradient as zero

  # compute the loss and the gradient
  num_classes = W.shape[1]
  num_train = X.shape[0]
  loss = 0.0
  
  for i in xrange(num_train):
    scores = X[i].dot(W)
    correct_class_score = scores[y[i]]
    
    for j in xrange(num_classes):
      if j == y[i]:
        continue
    
      margin = scores[j] - correct_class_score + 1 # note delta = 1
      
      if margin > 0:
        loss += margin
        dW[:,j] += X[i,:]
        dW[:,y[i]] -= X[i,:]

  # Right now the loss is a sum over all training examples, but we want it
  # to be an average instead so we divide by num_train.
  loss /= num_train
  dW /=num_train

  # Add regularization to the loss.
  loss += reg * np.sum(W * W)

  #############################################################################
  # TODO:                                                                     #
  # Compute the gradient of the loss function and store it dW.                #
  # Rather that first computing the loss and then computing the derivative,   #
  # it may be simpler to compute the derivative at the same time that the     #
  # loss is being computed. As a result you may need to modify some of the    #
  # code above to compute the gradient.                                       #
  #############################################################################


  return loss, dW




def svm_loss_vectorized(W, X, y, reg):
  """
  Structured SVM loss function, vectorized implementation.
  Inputs and outputs are the same as svm_loss_naive.
  """
  loss = 0.0
  dW = np.zeros(W.shape) # initialize the gradient as zero
#  print('Shape of W', W.shape)
#  print('Shape of X', X.shape)
#  print('Shape of y', y.shape)
  #print('Shape of reg', len(reg))

  #############################################################################
  # TODO:                                                                     #
  # Implement a vectorized version of the structured SVM loss, storing the    #
  # result in loss.                                                           #
  #############################################################################
#  scores = W.dot(X)
#  print('Shape of score', scores.shape)
#  ccs = y + 1
#  print('Shape of ccs', ccs.shape)
#  correct_class_scores = (ccs[:,None] == np.arange(ccs.max())+1).astype(int)
#  print('Shape of correct_class_scores', correct_class_scores.shape)
#  correction_factor = np.where(correct_class_scores == 1, 0, 1)
#  print('Shape of correction_factor', correction_factor.shape)
#  
#  correct_scores = scores * correct_class_scores
#  print('Shape of correct_scores', correct_scores.shape)
#  correct_scores = np.sum(correct_scores, axis = 1)
#  print('Shape of correct_scores', correct_scores.shape)
#  margin = (scores.T - correct_scores).T +1
#  margin = margin * correction_factor
#  margin = np.where(margin > 0, margin, 0)
#  print('Shape of margin', margin.shape)
#  loss += np.sum(margin)
#  loss /= X.shape[0]
#  loss += 0.5 * reg * np.sum(W * W)
#  print('Shape of loss', loss.shape)
#  
  
#  scores = X.dot(W) #== scores = np.dot(X,W) ; dim = N X C
#  class_scores = np.array([scores[i,y[i]] for i in range(y.shape[0])])
#  cor_fact = np.ones(scores.shape).T * class_scores
#    
#  #deltas = np.ones(scores.shape)
#  deltas = 1
#  margin = scores - cor_fact.T + deltas
#    
#  margin = np.where(margin > 0, margin, 0)
#  loss += np.sum(margin)
#  loss /= X.shape[0] 
#    
#  loss += 0.5 * reg * np.sum(W*W)
  num_train = X.shape[0]
  delta = 1.0

  scores = X.dot(W)
  correct_class_score = scores[np.arange(num_train), y]
  margins = np.maximum(0, scores - correct_class_score[:, np.newaxis] + delta)
  margins[np.arange(num_train), y] = 0
  loss = np.sum(margins)

  loss /= num_train # get mean
  loss += 0.5 * reg * np.sum(W * W) # regularization
  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################


  #############################################################################
  # TODO:                                                                     #
  # Implement a vectorized version of the gradient for the structured SVM     #
  # loss, storing the result in dW.                                           #
  #                                                                           #
  # Hint: Instead of computing the gradient from scratch, it may be easier    #
  # to reuse some of the intermediate values that you used to compute the     #
  # loss.                                                                     #
  #############################################################################

  # Fully vectorized version. Roughly 10x faster.
  X_mask = np.zeros(margins.shape)
  # column maps to class, row maps to sample; a value v in X_mask[i, j]
  # adds a row sample i to column class j with multiple of v
  X_mask[margins > 0] = 1
  # for each sample, find the total number of classes where margin > 0
  incorrect_counts = np.sum(X_mask, axis=1)
  X_mask[np.arange(num_train), y] = -incorrect_counts
  dW = X.T.dot(X_mask)

  dW /= num_train # average out weights
  dW += reg*W # regularize the weights

#  margin = np.where(margin > 0, 1, 0)
#  margin_corr = np.sum(margin, axis = 1)
#  margin_corr = np.reshape(margin_corr, (margin_corr.shape[0], 1L))
#  print('Shape of margin_corr', margin_corr.shape)
#  neg = X.T.dot(correct_class_scores * margin_corr)
#  print('Shape of neg', margin_corr.shape)
#  pos = X.T.dot(margin)
#  print('Shape of pos', pos.shape)
#  dW += pos
#  dW -= neg
#  dW /= X.shape[0]
#  dW += reg * W
#  print('Shape of dW', dW.shape)
#  #############################################################################
  #                             END OF YOUR CODE                              #
  #############################################################################

  return loss, dW




#def svm_loss_vectorized(W, X, y, reg):
#  """
#  Structured SVM loss function, vectorized implementation.
#
#  Inputs and outputs are the same as svm_loss_naive.
#  """
#  loss = 0.0
#  dW = np.zeros(W.shape) # initialize the gradient as zero
#
#  #############################################################################
#  # TODO:                                                                     #
#  # Implement a vectorized version of the structured SVM loss, storing the    #
#  # result in loss.                                                           #
#  #############################################################################
#  #scores = np.dot(W.T, X.T)
#  scores = X.dot(W)
#  
#  print(scores.shape)
#  
#  score_correction = np.ones(scores.shape) * scores[y, np.arange(0, scores.shape[1])]
#  factor = np.ones(scores.shape) # Correction factor of one '1'
#  Margin = scores - score_correction + factor
#
#  Margin[Margin < 0] = 0
#  Margin[y, np.arange(0, scores.shape[1])] = 0 # Don't count y_i
#  loss = np.sum(Margin)
#
#  # Average over number of training examples
#  num_train = X.shape[1]
#  loss /= num_train
#
#  # Add regularization
#  loss += 0.5 * reg * np.sum(W * W)
#  
#  #pass
#  #############################################################################
#  #                             END OF YOUR CODE                              #
#  #############################################################################
#
#
#  #############################################################################
#  # TODO:                                                                     #
#  # Implement a vectorized version of the gradient for the structured SVM     #
#  # loss, storing the result in dW.                                           #
#  #                                                                           #
#  # Hint: Instead of computing the gradient from scratch, it may be easier    #
#  # to reuse some of the intermediate values that you used to compute the     #
#  # loss.                                                                     #
#  #############################################################################
#
#  Margin = scores - score_correction + factor
#
#  Margin[Margin < 0] = 0
#  Margin[Margin > 0] = 1
#  Margin[y, np.arange(0, scores.shape[1])] = 0 # Don't count y_i
#  Margin[y, np.arange(0, scores.shape[1])] = -1 * np.sum(Margin, axis=0)
#  dW = np.dot(Margin, X.T)
#
#  # Average over number of training examples
#  num_train = X.shape[1]
#  dW /= num_train
#  dW += reg * W
#  #pass
#  #############################################################################
#  #                             END OF YOUR CODE                              #
#  #############################################################################
#
#  return loss, dW
