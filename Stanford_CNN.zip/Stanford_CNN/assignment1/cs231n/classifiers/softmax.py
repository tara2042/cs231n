import numpy as np
from random import shuffle
#from past.builtins import xrange

def softmax_loss_naive(W, X, y, reg):
  """
  Softmax loss function, naive implementation (with loops)

  Inputs have dimension D, there are C classes, and we operate on minibatches
  of N examples.

  Inputs:
  - W: A numpy array of shape (D, C) containing weights.
  - X: A numpy array of shape (N, D) containing a minibatch of data.
  - y: A numpy array of shape (N,) containing training labels; y[i] = c means
    that X[i] has label c, where 0 <= c < C.
  - reg: (float) regularization strength

  Returns a tuple of:
  - loss as single float
  - gradient with respect to weights W; an array of same shape as W
  """
  # Initialize the loss and gradient to zero.
  loss = 0.0
  dW = np.zeros_like(W)

  #############################################################################
  # TODO: Compute the softmax loss and its gradient using explicit loops.     #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  #############################################################################
  
  num_train = X.shape[0]
  num_class = W.shape[1]
  dW = dW.astype(float)
  for i in xrange(num_train):
    scores = X[i].dot(W)
    exp_scores = np.exp(scores)
    prob_scores = exp_scores / np.sum(exp_scores)
    loss -= np.log(prob_scores[y[i]])
    for j in xrange(num_class):
      dW[:,j] += X[i] * prob_scores[j]
    dW[:,y[i]] -= X[i] * prob_scores[y[i]]
    dW[:,y[i]] -= X[i] * (1 - prob_scores[y[i]])
  loss /= num_train
  loss += 0.5 * reg * np.sum(W*W)
  dW /= num_train
  dW += reg * W
  
#  loss = 0.0
#  num_train = X.shape[0]
#  scores = np.zeros(W.shape)
#  scores = np.exp(X.dot(W)) # Applying exponent to each and every elements of score matrix
#  sample = np.zeros(scores.shape)
#  for i in xrange(num_train):
#      temp = scores[i,:]/np.sum(scores[i,:]) # Score normalization --- softmax
#      sample[i] = - np.log(temp) # softmax negative log loss / cross entropy
#      loss += np.sum(sample)
#  
#  loss /= num_train
#  loss += reg * np.sum(W * W)
#  dW = X.T.dot(sample)
#
#  dW /= num_train # average out weights
#  dW += reg*W # regularize the weights
  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

  return loss, dW


def softmax_loss_vectorized(W, X, y, reg):
  """
  Softmax loss function, vectorized version.

  Inputs and outputs are the same as softmax_loss_naive.
  """
  # Initialize the loss and gradient to zero.
  loss = 0.0
  dW = np.zeros_like(W)
  
  N = X.shape[0]
  
  #############################################################################
  # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  #############################################################################
  
  scores = X.dot(W)
  scores -= np.matrix(np.max(scores, axis=1)).T # Numerical Instability
    
#  term1 = -f[np.arange(N), y]
  sum_j = np.sum(np.exp(scores), axis=1)
#  term2 = np.log(sum_j)
#  loss = np.sum(term1 + term2)
#  loss /= N 
#  loss += 0.5 * reg * np.sum(W * W)
  
  norm_score = np.exp(scores) / np.matrix(sum_j).T # Score normalization
  
  loss = norm_score[np.arange(N), y] # Correct class scores
  loss = np.sum(-np.log(loss)) # Applying -ve log to the normalized score and taking the sum
  loss /= N # Avg. loss
  loss += 0.5 * reg * np.sum(W * W) # Reqularized loss
  
  norm_score[np.arange(N),y] -= 1 # Subtracting -1 from the normalized actual class scores
  dW = X.T.dot(norm_score)
  dW /= N
  dW += reg*W
    
  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

  return loss, dW

