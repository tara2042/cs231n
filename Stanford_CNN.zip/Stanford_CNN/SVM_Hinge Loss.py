# -*- coding: utf-8 -*-
"""
Created on Wed May 17 11:30:41 2017

@author: tarachy
"""

  """
  Structured SVM loss function, naive implementation (with loops).

  Inputs have dimension D, there are C classes, and we operate on minibatches
  of N examples.

  Inputs:
  - W: A numpy array of shape (D, C) containing weights.
  - X: A numpy array of shape (N, D) containing a minibatch of data.
  - y: A numpy array of shape (N,) containing training labels; y[i] = c means
    that X[i] has label c, where 0 <= c < C.
  - reg: (float) regularization strength

  Returns a tuple of:
  - loss as single float
  - gradient with respect to weights W; an array of same shape as W
  """

D = 10
C = 3
N = 50

loss = 0.0
reg = 0.0001
dW = np.zeros(W.shape) # initialize the gradient as zero

# generate a random SVM weight matrix of small numbers
W = np.random.randn(D, C)

X = np.random.randn(N, D)

y = np.random.randint(3, size=(50))

scores = X.dot(W) #== scores = np.dot(X,W) ; dim = N X C
class_scores = np.array([scores[i,y[i]] for i in range(y.shape[0])])
cor_fact = np.ones(scores.shape).T * class_scores

deltas = np.ones(scores.shape)
margin = scores - cor_fact.T + deltas

margin = np.where(margin > 0, margin, 0)
loss += np.sum(margin)
loss /= X.shape[0] 

loss += 0.5 * reg * np.sum(W*W)



## Gradient calculation with respect to xij and wj

margin = np.where(margin > 0, 1, 0)

margin_corr = np.sum(margin, axis = 1)
margin_corr = np.reshape(margin_corr, (margin_corr.shape[0], 1L))
neg = X.T.dot((cor_fact * margin_corr).T)
pos = X.T.dot(margin)
dW += pos
dW -= neg
dW /= X.shape[0]
dW += reg * W


ccs = y + 1
correct_class_scores = (ccs[:,None] == np.arange(ccs.max())+1).astype(int)